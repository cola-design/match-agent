import React, {
  useState,
  useEffect,
  useReducer,
  useRef,
  useCallback,
  memo,
} from "react";
import { createRoot } from "react-dom/client";
import {
  ScanLine,
  FileCheck2,
  BookOpen,
  Monitor,
  ChevronRight,
  Plus,
  FileText,
  Upload,
  ZoomIn,
  ZoomOut,
  Maximize,
  Maximize2,
  Minimize2,
  RotateCcw,
  ArrowUpRight,
  Copy,
  Check,
  LockKeyhole,
  Info,
  Clock3,
  Layers,
  ArrowRight,
  TriangleAlert,
  Image as ImageIcon,
  LoaderCircle,
  X,
  Link2,
  ShieldCheck,
  Download,
} from "lucide-react";
import contract from "./workflow-contract.json";
import {
  initialRun,
  reduceRun,
  phaseStates,
  validateFile,
  validateCount,
  readSSE,
  responseJSON,
  replyParagraphs,
} from "./workflow.mjs";
import "./styles.css";
import "./branding.css";
const reducer = (s, a) => reduceRun(s, a, contract);
const fileSize = (n) => `${(n / 1024 / 1024).toFixed(2)} MB`;
const elapsed = (start, end) => {
  const s = Math.max(0, Math.floor(((end || Date.now()) - start) / 1000));
  return `${Math.floor(s / 60)
    .toString()
    .padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
};
const STATUS = {
  idle: ["未开始", "neutral"],
  processing: ["处理中", "active"],
  review: ["待人工核对", "success"],
  attention: ["需处理", "warning"],
  error: ["处理未完成", "warning"],
  sample: ["示例体验完成", "neutral"],
};
const PREVIEW_ONLY = globalThis.WORKBENCH_PREVIEW_ONLY === true;
function useFileUrl(file) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    if (!file) {
      setUrl("");
      return;
    }
    const next = URL.createObjectURL(file);
    setUrl(next);
    return () => URL.revokeObjectURL(next);
  }, [file]);
  return url;
}
function Help({ onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    const previous = document.activeElement;
    ref.current.showModal();
    return () => previous?.focus?.();
  }, []);
  return (
    <dialog ref={ref} className="help-dialog" onCancel={onClose}>
      <div className="dialog-heading">
        <div>
          <span className="mini-label">操作指南</span>
          <h2>从系统图到选型报价</h2>
        </div>
        <button
          type="button"
          className="icon-button"
          aria-label="关闭使用指南"
          onClick={onClose}
        >
          <X />
        </button>
      </div>
      <ol className="help-steps">
        <li>
          <span>1</span>
          <div>
            <strong>上传完整的单柜系统图</strong>
            <p>
              支持PDF、PNG、JPG。项目名称和柜台数可留空，柜台数不要根据箱号猜填。
            </p>
          </div>
        </li>
        <li>
          <span>2</span>
          <div>
            <strong>开始识别，等待核对页生成</strong>
            <p>
              右侧显示实际处理状态。若返回资料问题，请按提示调整图纸，页面会保留已填内容。
            </p>
          </div>
        </li>
        <li>
          <span>3</span>
          <div>
            <strong>进入原核对页面继续操作</strong>
            <p>
              核实回路、参数、数量与供货范围，再进行产品选型、价格核对和Excel导出。
            </p>
          </div>
        </li>
      </ol>
      <details className="setup-details">
        <summary>首次使用：如何接入Dify应用？</summary>
        <p>
          将启动程序同目录的<code>.env.example</code>复制为<code>.env</code>
          ，填写Dify“访问API”页面提供的应用API地址与应用密钥，再重新启动程序。
        </p>
        <p>
          这里使用Dify应用密钥，不是模型密钥。原有图纸解析、核对和选型服务需保持可用。
        </p>
      </details>
      <div className="help-note">
        <Info />
        <span>
          {PREVIEW_ONLY
            ? "当前文件用于离线查看界面。接入Dify后，请通过运行工作台.bat启动，完成识图、人工核对和选型报价。"
            : "上传系统图并生成核对入口，核实图面参数后，在选型页面完成产品选择、价格核对与Excel导出。"}
        </span>
      </div>
      <button className="button primary full" onClick={onClose}>
        开始使用
      </button>
    </dialog>
  );
}
const Preview = memo(function Preview({
  file,
  isSample,
  busy,
  onChoose,
  onDrop,
  onRemove,
  ready,
  completed,
}) {
  const url = useFileUrl(file),
    pdf = !!file && /\.pdf$/i.test(file.name),
    loaded = !!file || isSample;
  const stageRef = useRef(null),
    panelRef = useRef(null),
    pan = useRef(null);
  const [zoom, setZoom] = useState(1),
    [size, setSize] = useState({ w: 700, h: 420 }),
    [natural, setNatural] = useState({ w: 1000, h: 650 }),
    [dragging, setDragging] = useState(false),
    [fullscreen, setFullscreen] = useState(false),
    [notice, setNotice] = useState(""),
    [imageError, setImageError] = useState(false);
  useEffect(() => {
    const el = stageRef.current,
      observer = new ResizeObserver((entries) => {
        const { width, height } = entries[0].contentRect;
        setSize((prev) =>
          prev.w === width && prev.h === height
            ? prev
            : { w: width, h: height },
        );
      });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    const changed = () =>
      setFullscreen(document.fullscreenElement === panelRef.current);
    document.addEventListener("fullscreenchange", changed);
    return () => document.removeEventListener("fullscreenchange", changed);
  }, []);
  const endPan = () => {
    if (pan.current) {
      try {
        stageRef.current.releasePointerCapture(pan.current.id);
      } catch {}
      pan.current = null;
    }
  };
  useEffect(() => {
    window.addEventListener("blur", endPan);
    return () => window.removeEventListener("blur", endPan);
  }, []);
  const ratio = natural.w / natural.h,
    baseWidth = Math.min(
      Math.max(200, size.w - 62),
      Math.max(160, size.h - 46) * ratio,
    ),
    paperWidth = baseWidth * zoom;
  const source = isSample ? "./drawing-example.svg" : url;
  const toggleFull = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await panelRef.current.requestFullscreen();
    } catch {
      setNotice("浏览器未允许全屏，可使用画布缩放或PDF自带工具。");
    }
  };
  const handlePointerDown = (e) => {
    const el = stageRef.current;
    if (pan.current || pdf || !loaded || zoom <= 1 || e.button !== 0) return;
    pan.current = {
      id: e.pointerId,
      x: e.clientX,
      y: e.clientY,
      left: el.scrollLeft,
      top: el.scrollTop,
    };
    el.setPointerCapture(e.pointerId);
  };
  const handlePointerMove = (e) => {
    const p = pan.current;
    if (!p || p.id !== e.pointerId) return;
    stageRef.current.scrollLeft = p.left - (e.clientX - p.x);
    stageRef.current.scrollTop = p.top - (e.clientY - p.y);
  };
  return (
    <section
      className={"preview-panel" + (!loaded ? " is-empty" : "") + (fullscreen ? " is-fullscreen" : "")}
      ref={panelRef}
      aria-label="系统图文件工作区"
    >
      <div className="preview-toolbar">
        <div className="document-tab">
          <FileText />
          <strong title={file?.name}>
            {isSample ? "配电箱系统图 · 操作示例" : file?.name || "系统图工作区"}
          </strong>
          <span className="file-pill">
            {isSample ? "示例" : pdf ? "PDF" : file ? "图片" : "待上传"}
          </span>
        </div>
        {loaded && <div className="canvas-tools">
          <button
            type="button"
            className="icon-button"
            aria-label="缩小图纸"
            title="缩小图纸"
            disabled={!loaded || pdf || zoom <= 0.5}
            onClick={() => setZoom((v) => Math.max(0.5, v - 0.25))}
          >
            <ZoomOut />
          </button>
          <span className="zoom-label">
            {pdf ? "PDF" : `${Math.round(zoom * 100)}%`}
          </span>
          <button
            type="button"
            className="icon-button"
            aria-label="放大图纸"
            title="放大图纸"
            disabled={!loaded || pdf || zoom >= 3}
            onClick={() => setZoom((v) => Math.min(3, v + 0.25))}
          >
            <ZoomIn />
          </button>
          <i />
          <button
            type="button"
            className="icon-button"
            aria-label="适合画布"
            title="适合画布"
            disabled={!loaded || pdf}
            onClick={() => setZoom(1)}
          >
            <Maximize />
          </button>
          <button
            type="button"
            className="icon-button"
            aria-label={fullscreen ? "退出全屏" : "全屏查看图纸"}
            title="全屏查看图纸"
            onClick={toggleFull}
          >
            {fullscreen ? <Minimize2 /> : <Maximize2 />}
          </button>
        </div>}
      </div>
      <div
        className={
          "canvas" + (!loaded ? " empty" : "") +
          (dragging ? " drag-over" : "") +
          (loaded && !pdf && zoom > 1 ? " can-pan" : "")
        }
        ref={stageRef}
        onDragOver={(e) => {
          e.preventDefault();
          if (!busy) setDragging(true);
        }}
        onDragLeave={(e) => {
          if (!e.currentTarget.contains(e.relatedTarget)) setDragging(false);
        }}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (!busy) onDrop(e.dataTransfer.files);
        }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={endPan}
        onPointerCancel={endPan}
        onLostPointerCapture={() => {
          pan.current = null;
        }}
        style={{ touchAction: loaded && !pdf && zoom > 1 ? "none" : "pan-y" }}
      >
        {!loaded ? (
          <div className="upload-well">
            <div className="upload-art" aria-hidden="true">
              <svg viewBox="0 0 76 88" fill="none"><path d="M14 4H47L64 21V80H14V4Z"/><path d="M47 4V21H64M25 35H53M38 35V44M25 62H53M27 62V70M50 62V70"/><path d="M33 44H43V56H33ZM38 56V62M36 47L41 53"/><circle cx="27" cy="72" r="2"/><circle cx="50" cy="72" r="2"/></svg>
              <b><Plus/></b>
            </div>
            <h2>上传电气系统图</h2>
            <p>将文件拖到这里，或点击下方按钮选择图纸。</p>
            <button type="button" className="button primary" onClick={onChoose}>
              <Upload />
              选择图纸文件
            </button>
            <div className="format-hints">
              <span>PDF ≤15MB</span>
              <i />
              <span>PNG / JPG ≤10MB</span>
            </div>
          </div>
        ) : pdf ? (
          <iframe
            key={url}
            src={url ? url + "#toolbar=1&navpanes=0&view=FitH" : undefined}
            title="上传PDF原件预览"
            className="pdf-frame"
          />
        ) : (
          <div
            className="drawing-paper"
            style={{ width: paperWidth, height: paperWidth / ratio }}
          >
            {source && !imageError ? (
              <img
                src={source}
                alt={
                  isSample
                    ? "虚构系统图，仅用于界面操作演示"
                    : "本次上传的原始图纸"
                }
                draggable="false"
                onLoad={(e) =>
                  setNatural({
                    w: e.currentTarget.naturalWidth,
                    h: e.currentTarget.naturalHeight,
                  })
                }
                onError={() => setImageError(true)}
              />
            ) : (
              <div className="preview-fallback">
                <ImageIcon />
                <strong>暂时无法预览图片</strong>
                <p>可更换图纸，或提交后以服务返回为准。</p>
              </div>
            )}
          </div>
        )}
        {loaded && (
          <span className={"canvas-badge" + (isSample ? " sample-badge" : "")}>
            {isSample ? "虚构示例 / 不作工程依据" : "本次上传原件"}
          </span>
        )}
      </div>
      {loaded && (
      <div className="filebar">
        <div>
          <span className="file-type-icon">
            {!file || pdf ? <FileText /> : <ImageIcon />}
          </span>
          <span>
            {isSample ? (
              "演示图纸，未上传客户资料"
            ) : file ? (
              <>
                <strong title={file.name}>{file.name}</strong>
                <small>{fileSize(file.size)}</small>
              </>
            ) : (
              "尚未选择图纸文件"
            )}
          </span>
        </div>
        <div className="filebar-actions">
          {file && url && (
            <a
              className="icon-button"
              href={url}
              download={file.name}
              title="下载本次原文件"
              aria-label="下载原文件"
            >
              <Download />
            </a>
          )}
          {loaded && (
            <button
              className="icon-button"
              type="button"
              title="移除图纸"
              aria-label="移除图纸"
              disabled={busy}
              onClick={onRemove}
            >
              <X />
            </button>
          )}
          <button
            className="text-button"
            type="button"
            disabled={busy}
            onClick={onChoose}
          >
            <RotateCcw />
            更换图纸
          </button>
        </div>
      </div>
      )}
      <div className="preview-action">
        <div className="scope-note">
          <ShieldCheck />
          <span>
            <strong>
              {isSample
                ? "示例不调用模型或查询数据库"
                : "图面信息仅作为选型依据"}
            </strong>
            <small>
              {isSample
                ? "真实识别会生成原核对页面的入口。"
                : "核对回路、参数、数量与供货范围后，再选型报价。"}
            </small>
          </span>
        </div>
        <button
          className={"button start-button" + (completed ? "" : " primary")}
          type="submit"
          disabled={busy || !ready}
          title={!ready ? "请先选择一份图纸" : undefined}
        >
          {busy ? <LoaderCircle className="spin" /> : completed ? <RotateCcw /> : <ScanLine />}
          {busy ? "正在处理…" : isSample ? "体验识别过程" : completed ? "重新识别" : "开始识别图纸"}
        </button>
      </div>
      {notice && <p className="inline-notice">{notice}</p>}
    </section>
  );
});
function RunClock({ startedAt, endedAt }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (endedAt) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [endedAt]);
  return (
    <span className="elapsed">
      <Clock3 />
      {elapsed(startedAt, endedAt || now)}
    </span>
  );
}
function ResultPanel({ run, phases, onRetry, onCopy, copied }) {
  const [label, tone] = STATUS[run.status],
    paragraphs = replyParagraphs(run.answer, contract.reviewUrlPattern);
  const title = {
    idle: "等待生成核对页",
    processing: run.sample ? "正在演示识图流程" : "正在处理系统图",
    review: "核对页已生成",
    attention: "本次未生成核对页",
    error: "这次处理未完成",
    sample: "示例体验已完成",
  }[run.status];
  return (
    <aside className="result-panel" aria-labelledby="result-title">
      <header className="result-heading">
        <div>
          <Layers />
          <h2>识别结果</h2>
        </div>
        <span className={"status-tag " + tone}>{label}</span>
      </header>
      {run.status !== "idle" && (
      <div className="process-section">
        <div className="section-caption">
          <span>{run.sample ? "示例处理进度" : "处理进度"}</span>
          {run.startedAt && (
            <RunClock startedAt={run.startedAt} endedAt={run.endedAt} />
          )}
        </div>
        <ol className="phase-list">
          {contract.phases.map((phase, i) => (
            <li key={phase.id} className={phases[i]}>
              <span className="phase-marker">
                {phases[i] === "done" ? (
                  <Check />
                ) : phases[i] === "attention" ? (
                  <TriangleAlert />
                ) : phases[i] === "active" ? (
                  <LoaderCircle className="spin" />
                ) : (
                  <span>{i + 1}</span>
                )}
              </span>
              <span>{phase.label}</span>
              <small>
                {
                  {
                    done: "完成",
                    active: "处理中",
                    attention: "需处理",
                    pending: "待开始",
                  }[phases[i]]
                }
              </small>
            </li>
          ))}
        </ol>
      </div>
      )}
      <section className="outcome" aria-live="polite">
        {run.status !== "idle" && <div className={"outcome-icon " + tone}>
          {run.status === "review" || run.status === "sample" ? (
            <FileCheck2 />
          ) : run.status === "attention" || run.status === "error" ? (
            <TriangleAlert />
          ) : run.status === "processing" ? (
            <ScanLine />
          ) : (
            <FileText />
          )}
        </div>}
        <h3 id="result-title">{title}</h3>
        {run.status === "idle" && (
          <>
            <p>上传图纸并开始识别，完成后会在这里显示核对入口。</p>
            <div className="expected-output"><span className="expected-caption">在核对页继续检查</span><ul><li><Check/><div><strong>器件参数</strong><span>核对图面型号、规格和原文。</span></div></li><li><Check/><div><strong>回路与数量</strong><span>确认器件归属、数量及供货范围。</span></div></li><li><Check/><div><strong>待确认事项</strong><span>处理模糊标注与缺失规格。</span></div></li></ul></div>
          </>
        )}
        {run.status === "processing" && (
          <>
            <p>
              {run.sample
                ? "示例使用虚构图纸，不进行真实识别。"
                : "图纸信息正在整理，请保持页面打开。处理完成后即可继续核对。"}
            </p>
            <div className="indeterminate-track" aria-label="图纸处理中">
              <span />
            </div>
          </>
        )}
        {["review", "attention"].includes(run.status) &&
          paragraphs.map((p, i) =>
            p.startsWith("建议先看") ? (
              <div key={i} className="priority-note">
                <span>
                  <TriangleAlert />
                  优先核对
                </span>
                <p>{p}</p>
              </div>
            ) : (
              <p key={i} className="answer-paragraph">
                {p}
              </p>
            ),
          )}
        {run.status === "error" && (
          <>
            <p className="error-message">{run.error}</p>
            <p>图纸与已填内容均已保留。请检查后重新提交。</p>
          </>
        )}
        {run.status === "sample" && (
          <>
            <p>
              这份虚构图纸用于体验预览、缩放与流程状态，不会生成真实核对链接。
            </p>
            <div className="next-step">
              <strong>正式识别完成后</strong>
              <span>
                此处将出现“打开图纸核对与选型页”，继续使用你原来的选型及报价页面。
              </span>
            </div>
          </>
        )}
        {run.url && (
          <>
            {run.workflowStatus === "partial-succeeded" && (
              <p className="partial-note">
                <TriangleAlert />
                部分步骤未完整完成，请在核对页重点复查。
              </p>
            )}
            <a
              className="button primary review-link"
              href={run.url}
              target="_blank"
              rel="noopener noreferrer"
            >
              打开图纸核对与选型页
              <ArrowUpRight />
            </a>
            <button type="button" className="copy-button" onClick={onCopy}>
              {copied ? <Check /> : <Copy />}
              {copied ? "链接已复制" : "复制核对链接"}
            </button>
            <div className="next-step">
              <strong>下一步：人工核对</strong>
              <span>
                核实回路、规格、数量和供货范围，确认型号后再导出报价表。
              </span>
            </div>
          </>
        )}
        {["attention", "error"].includes(run.status) && (
          <button
            className="button retry-button"
            type="button"
            onClick={onRetry}
          >
            <RotateCcw />
            返回检查
          </button>
        )}
      </section>
      {run.logs.length > 0 && (
        <details className="run-details">
          <summary>
            <span>
              处理记录<small>{run.logs.length}</small>
            </span>
            <ChevronRight />
          </summary>
          <ul>
            {run.logs.map((log, i) => (
              <li key={i} className={log.kind}>
                <time>{elapsed(run.startedAt, log.at)}</time>
                <span>{log.text}</span>
              </li>
            ))}
          </ul>
        </details>
      )}
      <footer className="result-foot">
        <Link2 />
        <p>
          产品匹配、价格核对与Excel导出，继续在原核对页面完成。
        </p>
      </footer>
    </aside>
  );
}
function App() {
  const [file, setFile] = useState(null),
    [isSample, setSample] = useState(false),
    [project, setProject] = useState(""),
    [count, setCount] = useState(""),
    [formError, setFormError] = useState(""),
    [configured, setConfigured] = useState(false),
    [help, setHelp] = useState(false),
    [copied, setCopied] = useState(false);
  const [run, dispatch] = useReducer(reducer, undefined, initialRun),
    fileInput = useRef(null),
    inflight = useRef(false),
    abort = useRef(null),
    projectRef = useRef(null),
    runRef = useRef(run),
    copyRef = useRef(null);
  runRef.current = run;
  const busy = run.status === "processing",
    ready = !!file || isSample,
    phases = phaseStates(run, contract);
  useEffect(() => {
    let disposed = false;
    if (PREVIEW_ONLY) return;
    fetch("/api/status")
      .then(responseJSON)
      .then((data) => {
        if (!disposed) setConfigured(data.configured === true);
      })
      .catch(() => {});
    return () => {
      disposed = true;
      abort.current?.abort();
      clearTimeout(copyRef.current);
    };
  }, []);
  const send = useCallback((action) => {
    const stamped = { ...action, at: action.at ?? Date.now() };
    runRef.current = reducer(runRef.current, stamped);
    dispatch(stamped);
  }, []);
  const choose = useCallback(() => fileInput.current.click(), []);
  const pick = useCallback(
    (files) => {
      if (inflight.current) return;
      if (files.length !== 1) {
        setFormError("本次只接收一份图纸，请按单柜分开上传。");
        return;
      }
      const incoming = files[0],
        problem = validateFile(incoming, contract.limits);
      if (problem) {
        setFormError(problem);
        return;
      }
      setFile(incoming);
      setSample(false);
      setFormError("");
      setCopied(false);
      send({ type: "reset" });
    },
    [send],
  );
  const remove = useCallback(() => {
    if (inflight.current) return;
    setFile(null);
    setSample(false);
    setFormError("");
    setCopied(false);
    send({ type: "reset" });
    fileInput.current.value = "";
  }, [send]);
  const restart = () => {
    remove();
    setProject("");
    setCount("");
    projectRef.current.focus();
  };
  const sample = () => {
    if (inflight.current) return;
    setFile(null);
    setSample(true);
    setFormError("");
    setCopied(false);
    send({ type: "reset" });
  };
  const submit = async (e) => {
    e?.preventDefault();
    if (inflight.current) return;
    const problem = validateCount(count);
    if (problem) {
      setFormError(problem);
      document.getElementById("count").focus();
      return;
    }
    if (!ready) {
      setFormError("请先选择一份系统图。");
      return;
    }
    if (!isSample && !configured) {
      setFormError(
        PREVIEW_ONLY
          ? "当前为界面预览。真实识图请启动运行包中的本机工作台。"
          : "尚未填写Dify应用配置。请在“使用指南”中查看首次接入说明。",
      );
      return;
    }
    setFormError("");
    setCopied(false);
    inflight.current = true;
    send({ type: "begin", sample: isSample });
    try {
      if (isSample) {
        for (const id of contract.phases.flatMap((phase) => phase.nodes)) {
          send({
            type: "event",
            event: {
              event: "node_started",
              data: { node_id: id, title: "示例：" + contract.nodeTitles[id] },
            },
          });
          await new Promise((r) => setTimeout(r, 140));
          send({
            type: "event",
            event: {
              event: "node_finished",
              data: {
                node_id: id,
                status: "succeeded",
                title: "示例：" + contract.nodeTitles[id],
              },
            },
          });
        }
        send({ type: "finish" });
        return;
      }
      abort.current = new AbortController();
      const body = new FormData();
      body.append("file", file);
      body.append("user", USER);
      const uploaded = await responseJSON(
        await fetch("/api/upload", {
          method: "POST",
          body,
          signal: abort.current.signal,
        }),
      );
      if (!uploaded.id) throw Error("图纸上传未返回文件标识，请检查应用服务。");
      send({ type: "note", text: "图纸已上传，正在启动识图流程" });
      const payload = {
        inputs: {
          drawing: {
            type: /\.pdf$/i.test(file.name) ? "document" : "image",
            transfer_method: "local_file",
            upload_file_id: uploaded.id,
          },
          project: project.trim(),
          cabinet_count: count,
        },
        query: contract.query,
        response_mode: "streaming",
        user: USER,
        conversation_id: "",
      };
      const response = await fetch("/api/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: abort.current.signal,
      });
      if (!response.ok) {
        await responseJSON(response);
        return;
      }
      const { ended } = await readSSE(response.body, (event) => {
        if (event.event === "error")
          throw Error(event.message || "识图服务运行失败，请检查后重试。");
        if (
          event.event === "workflow_finished" &&
          ["failed", "stopped"].includes(event.data?.status)
        )
          throw Error(
            event.data?.error || "识图流程未完整完成，请检查运行记录。",
          );
        send({ type: "event", event });
      });
      if (!ended)
        throw Error(
          "响应连接中断，未收到完整结果。请先检查Dify运行记录，避免重复提交。",
        );
      if (!runRef.current.answer.trim())
        throw Error("流程已结束，但没有返回核对结果。请检查应用回答节点。");
      send({ type: "finish" });
    } catch (error) {
      if (error.name !== "AbortError")
        send({
          type: "fail",
          error: error.message || "网络请求失败，请检查本机服务。",
        });
    } finally {
      inflight.current = false;
      abort.current = null;
    }
  };
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(run.url);
      setCopied(true);
      copyRef.current = setTimeout(() => setCopied(false), 2500);
    } catch {
      setFormError(
        "浏览器未允许自动复制，可右键核对按钮并选择“复制链接地址”。",
      );
    }
  };
  return (
    <>
      <a className="skip-link" href="#main">
        跳到工作区
      </a>
      <header className="enterprise-header">
        <a className="enterprise-brand" href="#main" aria-label="天正电气工作台">
          <span className="enterprise-wordmark">TENGEN<span>天正电气</span></span>
          <i className="brand-separator"/>
          <span className="enterprise-product">成套柜选型与报价</span>
        </a>
        <nav className="enterprise-nav" aria-label="工作台导航">
          <button type="button" className="enterprise-tab active" aria-current="page" onClick={()=>projectRef.current.focus()}><ScanLine/>系统图识别</button>
          <button type="button" className="enterprise-tab" disabled={!run.url} title={run.url?'打开原核对与选型页':'完成识别并生成核对页后可进入'} onClick={()=>window.open(run.url,'_blank','noopener,noreferrer')}><FileCheck2/>核对与选型{!run.url?<LockKeyhole className="tab-tail"/>:<ArrowUpRight className="tab-tail"/>}</button>
        </nav>
        <div className="enterprise-actions">
          <span className="config-status"><i className={configured?'configured':''}/>{PREVIEW_ONLY?'离线预览':configured?'应用配置已填写':'应用未配置'}</span>
          <button className="guide-trigger" type="button" onClick={()=>setHelp(true)}><BookOpen/>使用指南</button>
        </div>
      </header>
      <div className="application">
        <section className="command-hero" aria-labelledby="page-title">
          <div className="hero-inner">
            <div className="page-heading">
              <div>
                <div className="heading-line">
                  <h1 id="page-title">系统图识别</h1>
                  <span className="subtle-badge">单柜典型系统图</span>
                </div>
                <p>从一张系统图，开始清晰、可核对的选型与报价。</p>
                <ol className="hero-path" aria-label="业务操作顺序">
                  <li><span>01</span>上传系统图</li><li><span>02</span>核对识别结果</li><li><span>03</span>选型与报价</li>
                </ol>
              </div>
              <button className="button reset-button" type="button" disabled={busy} title="仅清空本页资料" onClick={restart}><RotateCcw/>重新开始</button>
            </div>
            <div className="hero-circuit" aria-hidden="true">
              <svg viewBox="0 0 600 240" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g stroke="currentColor" strokeWidth="1.2">
                  <path d="M50 8V55M50 89V112H560M50 116H560M50 150V194M180 116V150M310 116V150M440 116V150M560 116V150"/>
                  <path d="M50 179V211H98M180 182V211H228M310 182V211H358M440 182V211H488M560 182V211H596"/>
                  <rect x="39" y="55" width="22" height="34"/><path d="M44 61L57 82"/>
                  <path d="M41 150H59V179H41ZM171 150H189V182H171ZM301 150H319V182H301ZM431 150H449V182H431ZM551 150H569V182H551Z"/>
                  <path d="M46 156L55 173M176 157L185 175M306 157L315 175M436 157L445 175M556 157L565 175"/>
                  <circle cx="50" cy="112" r="3" fill="currentColor"/><circle cx="180" cy="116" r="3" fill="currentColor"/><circle cx="310" cy="116" r="3" fill="currentColor"/><circle cx="440" cy="116" r="3" fill="currentColor"/><circle cx="560" cy="116" r="3" fill="currentColor"/>
                  <path opacity=".4" d="M80 25H270V75H590M80 31H262V83H590M330 12V57H590M26 226H596"/>
                </g>
                <g fill="currentColor" fontSize="11" fontFamily="Arial,sans-serif"><text x="72" y="76">QF</text><text x="70" y="170">L1</text><text x="200" y="170">L2</text><text x="330" y="170">L3</text><text x="460" y="170">N</text></g>
              </svg>
            </div>
          </div>
        </section>
        <main id="main" className="workspace">
          <form onSubmit={submit} noValidate>
            <input
              ref={fileInput}
              className="visually-hidden"
              type="file"
              accept=".pdf,.png,.jpg,.jpeg"
              aria-label="选择系统图文件"
              tabIndex={-1}
              onChange={(e) => {
                pick(e.target.files);
                e.target.value = "";
              }}
            />
            {formError && (
              <div className="form-alert" role="alert">
                <TriangleAlert />
                <span>{formError}</span>
                <button
                  type="button"
                  className="icon-button"
                  aria-label="关闭提示"
                  onClick={() => setFormError("")}
                >
                  <X />
                </button>
              </div>
            )}
            <div className="work-grid">
              <div className="drawing-column">
                <section className="project-bar" aria-label="本次识图资料">
                  <div className="project-field">
                    <label htmlFor="project">
                      项目名称<span>{run.status === "review" ? "已提交" : "选填"}</span>
                    </label>
                    <input
                      ref={projectRef}
                      id="project"
                      value={project}
                      readOnly={run.status === "review"}
                      maxLength={contract.limits.projectLength}
                      disabled={busy}
                      onChange={(e) => setProject(e.target.value)}
                      placeholder="为本次识图填写项目名称"
                      autoComplete="off"
                    />
                  </div>
                  <div className="count-field">
                    <label htmlFor="count">
                      柜台数<span>{run.status === "review" ? "已提交" : "选填"}</span>
                    </label>
                    <input
                      id="count"
                      value={count}
                      readOnly={run.status === "review"}
                      maxLength={6}
                      inputMode="numeric"
                      disabled={busy}
                      onChange={(e) => setCount(e.target.value)}
                      placeholder="待确认"
                      aria-describedby="count-hint"
                      autoComplete="off"
                    />
                  </div>
                  <div className="project-context">
                    <span className={"ready-dot" + (ready ? " ready" : "")} />
                    <div>
                      <strong>
                        {file
                          ? "已选择1份图纸"
                          : isSample
                            ? "示例图纸已载入"
                            : "等待上传图纸"}
                      </strong>
                      <small id="count-hint">柜台数可在核对页补充</small>
                    </div>
                  </div>
                </section>
                <Preview
                  key={
                    isSample
                      ? "sample"
                      : file
                        ? `${file.name}-${file.size}-${file.lastModified}`
                        : "empty"
                  }
                  file={file}
                  isSample={isSample}
                  busy={busy}
                  onChoose={choose}
                  onDrop={pick}
                  onRemove={remove}
                  ready={ready}
                  completed={run.status === "review"}
                />
                <div className="drawing-foot">
                  <span>
                    <Info />
                    建议上传单柜系统图，多个柜型请分开处理。
                  </span>
                  {PREVIEW_ONLY && <button
                    type="button"
                    className="text-button sample-link"
                    onClick={sample}
                    disabled={busy}
                  >
                    查看操作示例
                    <ArrowRight />
                  </button>}
                </div>
              </div>
              <ResultPanel
                run={run}
                phases={phases}
                onRetry={() => {
                  setFormError(
                    "文件和填写内容已保留。请根据返回信息检查资料或服务，再点击“开始识别图纸”。",
                  );
                  document.querySelector(".start-button").focus();
                }}
                onCopy={copy}
                copied={copied}
              />
            </div>
          </form>
          <footer className="workspace-footer">
            <span>天正电气成套柜选型报价工作台</span>
            <span>
              <ShieldCheck />
              图纸辅助识别，结果以人工核对为准。
            </span>
          </footer>
        </main>
      </div>
      {help && <Help onClose={() => setHelp(false)} />}
    </>
  );
}
const USER =
  "workbench-" + (globalThis.crypto?.randomUUID?.() || Date.now().toString(36));
createRoot(document.getElementById("root")).render(<App />);
