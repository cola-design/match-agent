from pathlib import Path
import os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':1000});requests=[];errors=[]
 page.on('request',lambda request:requests.append(request.url));page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(os.environ.get('WORKBENCH_TEST_URL','http://localhost:8780')+'/界面预览.html');page.wait_for_load_state('networkidle');page.get_by_text('离线预览',exact=True).wait_for()
 page.get_by_role('button',name='查看操作示例').click();page.locator('.drawing-paper img').wait_for();page.wait_for_timeout(100);image=page.locator('.drawing-paper img').screenshot()
 page.get_by_role('button',name='体验识别过程').click();page.get_by_role('heading',name='示例体验已完成',exact=True).wait_for()
 page.locator('input[type=file]').set_input_files({'name':'preview.png','mimeType':'image/png','buffer':image})
 page.get_by_role('button',name='开始识别图纸',exact=True).click();assert '当前为界面预览' in page.get_by_role('alert').inner_text()
 assert not any('/api/' in url or '/assets/' in url for url in requests),requests
 assert not errors,errors
 browser.close()
print('PASS: self-contained preview, embedded art, zero asset/API requests, real calls disabled, sample works.')
