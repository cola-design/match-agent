"""Make a self-contained UI preview; disables all real API calls."""
from pathlib import Path
import base64,re
root=Path(__file__).resolve().parents[1];web=root/'web'
html=(web/'index.html').read_text()
js_path=re.search(r'<script[^>]+src="([^"]+\.js)"',html).group(1)
css_path=re.search(r'<link[^>]+href="([^"]+\.css)"',html).group(1)
script=(web/js_path.removeprefix('./')).read_text();css=(web/css_path.removeprefix('./')).read_text()
svg=base64.b64encode((web/'drawing-example.svg').read_bytes()).decode()
assert './drawing-example.svg' in script
script=script.replace('./drawing-example.svg','data:image/svg+xml;base64,'+svg).replace('</script','<\\/script')
preview='<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>天正电气工作台 · 离线预览</title><style>'+css+'</style></head><body><div id="root"></div><script>globalThis.WORKBENCH_PREVIEW_ONLY=true;</script><script type="module">'+script+'</script></body></html>'
assert not re.search(r'<script[^>]+src=',preview)
for path in [root/'界面预览.html',web/'界面预览.html']:path.write_text(preview)
print('Self-contained preview written; no remote assets or real API calls enabled.')
