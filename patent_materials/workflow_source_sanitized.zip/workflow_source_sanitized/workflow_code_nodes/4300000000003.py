import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_WIRE_MAX = 55000
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_pack(value):
    raw = _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if len(raw) > _CONTEXT_MAX:
        raise CapacityError('完整上下文超过本版5MB保护上限，请按柜号或回路分批')
    if len(raw) <= _WIRE_MAX:
        return raw.decode('utf-8')
    result = _WIRE_PREFIX + _whash.sha256(raw).hexdigest() + ':' + _wb64.b64encode(_wgzip.compress(raw, compresslevel=9, mtime=0)).decode('ascii')
    if len(result.encode('utf-8')) > _WIRE_MAX:
        raise CapacityError('上下文无损压缩后仍超过传递预算，请按柜号或回路分批；本次不生成不完整BOM')
    return result
import json
import re

def collect_advisories(results, manifest):
    meta = json.loads(manifest)
    expected = set(meta['ids'])
    seen = set()
    errors = list(meta['errors'])
    rows = []
    warnings = []
    conflicts = []
    for raw in results if isinstance(results, list) else []:
        try:
            part = json.loads(re.sub('^```(?:json)?\\s*|\\s*```$', '', str(raw).strip(), flags=re.I))
            aid = part.get('advisory_id')
            if aid not in expected or aid in seen:
                raise ValueError('关联批次编号缺失、错误或重复')
            seen.add(aid)
            if part.get('input_problem'):
                errors.append(str(part['input_problem']))
            values = part.get('component_requirements', [])
            if not isinstance(values, list):
                raise ValueError('关联需求不是数组')
            rows.extend(values)
            warnings.extend(part.get('warnings', []))
            conflicts.extend(part.get('potential_conflicts', []))
        except (ValueError, TypeError, AttributeError) as exc:
            errors.append('语义关联批次输出错误：' + str(exc))
    if expected - seen:
        errors.append('语义关联批次缺失：' + '、'.join(sorted(expected - seen)))
    return {'text': wire_pack({'component_requirements': rows, 'warnings': warnings, 'potential_conflicts': conflicts, '_document_errors': errors})}

def main(results, manifest):
    return collect_advisories(results, manifest)
