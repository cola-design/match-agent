import json

def clean(value):
    return str(value or '').replace('\u200b', '').replace('\ufeff', '').strip()

def main(item):
    row = item if isinstance(item, dict) else {}
    code = clean(row.get('material_code')).upper()
    model = clean(row.get('model_spec'))
    name = clean(row.get('material_name'))
    retry = ' '.join(dict.fromkeys((x for x in (code, model, name) if x)))
    return {'material_code': code, 'retrieval_query': code, 'bare_code_query': code, 'retry_query': retry, 'item_json': json.dumps(row, ensure_ascii=False)}
