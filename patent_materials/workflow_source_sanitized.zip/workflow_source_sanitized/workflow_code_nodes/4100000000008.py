def main(result_json):
    return {"result_json":result_json}
