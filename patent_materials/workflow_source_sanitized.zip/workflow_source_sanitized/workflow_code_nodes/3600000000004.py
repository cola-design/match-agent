import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_WIRE_MAX = 55000
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def wire_pack(value):
    raw = _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if len(raw) > _CONTEXT_MAX:
        raise CapacityError('完整上下文超过本版5MB保护上限，请按柜号或回路分批')
    if len(raw) <= _WIRE_MAX:
        return raw.decode('utf-8')
    result = _WIRE_PREFIX + _whash.sha256(raw).hexdigest() + ':' + _wb64.b64encode(_wgzip.compress(raw, compresslevel=9, mtime=0)).decode('ascii')
    if len(result.encode('utf-8')) > _WIRE_MAX:
        raise CapacityError('上下文无损压缩后仍超过传递预算，请按柜号或回路分批；本次不生成不完整BOM')
    return result

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
import base64
import gzip
import re

def clean(value):
    return '' if value is None else str(value).strip()

def _original_main(extracted_text: str) -> dict:
    text = clean(extracted_text)
    form_type = ''
    if 'CLARIFICATION_CONFIRMATION' in text:
        form_type = 'CLARIFICATION_CONFIRMATION'
    elif 'BOM_CONFIRMATION' in text:
        form_type = 'BOM_CONFIRMATION'
    part_matches = re.findall('PAYLOAD_B64_PART_(\\d{3}):\\s*([A-Za-z0-9+/=]{1,24000})', text)
    if part_matches:
        indexed = {}
        for index, value in part_matches:
            key = int(index)
            if key in indexed and indexed[key] != value:
                return {'form_status': 'INVALID', 'form_type': form_type, 'base_payload_json': '{}', 'human_table_text': text[:16000], 'parse_message': '系统上下文存在相互冲突的重复分段'}
            indexed[key] = value
        ordered = sorted(indexed.items(), key=lambda x: x[0])
        payload_b64 = ''.join((value for _, value in ordered))
        payload_markers = [match.group(0) for match in re.finditer('PAYLOAD_B64_PART_\\d{3}:\\s*[A-Za-z0-9+/=]{1,24000}', text)]
    else:
        legacy = re.search('PAYLOAD_B64:\\s*([A-Za-z0-9+/=]{80,})', text)
        payload_b64 = legacy.group(1) if legacy else ''
        payload_markers = [legacy.group(0)] if legacy else []
    if not payload_b64:
        return {'form_status': 'INVALID', 'form_type': form_type, 'base_payload_json': '{}', 'human_table_text': text[:16000], 'parse_message': '未找到系统上下文，可能不是本系统V14生成的文件或系统数据页被修改'}
    try:
        raw = base64.b64decode(payload_b64)
        try:
            decoded = gzip.decompress(raw).decode('utf-8')
        except (OSError, EOFError):
            decoded = raw.decode('utf-8')
        payload = wire_loads(decoded)
        decoded = plain_json(payload)
        if not isinstance(payload, dict):
            raise ValueError('系统上下文不是JSON对象')
    except Exception as exc:
        return {'form_status': 'INVALID', 'form_type': form_type, 'base_payload_json': '{}', 'human_table_text': text[:16000], 'parse_message': '系统上下文损坏：%s' % clean(exc)}
    if form_type != 'CLARIFICATION_CONFIRMATION':
        return {'form_status': 'WRONG_FORM', 'form_type': form_type, 'base_payload_json': decoded, 'human_table_text': text[:16000], 'parse_message': '当前文件不是选型前问题确认表，请改用正确入口'}
    visible = text
    for marker in payload_markers:
        visible = visible.replace(marker, '[系统上下文分段已读取]')
    if len(visible.encode('utf-8')) > 50000:
        return {'form_status': 'INVALID', 'form_type': form_type, 'base_payload_json': '{}', 'human_table_text': '', 'parse_message': '问题确认表正文超过50KB预算，请分批；未截取前半份意见'}
    return {'form_status': 'VALID', 'form_type': form_type, 'base_payload_json': decoded, 'human_table_text': visible, 'parse_message': '问题确认表及选型上下文读取成功'}

def main(extracted_text):
    out = _original_main(extracted_text)
    try:
        base = wire_loads(out['base_payload_json'])
        if base.get('capacity_blocked'):
            out.update(form_status='INVALID', parse_message=base.get('capacity_message') or '请分批重新上传原始协议和图纸，不能以填写采用解除容量限制')
        reqs = base.get('component_requirements', [])
        projection = {'component_requirements': [{k: r[k] for k in ('request_id', 'scheme_group_id', 'circuit_id', 'component_role', 'category_path', 'requirements', 'quantity_per_cabinet', 'cabinet_quantity', 'shown_model', 'handling_mode') if k in r} for r in reqs if isinstance(r, dict)], 'issues': base.get('issues', []), 'projection_only': True, 'note': '这是供意见映射的需求与问题投影，不包含完整证据；完整数据由后续代码恢复，不得推测未提供的技术结论。'}
        prompt = plain_json(projection)
        if len(prompt.encode('utf-8')) > 50000:
            out.update(form_status='INVALID', parse_message='问题确认映射数据超过50KB预算，请分批重新选型；本次未截断需求')
            prompt = '{}'
        out['base_payload_prompt'] = prompt
        out['base_payload_json'] = wire_pack(base)
    except Exception as exc:
        out.update(form_status='INVALID', parse_message='问题确认上下文无法完整恢复：' + str(exc), base_payload_json='{}', base_payload_prompt='{}')
    return out
