import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_WIRE_MAX = 55000
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def wire_pack(value):
    raw = _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if len(raw) > _CONTEXT_MAX:
        raise CapacityError('完整上下文超过本版5MB保护上限，请按柜号或回路分批')
    if len(raw) <= _WIRE_MAX:
        return raw.decode('utf-8')
    result = _WIRE_PREFIX + _whash.sha256(raw).hexdigest() + ':' + _wb64.b64encode(_wgzip.compress(raw, compresslevel=9, mtime=0)).decode('ascii')
    if len(result.encode('utf-8')) > _WIRE_MAX:
        raise CapacityError('上下文无损压缩后仍超过传递预算，请按柜号或回路分批；本次不生成不完整BOM')
    return result

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
import json
import re

def strip_fence(text):
    value = (text or '').strip()
    value = re.sub('^```(?:json)?\\s*', '', value, flags=re.I)
    value = re.sub('\\s*```$', '', value)
    return value.strip()

def clean(value):
    if value is None:
        return ''
    if isinstance(value, bool):
        return '是' if value else '否'
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    return str(value).replace('|', '／').replace('\n', ' ').replace('\r', ' ').strip()

def as_number(value):
    if value in (None, '') or isinstance(value, bool):
        return None
    try:
        x = float(value)
        return int(x) if x.is_integer() else x
    except Exception:
        return None

def tri_bool(value):
    if isinstance(value, bool):
        return value
    text = clean(value).lower()
    if text in {'是', '有', '需要', '配置', 'true', 'yes'}:
        return True
    if text in {'否', '无', '不需要', '不配置', '无需', 'false', 'no'}:
        return False
    return None

def chinese_message(value, fallback='未返回具体原因，请查看节点输入输出'):
    if isinstance(value,dict):
        for key in ('message','description','reason','detail','text'):
            if value.get(key):return chinese_message(value[key],fallback)
        return clean(json.dumps(value,ensure_ascii=False)) or fallback
    if isinstance(value,list):return '；'.join(chinese_message(x,fallback) for x in value) or fallback
    return clean(value) or fallback

def evidence_text(value):
    if isinstance(value,list):return '；'.join(evidence_text(x) for x in value if x)
    if not isinstance(value,dict) or not clean(value.get('text')):return '未取得可定位原文，需复核'
    page=value.get('page_index') or value.get('image_index')
    place='第%s页'%page if page not in (None,'') else ('文本段'+str(value.get('chunk_id')) if value.get('chunk_id') else '来源位置待核对')
    if value.get('source_start') is not None and value.get('source_end') is not None:place+='（字符%s—%s）'%(value['source_start'],value['source_end'])
    return clean(place+' '+clean(value.get('location'))+' '+clean(value.get('text')))

def normalize_material(item, fallback_scope, fallback_category, fallback_evidence, item_id):
    src = item if isinstance(item, dict) else {}
    role = src.get('component_role') or src.get('name') or src.get('material_name') or src.get('item_name') or ''
    model = src.get('shown_model') or src.get('model') or src.get('specification') or src.get('spec') or ''
    params = src.get('shown_parameters') if isinstance(src.get('shown_parameters'), dict) else src.get('parameters')
    if not isinstance(params, dict):
        params = {}
    qty = src.get('quantity_per_cabinet')
    if qty is None:
        qty = src.get('quantity')
    if qty is None:
        qty = src.get('qty')
    result = {'item_id': clean(src.get('item_id')) or item_id, 'source_row_key': clean(src.get('source_row_key')), 'scope_type': clean(src.get('scope_type')) or fallback_scope, 'circuit_id': clean(src.get('circuit_id')), 'symbol': clean(src.get('symbol')), 'component_role': clean(role), 'category': clean(src.get('category')) or fallback_category, 'shown_model': clean(model), 'shown_parameters': params, 'quantity_per_cabinet': as_number(qty), 'unit': clean(src.get('unit')) or '件', 'functional_position': clean(src.get('functional_position')), 'path_order': as_number(src.get('path_order')), 'evidence': src.get('evidence') if isinstance(src.get('evidence'), (dict, list, str)) else fallback_evidence}
    result['parameter_facts'] = copy.deepcopy(src.get('parameter_facts') or [])
    return result

def evidence_signature(item):
    ev = item.get('evidence') if isinstance(item, dict) else None
    if isinstance(ev, dict):
        return (clean(ev.get('page_index')), clean(ev.get('location')), clean(ev.get('text')))
    return ('', '', clean(ev))

def split_external_cables(items):
    inside, external = ([], [])
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        role = clean(item.get('component_role'))
        category = clean(item.get('category'))
        ev = evidence_text(item.get('evidence'))
        is_external = '外部并网电缆' in role or (category == '电缆' and '并网电缆线径' in ev)
        (external if is_external else inside).append(item)
    return (inside, external)

def status_cn(value):
    return {'VALID': '校验通过', 'NEED_REVIEW': '需要人工确认', 'INVALID': '识别失败'}.get(clean(value).upper(), '待确认')

def build_review_markdown(data, status, summary, issues):
    groups = data.get('scheme_groups') if isinstance(data.get('scheme_groups'), list) else []
    lines = ['## 识别概况', '', '| 项目 | 内容 |', '|---|---|', '| 确认单类型 | 图纸识别问题确认单 |', '| 图纸识别状态 | %s |' % status_cn(status), '| 已识别方案组数 | %d |' % len(groups), '| 识别摘要 | %s |' % clean(summary), '', '## 待处理问题', '', '| 序号 | 问题级别 | 问题说明 | 人工处理结果 |', '|---:|---|---|---|']
    visible = [x for x in issues if isinstance(x, dict) and x.get('severity') in {'BLOCKER', 'WARNING'}]
    if not visible:
        lines.append('| 1 | 信息 | 图纸结构校验通过 |  |')
    else:
        for i, issue in enumerate(visible, 1):
            lines.append('| %d | %s | %s |  |' % (i, issue.get('level', '警告'), chinese_message(issue.get('message'))))
    lines += ['', '## 已识别方案组', '', '| 序号 | 方案组 | 方案名称 | 进线数 | 出线数 | 表位 | 主电流(A) | 防护等级 | 单柜样例数 | PDF证据 |', '|---:|---|---|---:|---:|---|---:|---|---:|---|']
    for i, g in enumerate(groups, 1):
        lines.append('| %d | %s | %s | %s | %s | %s | %s | %s | %s | %s |' % (i, clean(g.get('scheme_group_id')), clean(g.get('scheme_name')), clean(g.get('incoming_count')), clean(g.get('outgoing_count')), clean(g.get('meter_required')), clean(g.get('main_current_a')), clean(g.get('protection_level')), clean(g.get('drawing_sample_quantity')), evidence_text(g.get('evidence'))))
    return '\n'.join(lines)

def _original_main(vision_text: str, raw_drawing_text: str='') -> dict:
    issues = []
    try:
        data = json.loads(strip_fence(vision_text))
        if not isinstance(data, dict):
            raise ValueError('根节点不是对象')
    except Exception:
        data = {}
        issues.append({'level': '错误', 'severity': 'BLOCKER', 'message': '图纸解析输出不是合法JSON对象'})
    recognition = clean(data.get('recognition_status')).upper()
    if recognition not in {'READABLE', 'PARTIAL', 'UNREADABLE'}:
        issues.append({'level': '错误', 'severity': 'BLOCKER', 'message': '缺少有效图纸识别状态'})
    groups = data.get('scheme_groups') if isinstance(data.get('scheme_groups'), list) else []
    if not groups:
        issues.append({'level': '错误', 'severity': 'BLOCKER', 'message': '未识别到任何方案组'})
    valid_groups = []
    total_circuits = total_components = total_items = 0
    for gi, raw_group in enumerate(groups, 1):
        if not isinstance(raw_group, dict):
            issues.append({'level': '错误', 'severity': 'BLOCKER', 'message': '第%d个方案组格式错误' % gi})
            continue
        group = dict(raw_group)
        gid = clean(group.get('scheme_group_id')) or '方案组-%02d' % gi
        group['scheme_group_id'] = gid
        group['meter_required'] = tri_bool(group.get('meter_required'))
        group['leakage_required'] = tri_bool(group.get('leakage_required'))
        for k in ['incoming_count', 'outgoing_count', 'isolator_count', 'main_current_a', 'cabinet_thickness_mm']:
            group[k] = as_number(group.get(k))
        sample_qty = as_number(group.get('drawing_sample_quantity'))
        if sample_qty is None:
            sample_qty = as_number(group.get('quantity'))
        if sample_qty is None:
            issues.append({'level': '警告', 'severity': 'WARNING', 'message': '%s未标样柜数量，保留空值；不推断项目总柜数' % gid})
        group['drawing_sample_quantity'] = sample_qty
        circuits = group.get('circuits') if isinstance(group.get('circuits'), list) else []
        if not circuits:
            issues.append({'level': '警告', 'severity': 'WARNING', 'message': '%s未识别到连接回路；可保留有证据的物料表，不补造拓扑' % gid})
        normalized_circuits, unified_items = ([], [])
        group_evidence_count = 0
        for ci, raw_circuit in enumerate(circuits, 1):
            if not isinstance(raw_circuit, dict):
                continue
            circuit = dict(raw_circuit)
            cid = clean(circuit.get('circuit_id')) or 'CIR-%02d' % ci
            circuit['circuit_id'] = cid
            for k in ['rated_voltage_v', 'current_a', 'breaking_capacity_ka']:
                circuit[k] = as_number(circuit.get(k))
            ev = circuit.get('evidence')
            if isinstance(ev, dict) and (ev.get('page_index') or ev.get('text')):
                group_evidence_count += 1
            comps = circuit.get('components') if isinstance(circuit.get('components'), list) else []
            normalized_components = []
            for ii, raw_comp in enumerate(comps, 1):
                fallback_id = '%s-%s-%02d' % (gid, cid, ii)
                comp = normalize_material(raw_comp, 'circuit', clean(raw_comp.get('category')) if isinstance(raw_comp, dict) else '', ev, fallback_id)
                comp['scope_type'] = 'circuit'
                comp['circuit_id'] = cid
                if comp['quantity_per_cabinet'] is None:
                    issues.append({'level': '警告', 'severity': 'WARNING', 'message': '%s %s 的单柜数量未明确，保留空值并要求复核，不自动补1' % (gid, comp.get('component_role') or comp.get('symbol') or fallback_id)})
                normalized_components.append(comp)
                unified_items.append(dict(comp))
            circuit['components'] = normalized_components
            normalized_circuits.append(circuit)
        group['circuits'] = normalized_circuits
        unified_items = [dict(comp) for c in normalized_circuits if isinstance(c, dict) for comp in (c.get('components', []) if isinstance(c.get('components'), list) else []) if isinstance(comp, dict)]
        total_components += len(unified_items)
        seq = 0
        field_lists = {}
        for field, scope, category in [('shown_bom', 'auxiliary', '辅材'), ('auxiliary_materials', 'auxiliary', '辅材'), ('wire_requirements', 'cabinet', '导线/铜排')]:
            raw_items = group.get(field) if isinstance(group.get(field), list) else []
            normalized_list = []
            for raw_item in raw_items:
                seq += 1
                item = normalize_material(raw_item, scope, category, group.get('evidence'), '%s-AUX-%03d' % (gid, seq))
                normalized_list.append(item)
            field_lists[field] = normalized_list
        field_lists['shown_bom'] = repair_bom_fragments(field_lists.get('shown_bom', []), issues, gid)
        field_lists['auxiliary_materials'] = repair_bom_fragments(field_lists.get('auxiliary_materials', []), issues, gid)
        for field, items in field_lists.items():
            group[field] = items
            unified_items.extend((dict(x) for x in items))
        unified_items, external_cables = split_external_cables(unified_items)
        group['external_cable_requirements'] = external_cables
        for _field in ['shown_bom', 'auxiliary_materials', 'wire_requirements']:
            _inside, _ext = split_external_cables(group.get(_field, []))
            group[_field] = _inside
        deduped, seen = ([], set())
        for item in unified_items:
            sig = (clean(item.get('scope_type')), clean(item.get('circuit_id')), clean(item.get('symbol')), clean(item.get('component_role')), clean(item.get('shown_model')), clean(item.get('quantity_per_cabinet')), evidence_signature(item))
            if sig in seen:
                continue
            seen.add(sig)
            deduped.append(item)
        group['drawing_items'] = deduped
        total_items += len(deduped)
        total_circuits += len(normalized_circuits)
        if not deduped:
            issues.append({'level': '错误', 'severity': 'BLOCKER', 'message': '%s未识别到任何元器件或辅材' % gid})
        if not evidence_proven(group.get('evidence')):
            issues.append({'level': '错误', 'severity': 'BLOCKER', 'message': '%s缺少可定位的页码或文本段原文证据' % gid})
        valid_groups.append(group)
    data['schema_version'] = 'drawing-pdf-text-v3-normalized'
    data['scheme_groups'] = valid_groups
    for warning in data.get('warnings', []) if isinstance(data.get('warnings'), list) else []:
        issues.append({'level': '警告', 'severity': 'WARNING', 'message': chinese_message(warning)})
    if recognition == 'PARTIAL':
        issues.append({'level': '警告', 'severity': 'WARNING', 'message': ('原文证据或分段完整性校验未通过，具体原因见来源问题' if data.get('_document_errors') else '模型报告图纸存在未完整提取的内容')})
    if recognition == 'UNREADABLE':
        issues.append({'level': '错误', 'severity': 'BLOCKER', 'message': '模型判定图纸不可读'})
    blockers = [x for x in issues if x.get('severity') == 'BLOCKER']
    status = 'VALID' if recognition == 'READABLE' and (not blockers) else 'NEED_REVIEW'
    summary = '方案组%d个，回路%d个，规范化图纸物料%d项，阻断问题%d项，警告%d项。' % (len(valid_groups), total_circuits, total_items, len(blockers), len([x for x in issues if x.get('severity') == 'WARNING']))
    return {'drawing_validation_status': status, 'drawing_validation_message': '；'.join((x.get('message', '') for x in issues if x.get('severity') in {'BLOCKER', 'WARNING'})) if issues else '图纸识别质量和结构校验通过', 'drawing_summary': summary, 'validated_drawing_json': json.dumps(data, ensure_ascii=False), 'drawing_review_markdown': build_review_markdown(data, status, summary, issues), 'drawing_review_filename': '图纸识别问题确认单_V9.5.xlsx', 'scheme_group_count': len(valid_groups), 'circuit_count': total_circuits, 'component_count': total_components}

def _drawing_prior_main(vision_text, raw_drawing_text=''):
    out = _original_main(vision_text, raw_drawing_text)
    try:
        full = wire_loads(out['validated_drawing_json'])

        def project(value):
            if isinstance(value, list):
                return [project(x) for x in value]
            if isinstance(value, dict):
                return {k: project(v) for k, v in value.items() if k not in ('evidence', 'source_evidence', 'raw_text')}
            return value
        projected = project(full)
        projected['projection_only'] = True
        projected['evidence_in_full_context'] = True
        prompt = plain_json(projected)
        if len(prompt.encode('utf-8')) > 50000:
            prompt = plain_json({'projection_only': True, 'note': '完整图纸较长，语义关联使用自动分批输入；此处仅为摘要', 'scheme_group_count': len(full.get('scheme_groups', []))})
        out['validated_drawing_json'] = wire_pack(full)
        out['drawing_prompt_json'] = prompt
    except CapacityError as exc:
        message = str(exc)
        out.update(drawing_validation_status='NEED_REVIEW', drawing_validation_message=message, drawing_summary=message, validated_drawing_json='{}', drawing_prompt_json='{}', drawing_review_markdown='## 图纸识别问题\n\n| 问题 | 处理 |\n|---|---|\n| ' + message + ' | 按柜号或回路分批重新上传原始资料 |')
    return out
import copy

def compatible_evidence(value):
    if isinstance(value, dict):
        return value
    if not isinstance(value, list):
        return value
    objects = [v for v in value if isinstance(v, dict)]
    proven = [v for v in objects if v.get('page_index') not in (None, '') and clean(v.get('text'))]
    if not proven:
        return value
    first = copy.deepcopy(proven[0])
    first['sources'] = copy.deepcopy(value)
    return first

def normalize_drawing_contract(data):
    data = copy.deepcopy(data)
    if not isinstance(data, dict):
        return {}
    aliases = {'READABLE': 'READABLE', 'READY': 'READABLE', 'VALID': 'READABLE', 'PARTIAL': 'PARTIAL', 'NEED_REVIEW': 'PARTIAL', 'UNREADABLE': 'UNREADABLE', 'INVALID': 'UNREADABLE'}
    old = aliases.get(clean(data.get('recognition_status')).upper())
    new = aliases.get(clean(data.get('extraction_status')).upper())
    if old and new and (old != new):
        data['recognition_status'] = 'UNREADABLE'
        if not isinstance(data.get('warnings'), list):
            data['warnings'] = []
        data.setdefault('warnings', []).append('识别状态字段相互矛盾，需核查模型输出')
    elif old or new:
        data['recognition_status'] = old or new
    for group in data.get('scheme_groups', []) if isinstance(data.get('scheme_groups'), list) else []:
        if not isinstance(group, dict):
            continue
        group['evidence'] = compatible_evidence(group.get('evidence'))
        components = []
        for circuit in group.get('circuits', []) if isinstance(group.get('circuits'), list) else []:
            if not isinstance(circuit, dict):
                continue
            circuit['evidence'] = compatible_evidence(circuit.get('evidence'))
            for item in circuit.get('components', []) if isinstance(circuit.get('components'), list) else []:
                if isinstance(item, dict):
                    item['evidence'] = compatible_evidence(item.get('evidence'))
                    components.append(item)
        direct = group.get('drawing_items', []) if isinstance(group.get('drawing_items'), list) else []
        existing = list(group.get('shown_bom', [])) if isinstance(group.get('shown_bom'), list) else []
        indexed = {clean(r.get('item_id')): r for r in components + existing if isinstance(r, dict) and clean(r.get('item_id'))}
        for item in direct:
            if not isinstance(item, dict):
                continue
            item['evidence'] = compatible_evidence(item.get('evidence'))
            target = indexed.get(clean(item.get('item_id')))
            if target is None:
                existing.append(item)
                if clean(item.get('item_id')):
                    indexed[clean(item['item_id'])] = item
            else:
                differences = any((target.get(k) not in (None, '') and item.get(k) not in (None, '') and (clean(target[k]) != clean(item[k])) for k in ('shown_model', 'quantity_per_cabinet')))
                left = target.get('shown_parameters')
                right = item.get('shown_parameters')
                if isinstance(left, dict) and isinstance(right, dict):
                    differences = differences or any((k in left and left[k] not in (None, '') and (v not in (None, '')) and (clean(left[k]) != clean(v)) for k, v in right.items()))
                if differences:
                    existing.append(item)
                    data.setdefault('_contract_errors', []).append('同一来源编号的型号、数量或参数不一致：' + clean(item.get('item_id')))
                else:
                    for key, value in item.items():
                        if target.get(key) in (None, '', [], {}) and value not in (None, '', [], {}):
                            target[key] = value
                        elif key == 'shown_parameters' and isinstance(value, dict) and isinstance(target.get(key), dict):
                            for k, v in value.items():
                                if k not in target[key]:
                                    target[key][k] = v
        group['shown_bom'] = existing
        for key in ('shown_bom', 'auxiliary_materials', 'wire_requirements'):
            for item in group.get(key, []) if isinstance(group.get(key), list) else []:
                if isinstance(item, dict):
                    item['evidence'] = compatible_evidence(item.get('evidence'))
    return data

def run_drawing_contract(previous, vision_text, raw_drawing_text=''):
    try:
        data = wire_loads(strip_fence(vision_text))
    except (ValueError, TypeError):
        return previous(vision_text, raw_drawing_text)
    out = previous(plain_json(normalize_drawing_contract(data)), raw_drawing_text)
    full = wire_loads(out['validated_drawing_json'])
    if full.get('_contract_errors'):
        messages = '；'.join(full['_contract_errors'])
        out['drawing_validation_status'] = 'NEED_REVIEW'
        out['drawing_validation_message'] += '；' + messages
        out['drawing_review_markdown'] += '\n\n来源一致性问题：' + messages
    full['drawing_validation_status'] = out['drawing_validation_status']
    out['validated_drawing_json'] = wire_pack(full)
    return out

def main__v16_before_1(vision_text, raw_drawing_text=''):
    return run_drawing_contract(_drawing_prior_main, vision_text, raw_drawing_text)

def evidence_proven(value):
    if isinstance(value, list):
        return any((evidence_proven(v) for v in value))
    return isinstance(value, dict) and bool(value.get('text')) and (value.get('source_verified') is True and value.get('document_hash') and value.get('chunk_id') or value.get('page_index') not in (None, ''))

def generic_repair_fragments(items, issues, gid):
    out = []
    for item in items:
        if not isinstance(item, dict):
            continue
        item = copy.deepcopy(item)
        match = None
        source_key = clean(item.get('source_row_key'))
        if source_key:
            match = next((v for v in out if clean(v.get('source_row_key')) == source_key and evidence_signature(v) == evidence_signature(item)), None)
        if match is None:
            out.append(item)
            continue
        for key, value in item.items():
            if match.get(key) in (None, '', [], {}):
                match[key] = value
            elif value not in (None, '', [], {}) and match[key] != value and (key not in ('item_id', 'evidence')):
                issues.append({'severity': 'BLOCKER', 'level': '错误', 'message': gid + '同一来源行内容矛盾：' + source_key + ' ' + key})
    return out

def repair_bom_fragments(items, issues, gid):
    return generic_repair_fragments(items, issues, gid)
_v16_drawing_base = main__v16_before_1

def main(vision_text, raw_drawing_text=''):
    vision_text = wire_pack(preserve_document_facts(wire_loads(strip_fence(vision_text)), 'DRAWING', raw_drawing_text))
    out = _v16_drawing_base(vision_text, raw_drawing_text)
    full = wire_loads(out['validated_drawing_json'])
    errors = list(full.get('_document_errors', []))
    for group in full.get('scheme_groups', []):
        for item in group.get('drawing_items', []):
            if not evidence_proven(item.get('evidence')):
                errors.append('物料缺少可核查的原文：' + clean(item.get('component_role') or item.get('item_id')))
    if errors:
        out['drawing_validation_status'] = 'NEED_REVIEW'
        out['drawing_validation_message'] += '；' + '；'.join(dict.fromkeys(errors))
        report = out['drawing_review_markdown']
        before, sep, after = report.partition('## 已识别方案组')
        extra = '\n'.join(('| 来源-%d | 错误 | %s | 核对原文或补充可读资料 |' % (i + 1, str(e).replace('|', '／').replace('\n', ' ')) for i, e in enumerate(dict.fromkeys(errors))))
        out['drawing_review_markdown'] = before.rstrip() + '\n' + extra + '\n\n' + sep + after
        out['drawing_summary'] += ' 来源完整性问题%d项。' % len(set(errors))
    full['drawing_validation_status'] = out['drawing_validation_status']
    out['validated_drawing_json'] = wire_pack(full)
    return out
import hashlib
import math
import unicodedata

def fact_text(value):
    return unicodedata.normalize('NFKC', str(value or '')).replace('\r', '')

def fact_key(value):
    return re.sub('\\s+', '', fact_text(value)).casefold().replace('×', 'x')

def evidence_leaves(value):
    out = []
    if isinstance(value, list):
        for child in value:
            out.extend(evidence_leaves(child))
    elif isinstance(value, dict):
        if value.get('text'):
            out.append({k: copy.deepcopy(value[k]) for k in ('text', 'document_hash', 'chunk_id', 'source_verified', 'source_start', 'source_end', 'source_spans', 'page_index', 'location') if k in value})
        else:
            for child in value.values():
                if isinstance(child, (dict, list)):
                    out.extend(evidence_leaves(child))
        for child in value.get('sources', []) if isinstance(value.get('sources'), list) else []:
            out.extend(evidence_leaves(child))
    unique = []
    seen = set()
    for row in out:
        key = json.dumps(row, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            unique.append(row)
    return unique

def is_anchored(ev):
    return ev.get('source_verified') is True and bool(ev.get('document_hash')) and bool(ev.get('chunk_id'))

def source_rows(evidence, raw_text=''):
    """Expand a verified citation only to its own source line, never a document scan."""
    raw = str(raw_text or '').replace('\r\n', '\n').replace('\r', '\n')
    digest = hashlib.sha256(raw.encode()).hexdigest() if raw else ''
    rows = []
    for ev in evidence_leaves(evidence):
        if not is_anchored(ev):
            continue
        for line in str(ev['text']).replace('\\n', '\n').splitlines():
            if line.strip():
                rows.append((line.strip(), ev))
        spans = ev.get('source_spans') or ([[ev['source_start'], ev['source_end']]] if isinstance(ev.get('source_start'), int) and isinstance(ev.get('source_end'), int) else [])
        if raw and digest == ev.get('document_hash'):
            for span in spans:
                if not isinstance(span, (list, tuple)) or len(span) != 2:
                    continue
                start, end = span
                if not isinstance(start, int) or not isinstance(end, int) or (not 0 <= start < end <= len(raw)):
                    continue
                if '\n' in raw[start:end]:
                    continue
                a = raw.rfind('\n', 0, start) + 1
                b = raw.find('\n', end)
                if b < 0:
                    b = len(raw)
                row = raw[a:b].strip()
                expanded = dict(ev, text=row, source_start=a, source_end=b, source_spans=[[a, b]])
                if row:
                    rows.append((row, expanded))
    return rows

def item_source_clause(line, model, symbol, role):
    """Select a clause with an explicit item identity; same-model peers stay separate."""
    text = fact_text(line)
    model = fact_text(model).strip()
    symbol = fact_text(symbol).strip()
    clauses = re.split('[;；\\n]', text)
    selected = []
    for clause in clauses:
        if re.search('例如|示例|举例|推荐示意|可选型号', clause):
            continue
        if model and fact_key(model) not in fact_key(clause):
            continue
        if not model:
            if not symbol or not re.search('(?<![A-Za-z0-9_-])' + re.escape(symbol) + '(?![A-Za-z0-9_-])', clause, re.I):
                continue
            if role and fact_key(role) not in fact_key(clause):
                continue
        if model and fact_key(clause).count(fact_key(model)) > 1:
            if not symbol:
                continue
            hits = list(re.finditer('(?<![A-Za-z0-9_-])' + re.escape(symbol) + '(?![A-Za-z0-9_-])', clause, re.I))
            if len(hits) != 1:
                continue
            tail = clause[hits[0].start():]
            next_position = re.search('\\s+[A-Za-z][A-Za-z0-9_-]*\\s*[=:：]', tail[len(symbol):])
            clause = tail[:len(symbol) + next_position.start()] if next_position else tail
            if fact_key(clause).count(fact_key(model)) != 1:
                continue
        if symbol:
            label = re.match('\\s*([A-Za-z][A-Za-z0-9_-]*)\\s*[=:：]', clause)
            if label and label.group(1).casefold() != symbol.casefold():
                continue
        clause = re.sub('(?:不允许|不得|禁止|不能|不采用|不选用|不使用|排除|不含)[^;；。\\n,，]*', '', clause)
        if clause.strip():
            selected.append(clause.strip())
    return selected

def explicit_item_facts(clause, role=''):
    """Small, transparent grammar; unrecognized prose remains in source evidence."""
    text = fact_text(clause)
    facts = []

    def put(field, value):
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        pair = (field, value)
        if pair not in facts:
            facts.append(pair)
    if '断路器' in str(role) or 'MCB' in str(role).upper():
        for m in re.finditer('(?<![A-Z0-9])([BCD])\\s*(\\d{1,3})(?:\\s*A)?(?![A-Z0-9])', text, re.I):
            put('trip_curve', m.group(1).upper())
            put('rated_current_a', int(m.group(2)))
        for m in re.finditer('(?:脱扣(?:特性|曲线)\\s*[:：=为]?\\s*([BCD])|(?<![A-Z0-9])([BCD])\\s*型脱扣)', text, re.I):
            put('trip_curve', next((x for x in m.groups() if x)).upper())
    for m in re.finditer('(?<![A-Za-z0-9])([1-5])\\s*P\\s*(\\+\\s*N)?(?![A-Za-z0-9])', text, re.I):
        put('pole_count', m.group(1) + 'P' + ('+N' if m.group(2) else ''))
    patterns = [('continuous_operating_voltage_v', '(?:\\bUc|最大持续(?:工作|运行)电压)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V)\\b'), ('max_discharge_current_ka', '(?:\\bImax|最大放电电流)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA|A)\\b'), ('nominal_discharge_current_ka', '(?:\\bIn|标称放电电流)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA)\\b'), ('breaking_capacity_ka', '(?:分断能力|\\bIcn|\\bIcu)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA)\\b'), ('rated_current_a', '额定电流\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(A)\\b'), ('rated_voltage_v', '额定(?:工作)?电压\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V)\\b'), ('control_voltage', '(?:线圈电压|控制电压)\\s*[:：=为]?\\s*((?:AC|DC)\\s*\\d+(?:\\.\\d+)?\\s*V)\\b')]
    for field, pattern in patterns:
        for m in re.finditer(pattern, text, re.I):
            if field == 'control_voltage':
                put(field, re.sub('\\s+', '', m.group(1)).upper())
                continue
            number = float(m.group(1))
            unit = m.group(2).lower()
            if field.endswith('_v') and unit == 'kv':
                number *= 1000
            if field.endswith('_ka') and unit == 'a':
                number /= 1000
            put(field, number)
    return facts

def normalize_fact_value(field, value):
    if field in ('trip_curve', 'pole_count', 'control_voltage'):
        return re.sub('\\s+', '', fact_text(value)).upper()
    if isinstance(value, bool):
        return ('invalid', str(value))
    m = re.fullmatch('\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V|kA|A)?\\s*', str(value), re.I)
    if not m:
        return ('text', fact_key(value))
    number = float(m.group(1))
    unit = (m.group(2) or '').lower()
    if field.endswith('_v') and unit == 'kv':
        number *= 1000
    elif field.endswith('_ka') and unit == 'a':
        number /= 1000
    elif unit and unit not in (('v', 'kv') if field.endswith('_v') else ('a', 'ka')):
        return ('invalid', str(value))
    return number

def recover_item_facts(item, parameter_key, raw_text='', extra_evidence=None):
    params = item.setdefault(parameter_key, {})
    if not isinstance(params, dict):
        return ['物料参数不是对象，无法核对来源']
    model = item.get('shown_model') or next((params[k] for k in ('model', 'required_model', 'designated_model', 'specified_model') if params.get(k)), '')
    symbol = item.get('symbol') or params.get('bit_number') or params.get('symbol') or ''
    role = str(item.get('component_role') or item.get('category') or '')
    ledger = list(item.get('parameter_facts') or [])
    values = {}
    errors = []
    evidence = [item.get('evidence'), extra_evidence]
    for line, ev in source_rows(evidence, raw_text):
        for clause in item_source_clause(line, model, symbol, role):
            for field, value in explicit_item_facts(clause, role):
                proof = {k: copy.deepcopy(ev[k]) for k in ('document_hash', 'chunk_id', 'source_verified', 'source_start', 'source_end', 'source_spans', 'page_index', 'location') if k in ev}
                fact = {'field': field, 'value': value, 'source_text': clause, 'source': proof}
                if fact not in ledger:
                    ledger.append(fact)
                values.setdefault(field, [])
                if value not in values[field]:
                    values[field].append(value)
    for field, found in values.items():
        if len({str(normalize_fact_value(field, v)) for v in found}) != 1:
            errors.append('当前物料原文的' + field + '存在不同值：' + str(found))
            continue
        value = found[0]
        if params.get(field) in (None, '', [], {}):
            params[field] = value
        elif normalize_fact_value(field, params[field]) != normalize_fact_value(field, value):
            errors.append('模型参数' + field + '=' + str(params[field]) + '与当前物料原文' + str(value) + '不一致')
    if ledger:
        item['parameter_facts'] = ledger
    return errors

def preserve_document_facts(document, kind, raw_text=''):
    if not isinstance(document, dict):
        return {'scheme_groups': [], '_document_errors': ['提取结果不是JSON对象，不能作为工程资料']}
    document = copy.deepcopy(document)
    errors = document.setdefault('_document_errors', [])
    if not isinstance(errors, list):
        errors = ['来源错误列表格式异常，需检查提取结果']
        document['_document_errors'] = errors

    def finite(value, path):
        if isinstance(value, float) and (not math.isfinite(value)):
            message = '来源字段含非有限数值：' + path
            if message not in errors:
                errors.append(message)
            return str(value)
        if isinstance(value, dict):
            return {key: finite(child, path + '.' + str(key)) for key, child in value.items()}
        if isinstance(value, list):
            return [finite(child, path + '[' + str(index) + ']') for index, child in enumerate(value)]
        return value
    document = finite(document, kind)
    document['_document_errors'] = errors
    if kind == 'PROTOCOL':
        for rule in document.get('component_rules', []) if isinstance(document.get('component_rules'), list) else []:
            if not isinstance(rule, dict):
                continue
            for error in recover_item_facts(rule, 'parameters', raw_text):
                message = str(rule.get('rule_id') or '') + ' ' + str(rule.get('component_role') or '') + '：' + error
                if message not in errors:
                    errors.append(message)
    else:
        for group in document.get('scheme_groups', []) if isinstance(document.get('scheme_groups'), list) else []:
            if not isinstance(group, dict):
                continue
            seen = set()
            for circuit in group.get('circuits', []) if isinstance(group.get('circuits'), list) else []:
                if not isinstance(circuit, dict):
                    continue
                for item in circuit.get('components', []) if isinstance(circuit.get('components'), list) else []:
                    if not isinstance(item, dict):
                        continue
                    seen.add(id(item))
                    for error in recover_item_facts(item, 'shown_parameters', raw_text, circuit.get('evidence')):
                        message = str(item.get('item_id') or '') + '：' + error
                        if message not in errors:
                            errors.append(message)
            for key in ('drawing_items', 'shown_bom', 'auxiliary_materials', 'wire_requirements'):
                for item in group.get(key, []) if isinstance(group.get(key), list) else []:
                    if not isinstance(item, dict) or id(item) in seen:
                        continue
                    seen.add(id(item))
                    for error in recover_item_facts(item, 'shown_parameters', raw_text):
                        message = str(item.get('item_id') or '') + '：' + error
                        if message not in errors:
                            errors.append(message)
    return document
