import json
import re

def parse_model_object(value):
    if isinstance(value, dict):
        return value
    text = re.sub('^```(?:json)?\\s*|\\s*```$', '', str(value or '').strip(), flags=re.I)
    obj = json.loads(text)
    if not isinstance(obj, dict):
        raise ValueError('模型必须返回JSON对象')
    return obj

def bind_advisory(batch_json, model_text):
    batch = json.loads(batch_json) if isinstance(batch_json, str) else batch_json
    if not isinstance(batch, dict) or not batch.get('advisory_id'):
        raise ValueError('程序侧语义关联批次缺少标识')
    try:
        body = dict(parse_model_object(model_text))
        if not isinstance(body.get('component_requirements'), list):
            raise ValueError('未返回需求关联数组')
        for key in ('warnings', 'potential_conflicts'):
            if key in body and (not isinstance(body[key], list)):
                raise ValueError(key + '应为数组')
    except (ValueError, TypeError) as exc:
        body = {'component_requirements': [], 'warnings': [], 'potential_conflicts': [], 'input_problem': '语义关联模型输出结构无法处理：' + str(exc)}
    if batch.get('input_problem'):
        body['input_problem'] = batch['input_problem']
    body['advisory_id'] = batch['advisory_id']
    return {'result_json': json.dumps(body, ensure_ascii=False, separators=(',', ':'), allow_nan=False)}

def main(input_json, model_text):
    return bind_advisory(input_json, model_text)
