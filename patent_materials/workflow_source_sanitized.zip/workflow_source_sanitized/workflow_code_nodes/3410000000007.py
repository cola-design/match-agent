def main(result):
    return {'result': result if isinstance(result, list) else []}
