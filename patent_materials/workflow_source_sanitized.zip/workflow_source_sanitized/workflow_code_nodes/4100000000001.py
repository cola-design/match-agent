import hashlib
import json
CHUNK_CHARS = 10000
OVERLAP_CHARS = 500
MAX_CHUNKS = 40

def jdump(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def document_chunks(text, kind):
    raw = str(text or '').replace('\r\n', '\n').replace('\r', '\n')
    digest = hashlib.sha256(raw.encode()).hexdigest()
    chunks = []
    start = 0
    problem = ''
    if not raw.strip():
        problem = '未提取到可读文字；可能是扫描PDF、图形文字或文件损坏，需OCR/视觉处理后重试'
    while start < len(raw) and len(chunks) < MAX_CHUNKS:
        end = min(start + CHUNK_CHARS, len(raw))
        if end < len(raw):
            boundary = raw.rfind('\n', start + CHUNK_CHARS // 2, end)
            if boundary > start:
                end = boundary + 1
        chunks.append({'chunk_id': '%s-%03d' % (kind, len(chunks) + 1), 'document_hash': digest, 'start': start, 'end': end, 'text': raw[start:end]})
        if end == len(raw):
            break
        start = end - OVERLAP_CHARS
    if chunks and chunks[-1]['end'] != len(raw):
        problem = '资料超过本版40段文本处理预算；本次不处理前半份资料，请按项目或柜号拆分后提交'
        chunks = []
    if not chunks:
        chunks = [{'chunk_id': kind + '-001', 'document_hash': digest, 'start': 0, 'end': 0, 'text': '', 'input_problem': problem}]
    manifest = {'kind': kind, 'document_hash': digest, 'character_count': len(raw), 'input_problem': problem, 'chunks': [{k: v for k, v in c.items() if k != 'text'} for c in chunks]}
    return {'chunks': [jdump(c) for c in chunks], 'manifest': jdump(manifest), 'chunk_count': len(chunks)}

def main(text):
    return document_chunks(text, 'PROTOCOL')
