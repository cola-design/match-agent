import json
import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

def clean(v):
    return '' if v is None else str(v).replace('\u200b', '').replace('\ufeff', '').strip()

def norm(v):
    return re.sub('[^A-Z0-9]', '', clean(v).upper().replace('×', 'X').replace('²', '2'))

def stop(result, status, message):
    result.update(item_status=status, issue=message)

def dec(v):
    try:
        d = Decimal(clean(v).replace('￥', '').replace('¥', '').replace(',', '').replace('%', ''))
        return d if d.is_finite() else None
    except (ValueError, InvalidOperation):
        return None

def count_unit_ok(bom_unit, price_unit, cat):
    if bom_unit == price_unit:
        return (True, '')
    single = {'小型断路器', '小型隔离开关', 'SPD后备保护器', '电涌保护器', '表位支架', '接地排', '铜铝接线鼻', '电缆防水接头', '紧固件', '浪涌保护器', '防雷后备保护器'}
    if cat in single and bom_unit in ('台', '件', '只', '个') and (price_unit in ('台', '件', '只', '个')):
        return (True, '单件计数单位换算（需人工核实）：' + bom_unit + '→' + price_unit)
    if cat == '柜体箱体' and bom_unit == '台' and (price_unit == '套'):
        return (True, '一台柜体按一套计价，须人工核实')
    return (False, '')

def check_category(item, product):
    name = clean(item.get('material_name'))
    cat = clean(product.get('产品类别'))
    expected = (('SPD后备保护器', ('SPD后备保护器', '防雷后备保护器')), ('后备保护器', ('SPD后备保护器', '防雷后备保护器')), ('电涌保护器', ('电涌保护器', '浪涌保护器')), ('浪涌保护器', ('电涌保护器', '浪涌保护器')), ('小型断路器', '小型断路器'), ('小型隔离开关', '小型隔离开关'), ('隔离开关', ('隔离开关', '小型隔离开关')), ('表位支架', '表位支架'), ('接线鼻', '铜铝接线鼻'), ('防水接头', '电缆防水接头'), ('接地排', '接地排'), ('膨胀螺栓', '紧固件'), ('膨胀螺丝', '紧固件'), ('柜体', '柜体箱体'))
    for keyword, category in expected:
        if keyword in name and cat not in (category if isinstance(category, tuple) else (category,)):
            return 'BOM元器件类别与产品库类别不一致：' + name + ' → ' + cat
    return ''

def check_model(model, product):
    """Only explicit model information can be verified; no semantic substitution."""
    description = clean(product['物料描述'])
    expected = clean(model)
    if not expected:
        return '确认型号为空'
    tokens = re.findall('[A-Za-z]+[A-Za-z0-9]*[\\-_/×x]?[A-Za-z0-9]+(?:[\\-_/×x][A-Za-z0-9]+)*', expected)
    for token in tokens:
        nt = norm(token)
        if len(nt) >= 4 and nt not in norm(description):
            return '确认型号片段与产品描述不一致：' + token
    if re.fullmatch('\\d{2,4}', expected):
        if not re.search('(?<!\\d)' + re.escape(expected) + '(?!\\d)', description):
            return '纯数字规格代号与产品描述不一致：' + expected
    if re.search('\\b[1-4]P\\b', expected, re.I):
        exp = re.search('\\b([1-4])P\\b', expected, re.I).group(1)
        poles = re.search('极数\\s*=\\s*([1-4])P', clean(product['规格参数']), re.I)
        if poles and poles.group(1) != exp:
            return '确认型号极数与产品规格不一致'
    return ''

def evaluate_system_voltage(spec, product):
    """Return (action, note). REVIEW denotes no verified voltage rating.

    This workflow uses ACTIVE records from the formal price library; REVIEW is preserved
    in line remarks and summary. Explicit component rated-voltage data gaps
    cannot be silently treated as electrical compliance.
    """
    req = clean(spec)
    param = clean(product.get('规格参数'))
    cat = clean(product.get('产品类别'))
    wants = re.search('(?:额定工作电压|工作电压|系统电压|电网电压|交流电压)\\s*[:：=]?\\s*(?:AC\\s*)?(3[68]0|400|415)\\s*V', req, re.I)
    if not wants:
        return ('NOT_APPLICABLE', '')
    requested = int(wants.group(1))
    require_rated = bool(re.search('额定工作电压\\s*[:：=]?\\s*(?:AC\\s*)?' + str(requested) + '\\s*V', req, re.I))
    if cat in ('电涌保护器', '浪涌保护器'):
        return ('REVIEW', '系统' + str(requested) + 'V与SPD的Uc和接线方式需工程核实；不得以Uc直接当额定工作电压')
    matched = re.search('(?:额定工作电压|工作电压)\\s*=\\s*(AC|DC)?\\s*((?:\\d{2,4}\\s*/\\s*)*\\d{2,4})\\s*V\\b', param, re.I)
    if not matched:
        if require_rated:
            return ('UNVERIFIED_EXPLICIT', '元器件明确要求额定工作电压' + str(requested) + 'V，但原始PRODUCT无可验证的额定电压')
        return ('REVIEW', '系统' + str(requested) + 'V；PRODUCT没有该产品额定工作电压证据，需工程师查产品样本核实')
    acdc = (matched.group(1) or '').upper()
    nums = [int(x) for x in re.findall('\\d{2,4}', matched.group(2))]
    if acdc == 'DC':
        return ('MISMATCH', '需求交流系统' + str(requested) + 'V，产品记录明确为DC额定，须核实是否有交流额定值')
    if acdc == 'AC' and nums and (max(nums) >= requested):
        return ('VERIFIED_BY_RECORD', 'PRODUCT载明' + matched.group(0) + '；按额定交流电压容量覆盖系统' + str(requested) + 'V作材料参考报价，最终适用性待厂家样本确认')
    if acdc == 'AC' and nums and (max(nums) < requested):
        return ('MISMATCH', '系统' + str(requested) + 'V，产品额定工作电压仅' + matched.group(0))
    return ('REVIEW', 'PRODUCT电压记录缺少AC/DC制式，不能直接判定系统' + str(requested) + 'V适用性')

def check_specs(spec, product):
    """Verify key explicit machine-checkable requirements; defer others to engineer."""
    original_text = clean(spec)
    text = re.sub('(?:不允许|不得|禁止|不能|不采用|不选用|不使用|排除|不含)[^;；。\\n,，]*', '', original_text)
    if not original_text:
        return ''
    if '电压参数含义待确认' in text:
        return 'SPD电压参数含义未明确，不能报价'
    desc = clean(product['物料描述'])
    param = clean(product['规格参数'])
    alltxt = desc + ' ' + param
    m = re.search('(?<![A-Z0-9])([1-4])\\s*P(?![A-Z0-9])', text, re.I)
    if m:
        pm = re.search('极数\\s*=\\s*([1-4])\\s*P', param, re.I)
        if pm and pm.group(1) != m.group(1):
            return '关键参数极数不符：要求' + m.group(1) + 'P，产品' + pm.group(1) + 'P'
        if not pm and (not re.search('(?<![A-Z0-9])' + m.group(1) + '\\s*P(?![A-Z0-9])', alltxt, re.I)):
            return '无法证实关键参数极数' + m.group(1) + 'P'
    curve = re.search('(?<![A-Z0-9])([BCD])\\s*型\\s*(?:脱扣|曲线)?', text, re.I)
    if curve:
        actual = re.search('脱扣特性\\s*=\\s*([BCD])\\b', param, re.I)
        if actual and curve.group(1).upper() != actual.group(1).upper():
            return '脱扣特性不符：要求' + curve.group(1).upper() + '型，产品' + actual.group(1).upper() + '型'
        if not actual and (not re.search('(?<![A-Z0-9])' + curve.group(1) + '\\d{1,3}(?![A-Z0-9])', desc, re.I)):
            return '无法核实要求的' + curve.group(1).upper() + '型脱扣特性'
    trip = re.search('(?<![A-Z0-9])([BCD])\\s*(\\d{1,3})(?![A-Z0-9])', text, re.I)
    if trip:
        characteristic, current = (trip.group(1).upper(), trip.group(2))
        t = re.search('脱扣特性\\s*=\\s*([BCD])\\b', param, re.I)
        rated = re.search('额定电流\\s*=\\s*(\\d+(?:\\.\\d+)?)\\s*A', param, re.I)
        if t and t.group(1).upper() != characteristic:
            return '脱扣特性不符：要求' + characteristic + '，产品' + t.group(1)
        if rated and Decimal(rated.group(1)) != Decimal(current):
            return '额定电流不符：要求' + current + 'A，产品' + rated.group(1) + 'A'
        if not t and norm(characteristic + current) not in norm(desc):
            return '无法核实脱扣曲线与电流' + characteristic + current
    currents = re.findall('(?<![A-Za-z0-9])([1-9]\\d{1,3})\\s*A(?![A-Za-z0-9])', text, re.I)
    if currents:
        rated = re.search('额定电流\\s*=\\s*(\\d+(?:\\.\\d+)?)\\s*A', param, re.I)
        for c in currents:
            if rated:
                minimum = bool(re.search('额定电流最低要求\\s*[:：=]?\\s*' + re.escape(c) + '\\s*A', text, re.I))
                if Decimal(rated.group(1)) < Decimal(c) if minimum else Decimal(rated.group(1)) != Decimal(c):
                    return '关键参数额定电流不符：要求' + c + 'A，产品' + rated.group(1) + 'A'
            elif not re.search('(?<!\\d)' + c + '\\s*A(?!\\w)', desc, re.I):
                return '无法核实关键参数额定电流' + c + 'A'
    uc_req = re.search('(?:Uc|最大持续工作电压|最大持续运行电压|持续运行电压)\\s*[:：=]?\\s*(\\d{2,4})\\s*V', text, re.I)
    if uc_req:
        uc_known = re.search('最大持续工作电压\\s*=\\s*(\\d+(?:\\.\\d+)?)\\s*V?', param, re.I)
        if not uc_known:
            return '无法核实浪涌保护器最大持续工作电压Uc' + uc_req.group(1) + 'V（须核实专用参数，不能用系统电压代替）'
        if Decimal(uc_known.group(1)) != Decimal(uc_req.group(1)):
            return 'Uc不符：需求' + uc_req.group(1) + 'V，产品' + uc_known.group(1) + 'V'
    if re.search('禁止附件[^；;\\n]*辅助触点|无附加触点|无辅助触点', original_text) and re.search('(?<![A-Z])OF\\d*|配[^;；]*辅助触|带[^;；]*辅助触', alltxt, re.I):
        return '原始要求禁止辅助触点，最终产品带附加触点，请重新选型'
    for label in ('标称放电电流', '最大放电电流'):
        demand = re.search(label + '(?:In|Imax)?\\s*[:：=]\\s*(\\d+(?:\\.\\d+)?)\\s*kA', text, re.I)
        if demand:
            known = re.search(label + '\\s*(?:[（(]\\s*kA\\s*[）)])?\\s*[:=：]\\s*(\\d+(?:\\.\\d+)?)\\s*kA', param, re.I)
            if not known:
                return '无法核实' + label + '专用参数，不能用其他kA数值代替'
            if Decimal(known.group(1)) < Decimal(demand.group(1)):
                return label + '低于明确要求'
    demand = re.search('试验类别\\s*[:：=]\\s*([^；;\\n]+)', text)
    if demand:
        known = re.search('试验(?:分类|类型|类别)\\s*[:：=]\\s*([^；;\\n]+)', param)
        canon = lambda s: clean(s).upper().replace('类', '').replace('Ⅱ', 'II')
        if not known or canon(known.group(1)) != canon(demand.group(1)):
            return '试验类别未证实或不符'
    ratings = re.findall('(?<![A-Za-z0-9])([1-9]\\d*(?:\\.\\d+)?)\\s*kA(?![A-Za-z0-9])', text, re.I)
    for rating in ratings:
        if not re.search('(?<!\\d)' + re.escape(rating) + '\\s*kA(?![A-Za-z0-9])', alltxt, re.I):
            return '不能核实关键参数' + rating + 'kA'
    pair_kas = re.findall('(?<![A-Za-z0-9])([1-9]\\d*)\\s*/\\s*([1-9]\\d*)\\s*kA', text, re.I)
    for a, b in pair_kas:
        for num in (a, b):
            if not re.search('(?<!\\d)' + re.escape(num) + '\\s*kA(?![A-Za-z0-9])', alltxt, re.I):
                return '不能核实标称/最大放电电流' + num + 'kA'
    for count in re.findall('(?<!\\d)([1-9]\\d?)\\s*孔', text):
        if not re.search('(?<!\\d)' + count + '\\s*孔', alltxt):
            return '接地排孔数与要求不一致：' + count + '孔'
    for protection in re.findall('\\bIP\\s*\\d{2}\\b', text, re.I):
        if norm(protection) not in norm(alltxt):
            return '防护等级不符：要求' + protection
    if re.search('(?<![A-Z0-9])([BCD])(\\d{2,3})(?![A-Z0-9])', text, re.I) and '断路器' not in clean(product['产品类别']):
        return '要求脱扣曲线，但产品类别不是断路器'
    return ''
PRODUCT_FIELDS = ('物料编码', '物料描述', '产品类别', '产品系列', '规格参数', '状态', '数据质量')
PRICE_FIELDS = ('物料编码', '物料描述', '产品类别', '未税单价', '计价单位', '税率', '有效期', '价格版本', '审批状态')
CODE_RE = re.compile('物料编码\\s*[:：]\\s*([A-Z][A-Z0-9_-]{5,}|\\d{8,16})(?![A-Z0-9_-])', re.I)

def doc_texts(value):
    """Only interpret document body text; never mistake retrieval metadata for a record."""
    if isinstance(value, str):
        if value.strip().startswith(('[', '{')):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, (dict, list)):
                    return doc_texts(parsed)
            except (ValueError, TypeError):
                pass
        return [value] if value.strip() else []
    if isinstance(value, list):
        out = []
        for x in value:
            out.extend(doc_texts(x))
        return out
    if isinstance(value, dict):
        for k in ('content', 'text', 'page_content'):
            if isinstance(value.get(k), str) and value[k].strip():
                return [value[k]]
        for k in ('result', 'results', 'documents', 'chunks', 'data'):
            if k in value:
                return doc_texts(value[k])
    return []

def extract_field(block, key, fields):
    """Read the named field only inside one material record, not the next record."""
    all_labels = '|'.join((re.escape(x) for x in fields))
    m = re.search('(?:^|\\s)' + re.escape(key) + '\\s*[:：]\\s*', block, re.I)
    if not m:
        return ''
    rest = block[m.end():]
    nxt = re.search('(?:^|\\s)(?:' + all_labels + ')\\s*[:：]', rest, re.I)
    value = rest[:nxt.start()] if nxt else rest
    value = re.split('(?:\\n\\s*#{1,6}\\s*(?:PRODUCT|PRICE)\\b|\\n\\s*---\\s*$)', value, 1, flags=re.I | re.M)[0]
    value = re.sub('\\s+', ' ', value).strip()
    value = re.sub('(?:\\s+#{0,6}\\s*(?:PRICE|PRODUCT)|\\s+---)\\s*$', '', value, flags=re.I).strip()
    return value

def parse_records(value, fields):
    """Exact-code record extraction from any Dify retrieval hit; never join adjacent codes."""
    out = []
    for raw in doc_texts(value):
        text = raw.replace('**', '').replace('＃', '')
        matches = list(CODE_RE.finditer(text))
        for i, m in enumerate(matches):
            block = text[m.start():matches[i + 1].start() if i + 1 < len(matches) else len(text)]
            row = {'物料编码': m.group(1).upper()}
            for k in fields[1:]:
                row[k] = extract_field(block, k, fields)
            if row.get('物料描述') and (row.get('规格参数') if fields == PRODUCT_FIELDS else row.get('未税单价')):
                out.append(row)
    return out

def explicit_trip_requirements(value):
    curves = set()
    currents = set()
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in ('forbidden_models', 'excluded_models', 'prohibited_models', 'forbidden_accessories'):
                continue
            if key in ('trip_curve', 'tripping_curve', '脱扣曲线', '脱扣特性'):
                text = clean(child).upper()
                if text in ('B', 'C', 'D'):
                    curves.add(text)
            c, a = explicit_trip_requirements(child)
            curves.update(c)
            currents.update(a)
        return (curves, currents)
    if isinstance(value, (list, tuple)):
        for child in value:
            c, a = explicit_trip_requirements(child)
            curves.update(c)
            currents.update(a)
        return (curves, currents)
    text = clean(value).upper()
    text = re.sub('(?:不允许|不得|禁止|不能|不采用|不选用|不使用|排除|不含)[^;；。\\n,，]*', '', text)
    for match in re.finditer('(?<![A-Z0-9])([BCD])\\s*(\\d{1,3})(?:\\s*A)?(?![A-Z0-9])', text):
        curves.add(match.group(1))
        currents.add(int(match.group(2)))
    for match in re.finditer('(?:脱扣(?:特性|曲线)|TRIP_CURVE|TRIPPING_CURVE)\\s*[:：=为]?\\s*([BCD])(?![A-Z0-9/／])|(?<![A-Z0-9/／])([BCD])\\s*型?\\s*脱扣', text):
        curves.add(next((x for x in match.groups() if x)))
    return (curves, currents)

def trip_mismatch(requirement, product):
    wanted_curves, wanted_currents = explicit_trip_requirements(requirement)
    actual_curves, actual_currents = explicit_trip_requirements(product)
    if len(wanted_curves) > 1 or len(wanted_currents) > 1:
        return '需求中的脱扣特性或对应电流存在冲突，请核实原始资料，不能直接采用'
    if wanted_curves:
        if len(actual_curves) != 1:
            return '产品记录或确认型号未唯一证实所要求的脱扣特性：' + '/'.join(sorted(wanted_curves))
        if wanted_curves != actual_curves:
            return '脱扣特性不一致：要求' + '/'.join(sorted(wanted_curves)) + '型，当前为' + '/'.join(sorted(actual_curves)) + '型；请更正型号及对应物料编码'
    if wanted_currents and actual_currents and (wanted_currents != actual_currents):
        return '脱扣型号额定电流不一致：要求%sA，当前%sA' % (sorted(wanted_currents), sorted(actual_currents))
    return ''

def main(item_json, material_code, product_result, price_result, primary_product_result, primary_price_result, product_gate, price_gate):
    product_retry_result = []
    price_retry_result = []
    try:
        item = json.loads(item_json) if isinstance(item_json, str) else item_json if isinstance(item_json, dict) else {}
    except (ValueError, TypeError):
        item = {}
    code = clean(material_code or item.get('material_code')).upper()
    result = dict(item)
    result.update(material_code=code, item_status='PRICED', issue='', price_source='', product_source='')
    if not re.fullmatch('(?:\\d{8,16}|[A-Z][A-Z0-9_-]{5,})', code):
        stop(result, 'INVALID_CODE', 'BOM物料编码为空或格式不合法')
    result['product_retrieval_hits'] = len(doc_texts(product_result)) + len(doc_texts(product_retry_result))
    result['price_retrieval_hits'] = len(doc_texts(price_result)) + len(doc_texts(price_retry_result))
    result['product_exact_primary_hits'] = sum((p['物料编码'] == code for p in parse_records(primary_product_result, PRODUCT_FIELDS)))
    result['product_exact_retry_hits'] = sum((p['物料编码'] == code for p in parse_records(product_retry_result, PRODUCT_FIELDS)))
    result['price_exact_primary_hits'] = sum((p['物料编码'] == code for p in parse_records(primary_price_result, PRICE_FIELDS)))
    result['price_exact_retry_hits'] = sum((p['物料编码'] == code for p in parse_records(price_retry_result, PRICE_FIELDS)))
    result['product_primary_retrieval_hits'] = len(doc_texts(primary_product_result))
    result['price_primary_retrieval_hits'] = len(doc_texts(primary_price_result))
    result['product_retry_executed'] = product_gate == 'MISS'
    result['price_retry_executed'] = price_gate == 'MISS'
    result['product_exact_selected_hits'] = sum((p['物料编码'] == code for p in parse_records(product_result, PRODUCT_FIELDS)))
    result['price_exact_selected_hits'] = sum((p['物料编码'] == code for p in parse_records(price_result, PRICE_FIELDS)))
    result['product_exact_retry_hits'] = result['product_exact_selected_hits'] if result['product_retry_executed'] else 0
    result['price_exact_retry_hits'] = result['price_exact_selected_hits'] if result['price_retry_executed'] else 0
    result['product_returned_codes'] = list(dict.fromkeys((p['物料编码'] for p in parse_records(product_result, PRODUCT_FIELDS))))
    result['product_returned_documents'] = list(dict.fromkeys((clean(x.get('title')) for x in product_result or [] if isinstance(x, dict) and clean(x.get('title')))))
    if result['item_status'] == 'PRICED':
        candidates = [p for p in parse_records(product_result, PRODUCT_FIELDS) + parse_records(product_retry_result, PRODUCT_FIELDS) if p['物料编码'] == code]
        signatures = {tuple((p.get(k, '') for k in ('物料描述', '产品类别', '规格参数', '状态'))) for p in candidates}
        if len(signatures) > 1:
            stop(result, 'PRODUCT_CONFLICT', '实时PRODUCT检索同码出现不同产品描述或规格，不能以离线备援覆盖冲突')
        elif candidates:
            product = candidates[0]
            result['product_source'] = 'PRODUCT_API'
        else:
            stop(result, 'PRODUCT_NOT_RETRIEVED', '本次产品检索未命中编码%s（%s）；备用检索%s。最终返回编码：%s。请在产品库搜索该编码，核对原始产品段是否可用；系统未用价格记录或离线快照替代产品证据' % (code, clean(item.get('model_spec')), '已执行' if result['product_retry_executed'] else '未执行', '、'.join(result['product_returned_codes'][:5]) or '未解析到编码'))
    if result['item_status'] == 'PRICED':
        if not product.get('状态') or any((x in product['状态'] for x in ('停用', '禁用', '冻结', '停产', '淘汰', '作废'))):
            stop(result, 'PRODUCT_UNAVAILABLE', '产品状态缺失或不可用：' + clean(product.get('状态')))
        elif any((x in product['状态'] for x in ('待核实', '待确认', '待审核'))) or code.startswith('TMP-'):
            result['technical_review_required'] = True
            result['technical_review_notes'] = ['产品状态为' + clean(product.get('状态')) + '或为临时物料编码，须工程师/采购核实，当前仅可作为正式价格库材料报价']
    if result['item_status'] == 'PRICED':
        e = check_category(item, product)
        if e:
            stop(result, 'CATEGORY_MISMATCH', e)
    if result['item_status'] == 'PRICED':
        e = check_model(item.get('model_spec'), product)
        if e:
            stop(result, 'MODEL_SPEC_MISMATCH', e)
    if result['item_status'] == 'PRICED':
        try:
            typed = json.loads(item.get('requirements_json') or '{}')
            if not isinstance(typed, dict):
                raise ValueError('原始要求不是对象')
        except (ValueError, TypeError):
            typed = {}
            stop(result, 'TECH_SPEC_MISMATCH', '原始结构化技术要求损坏，不能跳过校验')
        extension_conflicts, extension_warnings = extension_product_checks(typed, product)
        if extension_conflicts:
            stop(result, 'TECH_SPEC_MISMATCH', '；'.join(extension_conflicts))
        e = trip_mismatch(item.get('key_technical_parameters'), product.get('规格参数', '') + ' ' + product.get('物料描述', ''))
        if not e:
            e = check_specs(item.get('key_technical_parameters'), product)
        if e:
            stop(result, 'TECH_SPEC_MISMATCH', e)
        if result['item_status'] == 'PRICED':
            voltage_state, voltage_note = evaluate_system_voltage(item.get('key_technical_parameters'), product)
            result['voltage_check_status'] = voltage_state
            if voltage_note:
                result['voltage_check_note'] = voltage_note
            if voltage_state == 'MISMATCH':
                stop(result, 'TECH_SPEC_MISMATCH', voltage_note)
            elif voltage_state == 'UNVERIFIED_EXPLICIT':
                stop(result, 'VOLTAGE_RATING_UNVERIFIED', voltage_note)
            elif voltage_state == 'REVIEW':
                result['technical_review_required'] = True
                result.setdefault('technical_review_notes', []).append(voltage_note)
    if result['item_status'] == 'PRICED':
        found = [p for p in parse_records(price_result, PRICE_FIELDS) + parse_records(price_retry_result, PRICE_FIELDS) if p['物料编码'] == code]
        result['price_exact_code_records'] = len(found)
        signatures = {tuple((re.sub('\\s+', ' ', clean(p.get(k, ''))) for k in PRICE_FIELDS)) for p in found}
        if len(signatures) > 1:
            stop(result, 'PRICE_CONFLICT', 'PRICE实时检索同码存在不同价/版本/单位/有效期，不自动选价')
        elif not found:
            stop(result, 'PRICE_NOT_RETRIEVED', 'PRICE主检索和备用检索均未返回完整的精确编码价格；请检查两个PRICE节点的库绑定、索引、分段及命中详情；不得猜测价格')
        else:
            price = found[0]
            if not all((clean(price.get(x)) for x in PRICE_FIELDS if x != '物料描述')):
                stop(result, 'PRICE_FIELD_MISSING', 'PRICE知识库中此编码的必填字段缺失')
            result['price_source'] = 'PRICE_API'
            if result['item_status'] == 'PRICED' and ((clean(price.get('物料描述')) and clean(price.get('物料描述')) != clean(product.get('物料描述'))) or clean(price.get('产品类别')) != clean(product.get('产品类别'))):
                stop(result, 'PRODUCT_PRICE_CONFLICT', '检索到的PRICE描述或类别与产品记录不一致，请检查知识库版本')
    if result['item_status'] == 'PRICED':
        unit = price['计价单位']
        bom_unit = clean(item.get('unit'))
        unit_ok, note = count_unit_ok(bom_unit, unit, product['产品类别'])
        amount = dec(price['未税单价'])
        taxraw = price['税率']
        tax = dec(taxraw)
        rate = tax / Decimal('100') if tax is not None and '%' in taxraw else tax
        if amount is None or amount <= 0:
            stop(result, 'PRICE_INVALID', '正式价格库未税单价无效')
        elif rate is None or not Decimal('0') <= rate <= Decimal('1'):
            stop(result, 'TAX_INVALID', '税率格式或数值无效')
        elif price['审批状态'].upper() not in ('ACTIVE', '有效'):
            stop(result, 'PRICE_APPROVAL_MISMATCH', '正式价格库记录不是ACTIVE状态')
        elif not unit:
            stop(result, 'UNIT_MISSING', 'PRICE计价单位缺失')
        elif bom_unit and (not unit_ok):
            stop(result, 'UNIT_MISMATCH', 'BOM单位' + bom_unit + '不能与价格单位' + unit + '安全对应')
        else:
            mm = re.fullmatch('(\\d{4}-\\d{2}-\\d{2})\\s*至\\s*(\\d{4}-\\d{2}-\\d{2})', price['有效期'])
            if not mm:
                stop(result, 'PRICE_VALIDITY_UNKNOWN', 'PRICE有效期缺少起止日期')
            else:
                try:
                    start = datetime.strptime(mm.group(1), '%Y-%m-%d').date()
                    end = datetime.strptime(mm.group(2), '%Y-%m-%d').date()
                    if not start <= datetime.now(timezone(timedelta(hours=8))).date() <= end:
                        stop(result, 'PRICE_EXPIRED', 'PRICE正式价格未生效或已过期：' + price['有效期'])
                except ValueError:
                    stop(result, 'PRICE_INVALID', 'PRICE有效期日期非法')
    if result['item_status'] == 'PRICED':
        result.update(material_name=clean(item.get('material_name')) or product['物料描述'], category=price['产品类别'], pricing_unit=unit, unit_price_ex_tax=float(amount), tax_rate=float(rate), price_version=price['价格版本'], approval_status='ACTIVE', price_basis=price.get('价格依据') or 'MARKET_REFERENCE_ESTIMATE', reference_only=False, price_validity=price['有效期'], unit_conversion_note=note, product_status=product['状态'], product_description=product['物料描述'])
    return {'quote_item_json': json.dumps(result, ensure_ascii=False), 'item_status': result['item_status'], 'material_code': code}
import unicodedata

def product_field_token(value):
    return re.sub('[\\s_()（）²]+', '', unicodedata.normalize('NFKC', str(value or ''))).casefold()

def product_attribute_map(record):
    attrs = record.get('规格参数') or ''
    if isinstance(attrs, dict):
        return {product_field_token(k): v for k, v in attrs.items()}
    result = {}
    for part in re.split('[;；\\n]', str(attrs)):
        m = re.match('\\s*([^=:：]{1,45})\\s*[=:：]\\s*(.+?)\\s*$', part)
        if m:
            result[product_field_token(m.group(1))] = m.group(2)
    for k, v in record.items():
        if v not in (None, '', [], {}):
            result.setdefault(product_field_token(k), v)
    materials = re.findall('(?<!\\d)(201|304|316L?)\\s*不锈钢', str(record.get('物料描述') or ''), re.I)
    if len(set(materials)) == 1:
        result.setdefault(product_field_token('材质'), materials[0] + '不锈钢')
    return result

def extension_product_checks(requirements, record):
    attrs = product_attribute_map(record)
    conflicts = []
    warnings = []
    fields = {'control_voltage': ('控制/线圈电压', ('控制电压', '线圈电压', 'control_voltage'), 'voltage'), 'leakage_current_ma': ('漏电动作电流', ('额定剩余动作电流', '漏电动作电流', '剩余动作电流', 'leakage_current_ma'), 'ma'), 'material': ('材质', ('材质', '柜体材质', 'material'), 'material'), 'thickness_mm': ('板厚', ('板厚', '柜体板厚', '厚度', 'thickness_mm'), 'mm'), 'cross_section_mm2': ('截面积', ('截面积', '导体截面', 'cross_section_mm2'), 'mm2'), 'color': ('颜色', ('颜色', '表面颜色', 'color'), 'text'), 'installation_mode': ('安装方式', ('安装方式', 'installation_mode'), 'text'), 'operation_mode': ('操作方式', ('操作方式', 'operation_mode'), 'text')}

    def atom(value, kind):
        text = unicodedata.normalize('NFKC', str(value or '')).strip().upper().replace(' ', '')
        if kind == 'material':
            found = set(re.findall('(?<!\\d)(201|304|316L?)(?!\\d)', text))
            return next(iter(found)) if len(found) == 1 else None
        if kind == 'voltage':
            m = re.fullmatch('(AC|DC)?([0-9.]+)(KV|V)?', text)
            return (m.group(1) or '', float(m.group(2)) * (1000 if m.group(3) == 'KV' else 1)) if m else None
        if kind in ('ma', 'mm', 'mm2'):
            m = re.fullmatch('([0-9.]+)(MA|A|MM|MM2|平方毫米)?', text)
            if not m:
                return None
            unit = m.group(2) or ''
            if kind == 'ma' and unit not in ('', 'MA', 'A'):
                return None
            if kind == 'mm' and unit not in ('', 'MM'):
                return None
            if kind == 'mm2' and unit not in ('', 'MM2', '平方毫米'):
                return None
            return float(m.group(1)) * (1000 if kind == 'ma' and unit == 'A' else 1)
        return text
    for field, (label, aliases, kind) in fields.items():
        wanted = requirements.get(field)
        if wanted in (None, '', [], {}):
            continue
        known = next((attrs[product_field_token(k)] for k in aliases if product_field_token(k) in attrs), None)
        if known is None:
            warnings.append('候选记录未证实' + label + '，需工程师核验')
            continue
        left, right = (atom(wanted, kind), atom(known, kind))
        if left is None or right is None:
            warnings.append(label + '文字无法自动等同，需工程师核验')
            continue
        if kind == 'voltage':
            different = left[1] != right[1] or bool(left[0] and right[0] and (left[0] != right[0]))
            if left[0] and (not right[0]):
                warnings.append('候选记录未证实控制电压的AC/DC类型')
        else:
            different = left != right
        if different:
            if kind == 'text':
                warnings.append(label + '描述不同，需工程师核验：' + str(wanted) + ' / ' + str(known))
            else:
                conflicts.append(label + '不一致：要求' + str(wanted) + '，候选' + str(known))

    def model_atom(value):
        value = unicodedata.normalize('NFKC', str(value or '')).upper().replace('×', 'X')
        return re.sub('[^A-Z0-9\\u4e00-\\u9fff]', '', value)
    for field in ('model', 'required_model', 'designated_model', 'specified_model'):
        wanted = requirements.get(field)
        if not wanted:
            continue
        description = model_atom(record.get('物料描述'))
        parts = [model_atom(part) for part in re.split('\\s+', str(wanted)) if model_atom(part)]
        if parts and (not all((part in description for part in parts))):
            conflicts.append('文件指定型号与产品记录不一致：' + str(wanted))
    brands = requirements.get('brand_constraints') or []
    if brands:
        known = next((attrs[product_field_token(k)] for k in ('品牌', '制造商', '产品品牌', 'brand') if product_field_token(k) in attrs), None)
        if known is None:
            warnings.append('候选记录未证实品牌，需工程师核验')
        elif not any((product_field_token(b) in product_field_token(known) for b in brands)):
            conflicts.append('品牌不符合资料限定范围')
    leakage = requirements.get('leakage_required')
    if isinstance(leakage, bool):
        known = next((attrs[product_field_token(k)] for k in ('漏电保护', '漏电功能', 'leakage_required') if product_field_token(k) in attrs), None)
        token = str(known or '').strip().lower()
        actual = True if token in ('是', '有', '带', 'true', '1') else False if token in ('否', '无', '不带', 'false', '0') else None
        if actual is None:
            warnings.append('候选记录未证实漏电保护功能，需工程师核验')
        elif actual != leakage:
            conflicts.append('漏电保护功能与明确要求不一致')
    for field, label in [('required_accessories', '必需附件')]:
        if requirements.get(field) not in (None, '', [], {}, False):
            warnings.append(label + '需工程师核验，系统未自动证明')
    return (conflicts, warnings)


# V18 MongoDB document adapters. PRODUCT/PRICE retrieval may return JSON documents
# from the formal MongoDB-backed Dify datasets; legacy Markdown remains supported.
def _v18_iter_objects(value):
    if isinstance(value, dict):
        if value.get('material_code') or value.get('物料编码'):
            yield value
            return
        for key in ('content', 'text', 'page_content', 'body', 'items', 'result', 'results', 'documents', 'chunks', 'data'):
            if key in value:
                yield from _v18_iter_objects(value[key])
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            yield from _v18_iter_objects(item)
        return
    if isinstance(value, str):
        text = value.strip()
        if text.startswith(('{', '[')):
            try:
                yield from _v18_iter_objects(json.loads(text))
                return
            except (ValueError, TypeError):
                pass
        yield value

def _v18_category(obj):
    c = obj.get('category') or {}
    if isinstance(c, dict):
        return str(c.get('middle') or c.get('root') or c.get('leaf') or '').strip(), str(c.get('leaf') or '').strip()
    return str(c).strip(), ''

def _v18_specs(obj):
    text = obj.get('specification_text') or ''
    if text:
        return str(text)
    specs = obj.get('standard_specs') or {}
    parts = []
    if isinstance(specs, dict):
        for key, val in specs.items():
            if isinstance(val, dict):
                value = val.get('value_text') or val.get('value_num') or ''
                unit = val.get('unit') or ''
                parts.append(str(val.get('raw_name') or key) + '=' + str(value) + str(unit))
            elif val not in (None, ''):
                parts.append(str(key) + '=' + str(val))
    attrs = obj.get('source_attributes') or []
    if isinstance(attrs, list):
        for attr in attrs:
            if isinstance(attr, dict) and attr.get('name') and attr.get('value') not in (None, ''):
                parts.append(str(attr['name']) + '=' + str(attr['value']))
    return '；'.join(dict.fromkeys(parts))

def _v18_product(obj):
    code = str(obj.get('material_code') or obj.get('物料编码') or '').strip().upper()
    if not code:
        return None
    if 'material_code' in obj:
        if str(obj.get('data_status') or '').upper() != 'ACTIVE':
            return None
        if str(obj.get('source_status') or '').strip() not in ('有效', 'ACTIVE', '在售'):
            return None
        category, series = _v18_category(obj)
        quality = '；'.join(str(x) for x in (obj.get('quality_flags') or []) if x)
        return {'物料编码': code, '物料描述': str(obj.get('description') or '').strip(),
                '产品类别': category, '产品系列': series, '规格参数': _v18_specs(obj),
                '状态': 'ACTIVE', '数据质量': quality or 'source_status=有效; data_status=ACTIVE'}
    return None

def _v18_price(obj):
    code = str(obj.get('material_code') or obj.get('物料编码') or '').strip().upper()
    if not code:
        return None
    if 'material_code' in obj:
        if str(obj.get('status') or '').upper() != 'ACTIVE':
            return None
        category = str(obj.get('category') or '').strip()
        start = str(obj.get('valid_from') or '')[:10]
        end = str(obj.get('valid_to') or '')[:10]
        return {'物料编码': code, '物料描述': '', '产品类别': category,
                '未税单价': str(obj.get('unit_price_ex_tax') or ''),
                '计价单位': str(obj.get('pricing_unit') or ''),
                '税率': str(obj.get('tax_rate') if obj.get('tax_rate') is not None else ''),
                '有效期': start + '至' + end, '价格版本': str(obj.get('price_version') or ''),
                '审批状态': 'ACTIVE', '价格依据': str(obj.get('price_basis') or '')}
    return None

def _v18_legacy_records(value, fields):
    out = []
    labels = '|'.join(re.escape(x) for x in fields)
    code_re = re.compile(r'(?:物料编码|material_code)\s*[:：]\s*([A-Z][A-Z0-9_-]{5,}|\d{8,16})(?![A-Z0-9_-])', re.I)
    for raw in _v18_iter_objects(value):
        if not isinstance(raw, str):
            continue
        matches = list(code_re.finditer(raw))
        for i, hit in enumerate(matches):
            block = raw[hit.start():matches[i+1].start() if i + 1 < len(matches) else len(raw)]
            row = {'物料编码': hit.group(1).upper()}
            for key in fields[1:]:
                m = re.search(r'(?:^|\s)' + re.escape(key) + r'\s*[:：]\s*(.*?)(?=\s*(?:' + labels + r')\s*[:：]|\Z)', block, re.S | re.I)
                row[key] = re.sub(r'\s+', ' ', m.group(1)).strip() if m else ''
            if row.get('物料描述') and (row.get('规格参数') if fields == PRODUCT_FIELDS else row.get('未税单价')):
                out.append(row)
    return out

def parse_records(value, fields):
    out = []
    for obj in _v18_iter_objects(value):
        if isinstance(obj, dict):
            row = _v18_product(obj) if fields == PRODUCT_FIELDS else _v18_price(obj)
            if row:
                out.append(row)
    out.extend(_v18_legacy_records(value, fields))
    return out

from datetime import timezone, timedelta

_V182_VERIFIED_BASES={'SUPPLIER_QUOTE','CONTRACT_PRICE','ACTUAL_PURCHASE','APPROVED_PURCHASE_PRICE','VERIFIED_MARKET_PRICE'}
_v182_price_base=main
def main(item_json,material_code,product_result,price_result,primary_product_result=None,primary_price_result=None,product_gate='',price_gate=''):
    out=_v182_price_base(item_json,material_code,product_result,price_result,primary_product_result,primary_price_result,product_gate,price_gate)
    row=json.loads(out['quote_item_json'])
    if row.get('item_status')=='PRICED':
        source_item=json.loads(item_json) if isinstance(item_json,str) else item_json
        requirements=source_item.get('requirements_json') or '{}'
        requirements=json.loads(requirements) if isinstance(requirements,str) else requirements
        wanted=dec(requirements.get('rated_current_a')) if isinstance(requirements,dict) else None
        if wanted is not None:
            records=parse_records(product_result,PRODUCT_FIELDS)+parse_records(primary_product_result,PRODUCT_FIELDS)
            for product in records:
                if str(product.get('物料编码') or '')!=str(material_code):continue
                attrs=product_attribute_map(product)
                value=next((attrs.get(product_field_token(key)) for key in ('额定电流','额定工作电流','rated_current_a') if attrs.get(product_field_token(key)) not in (None,'')),None)
                hit=re.fullmatch(r'\s*([0-9]+(?:\.[0-9]+)?)\s*A?\s*',str(value or ''),re.I)
                if hit and dec(hit.group(1))!=wanted:
                    row['item_status']='PRODUCT_PARAMETER_MISMATCH'
                    row['issue']='产品额定电流与原始明确要求不一致，需重新选型，不能直接报价'
        out['item_status']=row['item_status']
        basis=str(row.get('price_basis') or '').upper()
        row['reference_only']=basis not in _V182_VERIFIED_BASES
        row['price_basis_label']='估算或未核验来源，仅作材料参考' if row['reference_only'] else '已声明的供应商/采购核价来源，仍按企业审核流程使用'
    out['quote_item_json']=json.dumps(row,ensure_ascii=False)
    return out

"""Keep an explicit pole configuration intact; 4P and 3P+N are distinct."""
import unicodedata as _v1821_unicode


def v1821_pole_token(value):
    text = _v1821_unicode.normalize('NFKC', str(value or '')).upper()
    text = re.sub(r'\s+', '', text).replace('极', 'P')
    return text if re.fullmatch(r'[1-9][0-9]?P(?:\+N)?', text) else ''


def v1821_pole_error(required, record):
    if required in (None, ''):
        return ''
    wanted = v1821_pole_token(required)
    if not wanted:
        return '资料极数格式无法自动核验，需明确完整极数及中性线配置'
    attrs = product_attribute_map(record)
    values = [attrs.get(product_field_token(key)) for key in ('极数', 'pole_count')]
    actual = {v1821_pole_token(value) for value in values if v1821_pole_token(value)}
    description = _v1821_unicode.normalize('NFKC', str(record.get('物料描述') or '')).upper()
    actual.update(re.sub(r'\s+', '', hit) for hit in re.findall(
        r'(?<![A-Z0-9])([1-9][0-9]?\s*P(?:\s*\+\s*N)?)(?![A-Z0-9+])', description))
    if not actual:
        return '候选记录未证实完整极数配置，不能默认满足' + wanted
    if len(actual) != 1:
        return '候选极数记录相互冲突：' + '/'.join(sorted(actual))
    found = next(iter(actual))
    if wanted != found:
        return '极数不一致：要求%s，候选%s；4P与3P+N不能自动互换' % (wanted, found)
    return ''

_v1821_price_base = main


def main(item_json, material_code, product_result, price_result,
         primary_product_result=None, primary_price_result=None, product_gate='', price_gate=''):
    out = _v1821_price_base(item_json, material_code, product_result, price_result,
                          primary_product_result, primary_price_result, product_gate, price_gate)
    row = json.loads(out['quote_item_json'])
    if row.get('item_status') == 'PRICED':
        item = json.loads(item_json) if isinstance(item_json, str) else item_json
        requirements = item.get('requirements_json') or '{}'
        requirements = json.loads(requirements) if isinstance(requirements, str) else requirements
        records = parse_records(product_result, PRODUCT_FIELDS) + parse_records(primary_product_result, PRODUCT_FIELDS)
        for product in records:
            if str(product.get('物料编码') or '') != str(material_code):
                continue
            error = v1821_pole_error(requirements.get('pole_count'), product)
            if error:
                stop(row, 'TECH_SPEC_MISMATCH', error)
                break
    out['item_status'] = row['item_status']
    out['quote_item_json'] = json.dumps(row, ensure_ascii=False)
    return out
