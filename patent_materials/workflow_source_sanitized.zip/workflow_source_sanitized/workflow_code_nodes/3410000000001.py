import json
import re

def clean(v):
    return '' if v is None else str(v).replace('\u200b', '').replace('\ufeff', '').strip()
PRODUCT_FIELDS = ('物料编码', '物料描述', '产品类别', '产品系列', '规格参数', '状态', '数据质量')
CODE_RE = re.compile('物料编码\\s*[:：]\\s*([A-Z][A-Z0-9_-]{5,}|\\d{8,16})(?![A-Z0-9_-])', re.I)

def doc_texts(value):
    """Only interpret document body text; never mistake retrieval metadata for a record."""
    if isinstance(value, str):
        if value.strip().startswith(('[', '{')):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, (dict, list)):
                    return doc_texts(parsed)
            except (ValueError, TypeError):
                pass
        return [value] if value.strip() else []
    if isinstance(value, list):
        out = []
        for x in value:
            out.extend(doc_texts(x))
        return out
    if isinstance(value, dict):
        for k in ('content', 'text', 'page_content'):
            if isinstance(value.get(k), str) and value[k].strip():
                return [value[k]]
        for k in ('result', 'results', 'documents', 'chunks', 'data'):
            if k in value:
                return doc_texts(value[k])
    return []

def extract_field(block, key, fields):
    """Read the named field only inside one material record, not the next record."""
    all_labels = '|'.join((re.escape(x) for x in fields))
    m = re.search('(?:^|\\s)' + re.escape(key) + '\\s*[:：]\\s*', block, re.I)
    if not m:
        return ''
    rest = block[m.end():]
    nxt = re.search('(?:^|\\s)(?:' + all_labels + ')\\s*[:：]', rest, re.I)
    value = rest[:nxt.start()] if nxt else rest
    value = re.split('(?:\\n\\s*#{1,6}\\s*(?:PRODUCT|PRICE)\\b|\\n\\s*---\\s*$)', value, 1, flags=re.I | re.M)[0]
    value = re.sub('\\s+', ' ', value).strip()
    value = re.sub('(?:\\s+#{0,6}\\s*(?:PRICE|PRODUCT)|\\s+---)\\s*$', '', value, flags=re.I).strip()
    return value

def parse_records(value, fields):
    """Exact-code record extraction from any Dify retrieval hit; never join adjacent codes."""
    out = []
    for raw in doc_texts(value):
        text = raw.replace('**', '').replace('＃', '')
        matches = list(CODE_RE.finditer(text))
        for i, m in enumerate(matches):
            block = text[m.start():matches[i + 1].start() if i + 1 < len(matches) else len(text)]
            row = {'物料编码': m.group(1).upper()}
            for k in fields[1:]:
                row[k] = extract_field(block, k, fields)
            if row.get('物料描述') and (row.get('规格参数') if fields == PRODUCT_FIELDS else row.get('未税单价')):
                out.append(row)
    return out

def main(material_code, result):
    code = clean(material_code).upper()
    records = [r for r in parse_records(result, PRODUCT_FIELDS) if r['物料编码'] == code]
    complete = [r for r in records if all((clean(r.get(k)) for k in PRODUCT_FIELDS))]
    return {'exact_hit': 'HIT' if complete else 'MISS', 'exact_count': len(records)}


# V18 MongoDB document adapters. PRODUCT/PRICE retrieval may return JSON documents
# from the formal MongoDB-backed Dify datasets; legacy Markdown remains supported.
def _v18_iter_objects(value):
    if isinstance(value, dict):
        if value.get('material_code') or value.get('物料编码'):
            yield value
            return
        for key in ('content', 'text', 'page_content', 'body', 'items', 'result', 'results', 'documents', 'chunks', 'data'):
            if key in value:
                yield from _v18_iter_objects(value[key])
        return
    if isinstance(value, (list, tuple)):
        for item in value:
            yield from _v18_iter_objects(item)
        return
    if isinstance(value, str):
        text = value.strip()
        if text.startswith(('{', '[')):
            try:
                yield from _v18_iter_objects(json.loads(text))
                return
            except (ValueError, TypeError):
                pass
        yield value

def _v18_category(obj):
    c = obj.get('category') or {}
    if isinstance(c, dict):
        return str(c.get('middle') or c.get('root') or c.get('leaf') or '').strip(), str(c.get('leaf') or '').strip()
    return str(c).strip(), ''

def _v18_specs(obj):
    text = obj.get('specification_text') or ''
    if text:
        return str(text)
    specs = obj.get('standard_specs') or {}
    parts = []
    if isinstance(specs, dict):
        for key, val in specs.items():
            if isinstance(val, dict):
                value = val.get('value_text') or val.get('value_num') or ''
                unit = val.get('unit') or ''
                parts.append(str(val.get('raw_name') or key) + '=' + str(value) + str(unit))
            elif val not in (None, ''):
                parts.append(str(key) + '=' + str(val))
    attrs = obj.get('source_attributes') or []
    if isinstance(attrs, list):
        for attr in attrs:
            if isinstance(attr, dict) and attr.get('name') and attr.get('value') not in (None, ''):
                parts.append(str(attr['name']) + '=' + str(attr['value']))
    return '；'.join(dict.fromkeys(parts))

def _v18_product(obj):
    code = str(obj.get('material_code') or obj.get('物料编码') or '').strip().upper()
    if not code:
        return None
    if 'material_code' in obj:
        if str(obj.get('data_status') or '').upper() != 'ACTIVE':
            return None
        if str(obj.get('source_status') or '').strip() not in ('有效', 'ACTIVE', '在售'):
            return None
        category, series = _v18_category(obj)
        quality = '；'.join(str(x) for x in (obj.get('quality_flags') or []) if x)
        return {'物料编码': code, '物料描述': str(obj.get('description') or '').strip(),
                '产品类别': category, '产品系列': series, '规格参数': _v18_specs(obj),
                '状态': 'ACTIVE', '数据质量': quality or 'source_status=有效; data_status=ACTIVE'}
    return None

def _v18_price(obj):
    code = str(obj.get('material_code') or obj.get('物料编码') or '').strip().upper()
    if not code:
        return None
    if 'material_code' in obj:
        if str(obj.get('status') or '').upper() != 'ACTIVE':
            return None
        category = str(obj.get('category') or '').strip()
        start = str(obj.get('valid_from') or '')[:10]
        end = str(obj.get('valid_to') or '')[:10]
        return {'物料编码': code, '物料描述': '', '产品类别': category,
                '未税单价': str(obj.get('unit_price_ex_tax') or ''),
                '计价单位': str(obj.get('pricing_unit') or ''),
                '税率': str(obj.get('tax_rate') if obj.get('tax_rate') is not None else ''),
                '有效期': start + '至' + end, '价格版本': str(obj.get('price_version') or ''),
                '审批状态': 'ACTIVE', '价格依据': str(obj.get('price_basis') or '')}
    return None

def _v18_legacy_records(value, fields):
    out = []
    labels = '|'.join(re.escape(x) for x in fields)
    code_re = re.compile(r'(?:物料编码|material_code)\s*[:：]\s*([A-Z][A-Z0-9_-]{5,}|\d{8,16})(?![A-Z0-9_-])', re.I)
    for raw in _v18_iter_objects(value):
        if not isinstance(raw, str):
            continue
        matches = list(code_re.finditer(raw))
        for i, hit in enumerate(matches):
            block = raw[hit.start():matches[i+1].start() if i + 1 < len(matches) else len(raw)]
            row = {'物料编码': hit.group(1).upper()}
            for key in fields[1:]:
                m = re.search(r'(?:^|\s)' + re.escape(key) + r'\s*[:：]\s*(.*?)(?=\s*(?:' + labels + r')\s*[:：]|\Z)', block, re.S | re.I)
                row[key] = re.sub(r'\s+', ' ', m.group(1)).strip() if m else ''
            if row.get('物料描述') and (row.get('规格参数') if fields == PRODUCT_FIELDS else row.get('未税单价')):
                out.append(row)
    return out

def parse_records(value, fields):
    out = []
    for obj in _v18_iter_objects(value):
        if isinstance(obj, dict):
            row = _v18_product(obj) if fields == PRODUCT_FIELDS else _v18_price(obj)
            if row:
                out.append(row)
    out.extend(_v18_legacy_records(value, fields))
    return out
