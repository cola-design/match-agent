import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_WIRE_MAX = 55000
_CONTEXT_MAX = 5000000
_BATCH_MAX = 120

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def wire_pack(value):
    raw = _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if len(raw) > _CONTEXT_MAX:
        raise CapacityError('完整上下文超过本版5MB保护上限，请按柜号或回路分批')
    if len(raw) <= _WIRE_MAX:
        return raw.decode('utf-8')
    result = _WIRE_PREFIX + _whash.sha256(raw).hexdigest() + ':' + _wb64.b64encode(_wgzip.compress(raw, compresslevel=9, mtime=0)).decode('ascii')
    if len(result.encode('utf-8')) > _WIRE_MAX:
        raise CapacityError('上下文无损压缩后仍超过传递预算，请按柜号或回路分批；本次不生成不完整BOM')
    return result

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def check_array_budget(requirements):
    if len(requirements) > _BATCH_MAX:
        return '本次共%d项有效BOM需求，超过本版每次%d项的Excel模板容量。请按柜号或回路分批提交；全部需求仍保留在内部上下文，本次未执行部分选型。' % (len(requirements), _BATCH_MAX)
    if len(plain_json(requirements).encode('utf-8')) > 140000:
        return '本批需求及证据展开后超过140KB数组预算，请按柜号或回路分批。本次未执行部分选型。'
    if any((len(plain_json(r).encode('utf-8')) > 45000 for r in requirements)):
        return '单项需求及证据超过45KB预算，请精简重复原文或将相关页单独提交；本次未静默截断证据。'
    return ''
import json

def clean(value):
    text = '' if value is None else str(value)
    return text.replace('|', '／').replace('\n', ' ').replace('\r', ' ').strip()

def parse_item(value):
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        data = json.loads(value)
        return data if isinstance(data, dict) else None
    return None

def status_cn(status):
    return {'MATCHED': '可匹配', 'NEED_REVIEW': '需要复核', 'MISSING': '本次未找到匹配物料', 'NOT_RETRIEVED': '未检索到对应型号', 'BOM_DIRECT': '辅料待编码', 'BOM_REVIEW': '辅料待核对', 'SPACE_ONLY': '仅预留表位', 'HUMAN_CONFIRM': '待确认后选型'}.get(clean(status).upper(), '需要复核')

def excel_code(value):
    code = clean(value).replace('\u200b', '')
    return '\u200b' + code if code else ''

def list_text(value):
    if isinstance(value, list):
        return '；'.join((clean(x) for x in value if clean(x)))
    return clean(value)

def requirement_text(value):
    if not isinstance(value, dict):
        return clean(value)
    labels = [('rated_voltage_v', '额定电压', 'V'), ('rated_current_min_a', '额定电流', 'A'), ('pole_count', '极数', ''), ('breaking_capacity_min_ka', '分断能力', 'kA'), ('continuous_operating_voltage_v', 'SPD持续运行电压Uc', 'V'), ('trip_curve', '脱扣曲线', ''), ('leakage_required', '漏电要求', ''), ('operation_mode', '操作方式', ''), ('required_accessories', '附件', '')]
    parts = []
    for key, label, unit in labels:
        item = value.get(key)
        if item not in (None, '', []):
            parts.append('%s：%s%s' % (label, list_text(item), unit))
    return '；'.join(parts)

def unique_text(values):
    result = []
    for value in values:
        text = clean(value)
        if text and text not in result:
            result.append(text)
    return '；'.join(result)

def chinese_parameters__v16_before_1(value):
    if not isinstance(value, dict):
        return clean(value)
    labels = [('system_voltage_v', '系统电压', 'V'), ('rated_voltage_v', '额定电压', 'V'), ('rated_current_a', '额定电流', 'A'), ('rated_current_min_a', '额定电流最低要求', 'A'), ('pole_count', '极数', ''), ('breaking_capacity_ka', '分断能力', 'kA'), ('breaking_capacity_min_ka', '分断能力最低要求', 'kA'), ('continuous_operating_voltage_v', '最大持续运行电压Uc', 'V'), ('max_continuous_operating_voltage_v', '最大持续运行电压Uc', 'V'), ('uc_v', '最大持续运行电压Uc', 'V'), ('spd_uc_v', '最大持续运行电压Uc', 'V'), ('trip_curve', '脱扣特性', ''), ('tripping_curve', '脱扣特性', ''), ('leakage_required', '是否配置漏电保护', ''), ('leakage_current_ma', '漏电动作电流', 'mA'), ('installation_mode', '安装或进出线要求', ''), ('operation_mode', '操作方式', ''), ('control_voltage', '控制电压', ''), ('required_accessories', '要求附件', ''), ('forbidden_accessories', '禁止附件', ''), ('nominal_discharge_current_ka', '标称放电电流In', 'kA'), ('max_discharge_current_ka', '最大放电电流Imax', 'kA'), ('test_class', '试验类别', ''), ('brand_constraints', '品牌限制', '')]
    parts = []
    for key, label, unit in labels:
        val = value.get(key)
        if val is None or val == '' or val == [] or (val == {}):
            continue
        if isinstance(val, bool):
            text = '需要' if val else '不需要'
        elif isinstance(val, list):
            text = '、'.join((str(x) for x in val))
        else:
            text = str(val)
        parts.append(label + '：' + text + unit)
    return '；'.join(dict.fromkeys(parts))

def spd_ambiguous(req):
    role = clean(req.get('component_role')) + ' ' + clean(req.get('category_path'))
    spec = req.get('requirements') if isinstance(req.get('requirements'), dict) else {}
    return any((x in role.upper() for x in ('SPD', '电涌', '浪涌'))) and '后备' not in role and (spec.get('rated_voltage_v') not in (None, '')) and all((spec.get(k) in (None, '') for k in ('continuous_operating_voltage_v', 'max_continuous_operating_voltage_v', 'uc_v', 'spd_uc_v')))

def readable_requirement(req, item=None):
    item = item or {}
    spec = req.get('requirements') if isinstance(req.get('requirements'), dict) else item.get('requirements', {})
    spec = dict(spec) if isinstance(spec, dict) else {}
    ambiguous = spd_ambiguous(dict(req, requirements=spec))
    voltage = spec.pop('rated_voltage_v', None) if ambiguous else None
    parts = []
    model = clean(req.get('shown_model') or item.get('shown_model'))
    if model:
        parts.append('文件指定型号：' + model)
    if spec:
        parts.append(chinese_parameters(spec))
    summary = clean(item.get('requirement_summary') or req.get('requirement_summary'))
    if summary.startswith('{') and '}' in summary:
        summary = summary[summary.rfind('}') + 1:].strip('；; ')
    if summary and summary not in parts:
        parts.append(summary)
    if ambiguous:
        parts.append('电压参数含义待确认：' + str(voltage) + 'V（需明确额定工作电压还是Uc，不可互相替代）')
    segments = []
    for part in parts:
        for segment in part.split('；'):
            if segment and segment not in segments:
                segments.append(segment)
    if item.get('quantity_basis') == 'PER_CABINET' or req.get('quantity_basis') == 'PER_CABINET':
        segments.insert(0, '计量口径：单柜')
    gid = clean(req.get('scheme_group_id') or item.get('scheme_group_id'))
    if gid:
        segments.insert(0, '方案组：' + gid)
    return '；'.join(segments)

def _original_main(item_json_list, requirements_json: str) -> dict:
    try:
        requirements = wire_loads(requirements_json or '[]')
        if not isinstance(requirements, list):
            requirements = []
    except Exception:
        requirements = []
    modeled_by_key = {}
    for req in requirements:
        if not isinstance(req, dict):
            continue
        if clean(req.get('source_item_id')) and clean(req.get('shown_model')):
            key = (clean(req.get('scheme_group_id')), clean(req.get('component_role')), clean(req.get('project_quantity', req.get('quantity'))))
            modeled_by_key.setdefault(key, []).append(req)
    used_targets = set()
    filtered = []
    for req in requirements:
        if not isinstance(req, dict):
            continue
        key = (clean(req.get('scheme_group_id')), clean(req.get('component_role')), clean(req.get('project_quantity', req.get('quantity'))))
        is_shadow = not clean(req.get('source_item_id')) and (not clean(req.get('shown_model'))) and (clean(req.get('mapping_status')).upper() == 'PROTOCOL_ONLY')
        candidates = [x for x in modeled_by_key.get(key, []) if id(x) not in used_targets]
        if is_shadow and candidates:
            used_targets.add(id(candidates[0]))
            continue
        filtered.append(req)
    requirements = filtered
    request_map = {clean(x.get('request_id')): x for x in requirements if isinstance(x, dict) and clean(x.get('request_id'))}
    normalized, seen = ([], set())
    for value in item_json_list if isinstance(item_json_list, list) else []:
        try:
            item = parse_item(value)
        except Exception:
            item = None
        if not item:
            continue
        request_id = clean(item.get('request_id'))
        if not request_id or request_id in seen or request_id not in request_map:
            continue
        if clean(request_map[request_id].get('handling_mode')) in {'EXCLUDED', 'SPACE_ONLY'}:
            continue
        normalized.append(item)
        seen.add(request_id)
    for request_id, req in request_map.items():
        if request_id in seen:
            continue
        handling = clean(req.get('handling_mode'))
        if handling in {'EXCLUDED', 'SPACE_ONLY'}:
            continue
        status = handling if handling in {'BOM_DIRECT', 'BOM_REVIEW', 'SPACE_ONLY', 'HUMAN_CONFIRM'} else 'MISSING'
        normalized.append({'request_id': request_id, 'scheme_group_id': clean(req.get('scheme_group_id')), 'circuit_id': clean(req.get('circuit_id')), 'symbol': clean(req.get('symbol')), 'component_role': clean(req.get('component_role')), 'requirement_summary': requirement_text(req.get('requirements')), 'quantity_per_cabinet': req.get('quantity_per_cabinet', ''), 'cabinet_quantity': req.get('cabinet_quantity', ''), 'project_quantity': req.get('project_quantity', req.get('quantity', '')), 'quantity_basis': req.get('quantity_basis', 'PROJECT'), 'quantity_per_cabinet': req.get('quantity_per_cabinet'), 'quantity': req.get('project_quantity', req.get('quantity', '')), 'unit': clean(req.get('unit') or '台'), 'recommended': {}, 'alternatives': [], 'match_status': status, 'mismatch_or_missing': ['该需求的检索或选型结果未成功返回'] if status == 'MISSING' else ['该条为资料指定内容，未经过产品库型号与编码核验'], 'shown_model': clean(req.get('shown_model')), 'handling_mode': handling, 'selection_reason': '', 'warnings': [], 'source_evidence': [], 'upstream_missing_parameters': req.get('missing_parameters') if isinstance(req.get('missing_parameters'), list) else [], 'human_confirmation': '待确认', 'final_material_code': '', 'confirmation_note': ''})
    order = {clean(x.get('request_id')): i for i, x in enumerate(requirements) if isinstance(x, dict)}
    normalized.sort(key=lambda x: order.get(clean(x.get('request_id')), 999999))
    for item in normalized:
        req = request_map.get(clean(item.get('request_id')), {})
        for key in ('quantity_basis', 'quantity_per_cabinet', 'project_cabinet_quantity'):
            if key in req:
                item[key] = req[key]
        if req.get('quantity_basis') == 'PER_CABINET':
            item['project_quantity'] = None
            item['quantity'] = req.get('quantity_per_cabinet')
    valid_qty = []
    for item in normalized:
        val = item.get('quantity_per_cabinet') if item.get('quantity_basis') == 'PER_CABINET' else item.get('project_quantity', item.get('quantity'))
        try:
            number = float(val)
            if not (number > 0 and number < 1000000000.0):
                raise ValueError()
            valid_qty.append(item)
        except (ValueError, TypeError):
            item.setdefault('mismatch_or_missing', []).append('项目数量缺失或不合法，禁止确认报价')
            item['match_status'] = 'NEED_REVIEW'
    for item in normalized:
        req = request_map.get(clean(item.get('request_id')), {})
        item['requirements'] = req.get('requirements') if isinstance(req.get('requirements'), dict) else item.get('requirements', {})
        item['requirement_summary'] = readable_requirement(req, item)
        if spd_ambiguous(req):
            item.setdefault('warnings', []).append('SPD电压含义待确认，明确Uc或额定工作电压后才可报价')
            item['match_status'] = 'NEED_REVIEW'
    matched = sum((1 for x in normalized if clean(x.get('match_status')).upper() == 'MATCHED'))
    review = sum((1 for x in normalized if clean(x.get('match_status')).upper() == 'NEED_REVIEW'))
    missing = sum((1 for x in normalized if clean(x.get('match_status')).upper() in ('MISSING', 'NOT_RETRIEVED')))
    output = {'schema_version': 'component-selection-v12', 'selection_status': 'READY_FOR_HUMAN_CONFIRMATION' if normalized else 'NEED_REVIEW', 'items': normalized, 'human_review_required': True, 'pricing_allowed': False, 'next_action': '工程师填写确认单并提交；确认通过后形成正式BOM，再访问价格库。', 'global_warnings': ['正式采购前必须人工核验产品有效状态、完整规格和项目适用性。']}
    lines = ['## BOM确认', '', '| 序号 | 回路/位号 | 元器件名称 | 关键技术参数 | 推荐型号 | 物料编码 | 数量 | 系统状态 | 工程师确认 | 修改意见 |', '|---:|---|---|---|---|---|---|---|---|---|']
    for index, item in enumerate(normalized, 1):
        rec = item.get('recommended') if isinstance(item.get('recommended'), dict) else {}
        many_groups = len({clean(r.get('scheme_group_id')) for r in normalized if clean(r.get('scheme_group_id'))}) > 1
        position = v182_position(item, normalized, many_groups)
        quantity = item.get('quantity_per_cabinet') if item.get('quantity_basis') == 'PER_CABINET' else item.get('project_quantity', item.get('quantity', ''))
        quantity_text = (clean(quantity) + ' ' + clean(item.get('unit'))).strip()
        req = request_map.get(clean(item.get('request_id')), {})
        requirement = v182_requirement_display(item.get('requirement_summary'))
        item['requirement_summary'] = requirement
        source_model = clean(req.get('shown_model') or item.get('shown_model'))
        review_reasons = unique_text((item.get('warnings') or []) + (item.get('mismatch_or_missing') or []))
        visible_status = status_cn(item.get('match_status'))
        if review_reasons:
            visible_status += '（见选型说明）'
        model_name = clean(rec.get('material_name') or rec.get('product_model') or rec.get('model') or rec.get('series')) or ('需求：' + source_model if source_model else '未匹配')
        if item.get('selection_decision') == 'CANDIDATES_ONLY':
            choices = ['%s [%s]' % (x.get('material_name', ''), x.get('material_code', '')) for x in item.get('alternatives', [])]
            model_name = '待选定（见选型说明）'
            visible_status = '待选定（见选型说明）'
        item['position_display'] = position or clean(item.get('scheme_group_id'))
        item['model_display'] = model_name
        row = [index, position or clean(item.get('scheme_group_id')), clean(item.get('component_role')), requirement, model_name, excel_code(rec.get('material_code')), quantity_text, visible_status, '待确认', '']
        lines.append('| ' + ' | '.join((clean(x) for x in row)) + ' |')
    return {'selection_status': output['selection_status'], 'pricing_status': 'WAITING_HUMAN_CONFIRMATION', 'selection_message': '共%d项：可匹配%d项，需要复核%d项，本次未检索到%d项。' % (len(normalized), matched, review, missing), 'selection_json': json.dumps(output, ensure_ascii=False), 'confirm_markdown': '\n'.join(lines), 'output_filename': 'BOM人工确认单_V16.xlsx', 'item_count': len(normalized), 'matched_count': matched, 'review_count': review, 'missing_count': missing}

def _v163_selection_base(item_json_list, requirements_json):
    reqs = wire_loads(requirements_json or '[]')
    message = check_array_budget([r for r in reqs if isinstance(r, dict) and r.get('handling_mode') not in ('EXCLUDED', 'SPACE_ONLY')])
    try:
        if message:
            raise CapacityError(message)
        out = _original_main(item_json_list, requirements_json)
        out['selection_json'] = wire_pack(wire_loads(out['selection_json']))
        if len(out['confirm_markdown'].encode('utf-8')) > 50000:
            raise CapacityError('确认清单展示超过50KB预算；本次不生成截断的BOM，请分批')
        return out
    except CapacityError as exc:
        message = str(exc)
        return {'selection_status': 'CAPACITY_BLOCKED', 'pricing_status': 'BLOCKED_CAPACITY', 'selection_message': message, 'selection_json': plain_json({'capacity_blocked': True, 'capacity_message': message}), 'confirm_markdown': '', 'output_filename': '容量超限提示_请分批', 'item_count': len(reqs), 'matched_count': 0, 'review_count': len(reqs), 'missing_count': 0}
import copy

def generic_parameter_display(previous, value):
    if isinstance(value, dict):
        value = copy.deepcopy(value)
        for exact, minimum in [('rated_current_a', 'rated_current_min_a'), ('breaking_capacity_ka', 'breaking_capacity_min_ka')]:
            if value.get(exact) not in (None, '') and str(value.get(exact)) == str(value.get(minimum)):
                value.pop(minimum, None)
        if value.get('trip_curve') and value.get('trip_curve') == value.get('tripping_curve'):
            value.pop('tripping_curve', None)
    text = previous(value)
    if not isinstance(value, dict):
        return text
    existing = {'system_voltage_v', 'rated_voltage_v', 'rated_current_a', 'rated_current_min_a', 'pole_count', 'breaking_capacity_ka', 'breaking_capacity_min_ka', 'continuous_operating_voltage_v', 'max_continuous_operating_voltage_v', 'uc_v', 'spd_uc_v', 'trip_curve', 'tripping_curve', 'leakage_required', 'leakage_current_ma', 'installation_mode', 'operation_mode', 'control_voltage', 'required_accessories', 'forbidden_accessories', 'nominal_discharge_current_ka', 'max_discharge_current_ka', 'test_class', 'brand_constraints'}
    metadata = {'model', 'required_model', 'designated_model', 'specified_model', 'bit_number', 'position', 'symbol', 'unit', 'quantity_per_cabinet'}
    labels = {'material': '材质', 'thickness_mm': '板厚（mm）', 'color': '颜色', 'cross_section_mm2': '截面积（mm²）', 'specification': '规格原文', 'cabinet_cable_entry_exit': '柜体电缆进出线', 'cabinet_cable_entry_exit_source_text': '柜体电缆进出线原文（待核对）'}
    parts = [text]
    for key, val in value.items():
        if key in existing or key in metadata or val in (None, '', [], {}):
            continue
        parts.append(labels.get(key, str(key)) + '：' + clean(val))
    return '；'.join((p for p in parts if p))
_v16_parameter_display = chinese_parameters__v16_before_1

def chinese_parameters(value):
    return generic_parameter_display(_v16_parameter_display, value)

def main(item_json_list, requirements_json):
    out = _v163_selection_base(item_json_list, requirements_json)
    if out.get('selection_status') == 'CAPACITY_BLOCKED':
        return out
    reqs = wire_loads(requirements_json)
    contexts = []
    for row in reqs:
        context = row.get('project_context') if isinstance(row, dict) else None
        if context and context not in contexts:
            contexts.append(context)
    payload = wire_loads(out['selection_json'])
    payload['project_contexts'] = contexts
    payload['workflow_version'] = 'V18.2.1'
    payload['bom_fingerprint'] = selection_fingerprint(payload.get('items', []))
    payload['input_source_hashes'] = sorted({ev.get('document_hash') for row in payload.get('items', []) for ev in evidence_leaves(row.get('document_evidence')) if ev.get('document_hash')})
    out['selection_message'] += '\n版本：V18.2.1；BOM核对编号：' + payload['bom_fingerprint'][:16]
    if contexts:
        texts = []
        for context in contexts:
            text = context.get('cabinet_cable_entry_exit') or context.get('cabinet_cable_entry_exit_source_text')
            if not text and context.get('unmapped_cabinet_entry_requirements'):
                text = '作用范围待核对：' + '；'.join((r.get('text', '') for r in context['unmapped_cabinet_entry_requirements']))
            if text and text not in texts:
                texts.append(text)
        if texts:
            out['selection_message'] += '\n项目柜体电缆进出线要求（非器件接线方式）：' + '；'.join(texts)
    out['selection_json'] = wire_pack(payload)
    return out
import hashlib

def selection_fingerprint(items):
    rows = []
    for row in items:
        rows.append({'role': row.get('component_role'), 'model': row.get('shown_model'), 'requirements': row.get('requirements'), 'quantity': row.get('quantity'), 'unit': row.get('unit'), 'quantity_basis': row.get('quantity_basis'), 'selected_code': (row.get('recommended') or {}).get('material_code', ''), 'alternatives': sorted((x.get('material_code') or '' for x in row.get('alternatives', []))), 'decision': row.get('selection_decision')})
    rows.sort(key=lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True))
    body = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(body.encode()).hexdigest()

def evidence_leaves(value):
    out = []
    if isinstance(value, list):
        for child in value:
            out.extend(evidence_leaves(child))
    elif isinstance(value, dict):
        if value.get('text'):
            out.append({k: copy.deepcopy(value[k]) for k in ('text', 'document_hash', 'chunk_id', 'source_verified', 'source_start', 'source_end', 'source_spans', 'page_index', 'location') if k in value})
        else:
            for child in value.values():
                if isinstance(child, (dict, list)):
                    out.extend(evidence_leaves(child))
        for child in value.get('sources', []) if isinstance(value.get('sources'), list) else []:
            out.extend(evidence_leaves(child))
    unique = []
    seen = set()
    for row in out:
        key = json.dumps(row, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            unique.append(row)
    return unique
import re
def v182_position(item,items,many_groups):
    def generated(value):return bool(re.fullmatch(r'[A-Za-z]+-[a-f0-9]{12,}',str(value or ''),re.I))
    parts=[]
    if many_groups:
        groups=list(dict.fromkeys(str(row.get('scheme_group_id') or '') for row in items))
        label=item.get('scheme_label')
        parts.append(str(label) if label else '方案'+str(groups.index(str(item.get('scheme_group_id') or ''))+1))
    symbol=clean(item.get('symbol'));circuit=clean(item.get('circuit_id'))
    if symbol:parts.append(symbol)
    if circuit and not generated(circuit) and circuit!=symbol:parts.append(circuit)
    return '/'.join(parts) or clean(item.get('component_role'))


def v182_requirement_display(text):
    text=str(text or '')
    text=re.sub(r'(?:方案组|回路)\s*[:：]\s*[A-Za-z]+-[a-f0-9]{12,}\s*[；;]?','',text,flags=re.I).strip('；; ')
    text=text.replace('door_count：','柜门数量：').replace('door_type：','柜门形式：').replace('protection_level：','防护等级：')
    for curve in ('B','C','D'):
        if '脱扣特性：'+curve in text or '脱扣曲线：'+curve in text:
            text=text.replace('；明确脱扣特性：'+curve+'型脱扣','')
    return '；'.join(dict.fromkeys(part.strip() for part in text.split('；') if part.strip()))


_v182_parameter_display=chinese_parameters
def chinese_parameters(value):
    return _v182_parameter_display(value).replace('door_count：','柜门数量：').replace('door_type：','柜门形式：')

_v1821_requirement_display = v182_requirement_display
def v182_requirement_display(text):
    return _v1821_requirement_display(text).replace('ip_rating：', '防护等级：')
