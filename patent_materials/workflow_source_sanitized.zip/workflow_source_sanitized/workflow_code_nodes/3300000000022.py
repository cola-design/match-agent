import json, re, base64, gzip, io, math
HEADERS = ['序号', '回路/位号', '元器件名称', '关键技术参数', '推荐型号', '物料编码', '数量', '系统状态', '工程师确认', '修改意见']
PLACEHOLDERS = {'', '待确认', '【请工程师填写】', '【如需修改请填写】', '请工程师填写', '如需修改请填写'}

def text(v):
    return '' if v is None else str(v).replace('\u200b', '').replace('\ufeff', '').strip()

def canonical(v):
    return re.sub('\\s+', '', text(v)).replace('；', ';')


def canonical_parameters(value):
    """Only normalize the separators that the Excel writer changes.

    Keep each parameter segment and its order. Do not remove labels, values,
    units, signs or whole fields, and do not use an LLM to waive differences.
    """
    value = text(value).replace('\r\n', '\n').replace('\r', '\n')
    return tuple(canonical(part) for part in re.split('[；;\n]', value) if canonical(part))

def quantity_values(v):
    values = set()
    digits = {'零': 0, '一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9}
    for token, unit in re.findall('([0-9]+(?:\\.[0-9]+)?|[零一二两三四五六七八九十百千]+)\\s*(台|只|个|件|套|根|支|组|块|颗|处|米|m)(?![A-Za-z])', text(v), re.I):
        if re.fullmatch('[0-9]+(?:\\.[0-9]+)?', token):
            number = float(token)
        elif all((ch in digits for ch in token)):
            number = float(''.join((str(digits[ch]) for ch in token)))
        else:
            number = 0
            digit = 0
            for ch in token:
                if ch in digits:
                    digit = digits[ch]
                else:
                    number += (digit or 1) * {'十': 10, '百': 100, '千': 1000}[ch]
                    digit = 0
            number += digit
        values.add((number, unit.lower()))
    return values

def obj(v):
    if isinstance(v, dict):
        return v
    t = text(v)
    a, b = (t.find('{'), t.rfind('}'))
    x = json.loads(t[a:b + 1])
    if not isinstance(x, dict):
        raise ValueError('确认节点输出不是JSON对象')
    return x

def stored_selection(extracted):
    matches = re.findall('PAYLOAD_B64_PART_(\\d{3}):\\s*([A-Za-z0-9+/=]{1,24000})', extracted)
    chunks = {}
    for n, value in matches:
        if n in chunks and chunks[n] != value:
            raise ValueError('系统上下文重复分段冲突')
        chunks[n] = value
    if not chunks:
        raise ValueError('确认表未提取到完整系统数据；不能只凭模型生成的BOM进入报价')
    ordered = sorted(chunks)
    if ordered != ['%03d' % n for n in range(1, len(ordered) + 1)]:
        raise ValueError('系统上下文分段不连续')
    packed = base64.b64decode(''.join((chunks[n] for n in ordered)), validate=True)
    with gzip.GzipFile(fileobj=io.BytesIO(packed)) as stream:
        raw = stream.read(5000001)
    if len(raw) > 5000000:
        raise ValueError('确认表系统上下文超过处理容量')
    result = json.loads(raw.decode('utf-8'))
    if not isinstance(result, dict) or not isinstance(result.get('items'), list) or (not result['items']):
        raise ValueError('系统数据不是原始BOM选型结果，可能上传了问题确认单')
    return result

def main(reader_json, opinion_json, extracted_text):
    try:
        raw = obj(reader_json)
        interpreted = obj(opinion_json)
        if raw.get('form_type') != 'BOM_CONFIRMATION' or interpreted.get('form_type') != 'BOM_CONFIRMATION':
            raise ValueError('确认表类型不是BOM_CONFIRMATION，请使用对应提交入口')
        source = stored_selection(text(extracted_text))
        original = source['items']
        if source.get('workflow_version') not in ('V17', 'V17.1', 'V17.3'):
            for prior in original:
                notes = '；'.join((str(s) for s in prior.get('warnings') or []))
                if '脱扣曲线未明确' in notes or '候选存在B/C/D差异' in notes or 'SPD持续运行电压Uc未明确' in notes:
                    raise ValueError('旧版确认单含未明确关键参数的暂定推荐；请用原始协议图纸重新选型生成新版表，不能直接采用旧编码报价')
        rows = raw.get('rows')
        opinions = interpreted.get('rows')
        if not isinstance(rows, list) or not isinstance(opinions, list) or len(rows) != len(original) or (len(opinions) != len(rows)):
            raise ValueError('确认行数与原始BOM不一致；不能漏读、增添或静默删除未确认行。取消项请保留并填写不配置。')
        if len(rows) > 120:
            raise ValueError('确认表超过每批120项范围，请按方案分批')
        opinions_by_no = {text(r.get('序号')): r for r in opinions if isinstance(r, dict)}
        if len(opinions_by_no) != len(rows):
            raise ValueError('意见解释出现重复或空行号')
        result = []
        seen = set()
        for index, (row, base) in enumerate(zip(rows, original), 1):
            if not isinstance(row, dict) or not isinstance(base, dict):
                raise ValueError('确认表包含非法记录')
            no = text(row.get('序号'))
            if no != str(index) or no in seen:
                raise ValueError('确认表行号、顺序与原始清单不一致，请保留序号后再提交')
            seen.add(no)
            op = opinions_by_no.get(no)
            if not op:
                raise ValueError('缺少第' + no + '行的意见解释')
            wanted = text(base.get('requirement_summary'))
            if wanted and canonical_parameters(row.get('关键技术参数')) != canonical_parameters(wanted):
                raise ValueError('第' + no + '行关键技术要求与原始清单不一致；变更技术要求请重新选型，不直接确认报价')
            expected_position = base.get('position_display')
            if expected_position and canonical(row.get('回路/位号')) != canonical(expected_position):
                raise ValueError('第' + no + '行回路/位号与原清单不一致；不能把确认意见关联到另一个器件')
            if canonical(row.get('元器件名称')) != canonical(base.get('component_role')):
                raise ValueError('第' + no + '行元器件名称与原始清单不一致，请核对行关联')
            clean_row = {key: text(row.get(key)) for key in HEADERS}
            for key in ('normalized_action', 'action_confidence', 'action_reason', 'final_model_spec', 'final_material_code', 'final_quantity'):
                clean_row[key] = op.get(key)
            actual_note = ' '.join((text(row.get(k)) for k in ('工程师确认', '修改意见') if text(row.get(k)) not in PLACEHOLDERS))
            recommended = base.get('recommended') or {}
            for column, original_value in [('推荐型号', base.get('model_display') or recommended.get('material_name') or base.get('shown_model') or ''), ('物料编码', recommended.get('material_code') or '')]:
                current = text(row.get(column))
                if canonical(current) != canonical(original_value) and canonical(current) not in canonical(actual_note):
                    raise ValueError('第' + no + '行' + column + '被改动但修改意见没有明确最终值；请在黄色意见栏说明')
            if not actual_note:
                clean_row.update(normalized_action='PENDING', action_confidence=0.0, action_reason='工程师确认栏尚未填写，模型推断不能代替人工确认')
            original_qty = base.get('quantity_per_cabinet') if base.get('quantity_basis') == 'PER_CABINET' else base.get('project_quantity', base.get('quantity'))
            match = re.fullmatch('([0-9]+(?:\\.[0-9]+)?)\\s*([^0-9\\s]*)', text(row.get('数量')))
            if match and original_qty is not None and (clean_row.get('normalized_action') != 'EXCLUDE'):
                changed = float(match.group(1)) != float(original_qty) or (match.group(2) and match.group(2) != text(base.get('unit')))
                atoms = quantity_values(actual_note)
                if changed and float(match.group(1)) not in {n for n, u in atoms}:
                    raise ValueError('第' + no + '行数量或单位与原始清单不同；请在修改意见明确最终数量和单位')
            for key in ('final_model_spec', 'final_material_code', 'final_quantity'):
                val = text(clean_row.get(key))
                if val and canonical(val) not in canonical(actual_note):
                    if key == 'final_quantity' and quantity_values(val) and quantity_values(val).issubset(quantity_values(actual_note)):
                        continue
                    raise ValueError('第' + no + '行AI解释新增了工程师意见中没有的最终值：' + key)
            clean_row['关键技术参数'] = wanted or clean_row['关键技术参数']
            clean_row['original_requirements_json'] = json.dumps(base.get('requirements') or {}, ensure_ascii=False)
            clean_row['original_request_id'] = base.get('request_id', '')
            clean_row['scheme_group_id'] = base.get('scheme_group_id', '')
            clean_row['quantity_basis'] = base.get('quantity_basis', 'PROJECT')
            clean_row['project_cabinet_quantity'] = base.get('project_cabinet_quantity', base.get('cabinet_quantity'))
            result.append(clean_row)
        return {'text': json.dumps({'form_type': 'BOM_CONFIRMATION', 'rows': result, 'reconciled_with_original': True}, ensure_ascii=False), 'guard_status': 'VALID', 'guard_message': '已按原始清单逐行核对，AI仅用于理解工程师意见'}
    except (ValueError, TypeError, KeyError, EOFError, OSError) as exc:
        message = 'BOM回传核对失败：' + str(exc)
        return {'text': json.dumps({'form_type': 'BOM_CONFIRMATION', 'rows': [], 'validation_error': message}, ensure_ascii=False), 'guard_status': 'INVALID', 'guard_message': message}
