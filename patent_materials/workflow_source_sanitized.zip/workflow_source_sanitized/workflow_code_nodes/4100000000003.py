import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_WIRE_MAX = 55000
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def wire_pack(value):
    raw = _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if len(raw) > _CONTEXT_MAX:
        raise CapacityError('完整上下文超过本版5MB保护上限，请按柜号或回路分批')
    if len(raw) <= _WIRE_MAX:
        return raw.decode('utf-8')
    result = _WIRE_PREFIX + _whash.sha256(raw).hexdigest() + ':' + _wb64.b64encode(_wgzip.compress(raw, compresslevel=9, mtime=0)).decode('ascii')
    if len(result.encode('utf-8')) > _WIRE_MAX:
        raise CapacityError('上下文无损压缩后仍超过传递预算，请按柜号或回路分批；本次不生成不完整BOM')
    return result
import copy
import hashlib
import json
import re
import unicodedata

def jdump(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def norm_source(value):
    return re.sub('\\s+', '', ''.join((unicodedata.normalize('NFKC', ch) for ch in str(value or ''))))

def unfence(text):
    return re.sub('^```(?:json)?\\s*|\\s*```$', '', str(text or '').strip(), flags=re.I)

def anchor_evidence(value, chunk, errors):
    valid, rejected = exact_citations(value, chunk)
    if not valid:
        if not list(citation_leaves(value)):
            return {}
        example = next((str(x.get('text')) for x in citation_leaves(value)), '')
        errors.append(chunk['chunk_id']+'：来源原文未在当前文本段找到，不能用模型生成的原文作证据'
                      + ('；未定位摘录：'+example if example else '；未返回原文摘录'))
        return {}
    first = copy.deepcopy(valid[0])
    if len(valid) > 1:
        first['sources'] = copy.deepcopy(valid)
    if rejected:
        # A model's prose summary is not promoted to source evidence. Preserve
        # it for diagnosis while anchoring the independently valid quotations.
        first['unmatched_summary_texts'] = rejected
    return first

def stamp_sources(value, chunk, errors):
    if isinstance(value, list):
        return [stamp_sources(v, chunk, errors) for v in value]
    if not isinstance(value, dict):
        return value
    out = {}
    for key, child in value.items():
        out[key] = anchor_evidence(child, chunk, errors) if key == 'evidence' else stamp_sources(child, chunk, errors)
    return out

def combine_value(left, right, path, errors):
    if left in (None, '', [], {}):
        return copy.deepcopy(right)
    if right in (None, '', [], {}):
        return left
    if path.endswith('.evidence') and isinstance(left, dict) and isinstance(right, dict):
        if left == right:
            return left
        out = copy.deepcopy(left)
        sources = out.get('sources') or [copy.deepcopy(left)]
        if right not in sources:
            sources.append(copy.deepcopy(right))
        out['sources'] = sources
        return out
    if isinstance(left, dict) and isinstance(right, dict):
        out = copy.deepcopy(left)
        for k, v in right.items():
            out[k] = combine_value(out.get(k), v, path + '.' + k, errors)
        return out
    if isinstance(left, list) and isinstance(right, list):

        def identity(v):
            if isinstance(v, dict) and isinstance(v.get('evidence'), dict):
                ev = v['evidence']
                if ev.get('source_start') is not None and ev.get('source_end') is not None:
                    body = {k: x for k, x in v.items() if k not in ('item_id', 'evidence')}
                    return jdump([body, ev.get('document_hash'), ev['source_start'], ev['source_end']])
            return jdump(v)
        result = copy.deepcopy(left)
        seen = {identity(v) for v in result}
        for v in right:
            sig = identity(v)
            if sig not in seen:
                result.append(copy.deepcopy(v))
                seen.add(sig)
        return result
    if left == right:
        return left
    errors.append('跨段同一对象字段矛盾：' + path + '；保留来源，需确认，不能静默取后一个值')
    return left

def stable_key(value):
    return hashlib.sha256(str(value).encode()).hexdigest()[:16]

def collect_document(results, chunks, manifest):
    """Collect every expected result by ID, never by optimistic zip/truncation."""
    meta = json.loads(manifest)
    kind = meta['kind']
    source = [json.loads(c) for c in chunks]
    byid = {c['chunk_id']: c for c in source}
    errors = []
    parts = {}
    if meta.get('input_problem'):
        errors.append(meta['input_problem'])
    if not isinstance(results, list):
        results = []
        errors.append('分段结果不是数组')
    for value in results:
        try:
            part = json.loads(unfence(value)) if isinstance(value, str) else value
            if not isinstance(part, dict):
                raise ValueError('非对象')
            cid = part.get('chunk_id')
            if cid not in byid:
                raise ValueError('结果缺少合法chunk_id或关联了其他资料')
            if cid in parts:
                raise ValueError('同一文本段重复返回')
            if part.get('document_hash') != meta['document_hash']:
                raise ValueError('文档标识不一致')
            for key in ('project_requirements', 'drawing_info'):
                if key in part and (not isinstance(part[key], dict)):
                    errors.append(cid + '：' + key + '必须为对象')
                    part[key] = {}
            for key in ('component_rules', 'warnings'):
                if key in part and (not isinstance(part[key], list)):
                    errors.append(cid + '：' + key + '必须为数组')
                    part[key] = []
            if kind == 'DRAWING' and part.get('fragment_status') != 'NO_RELEVANT_CONTENT' and (part.get('recognition_status') not in ('READABLE', 'READY')):
                errors.append(cid + '：图纸段未明确完整可读')
            if part.get('fragment_status') not in ('COMPLETE', 'NO_RELEVANT_CONTENT'):
                errors.append(cid + '：模型报告本段未完整提取，需复核')
            if part.get('fragment_status') == 'NO_RELEVANT_CONTENT' and any((part.get(k) for k in ('scheme_groups', 'component_rules'))):
                errors.append(cid + '：声明无相关内容但同时返回了工程对象')
            if part.get('_binding_error'):
                errors.append(cid + '：' + str(part['_binding_error']))
            parts[cid] = stamp_sources(part, byid[cid], errors)
        except (ValueError, TypeError) as exc:
            errors.append('分段结果格式或关联错误：' + str(exc))
    missing = set(byid) - set(parts)
    if missing:
        errors.append('缺少文本段结果：' + '、'.join(sorted(missing)))
    project = {}
    groups = {}
    rules = []
    warnings = []
    drawing_info = {}
    drawing_sheets = []
    rule_seen = set()
    all_raw = ''.join((c['text'] for c in source))
    for cid in byid:
        part = parts.get(cid, {})
        project = combine_value(project, part.get('project_requirements', {}), '项目参数', errors)
        info = part.get('drawing_info', {})
        if info and info not in drawing_sheets:
            drawing_sheets.append(copy.deepcopy(info))
        if info:
            if not drawing_info:
                drawing_info = copy.deepcopy(info)
            else:
                drawing_info = {k: v for k, v in drawing_info.items() if v == info.get(k)}
        warnings.extend(part.get('warnings', []) if isinstance(part.get('warnings'), list) else [])
        local_ids = {}
        group_rows = part.get('scheme_groups', [])
        if not isinstance(group_rows, list):
            errors.append(cid + '：方案列表类型错误')
            group_rows = []
        for seq, group in enumerate(group_rows, 1):
            if not isinstance(group, dict):
                errors.append(cid + '：方案格式错误')
                continue
            group = copy.deepcopy(group)
            oldid = group.get('protocol_scheme_id') if kind == 'PROTOCOL' else group.get('scheme_group_id')
            if kind == 'DRAWING':
                for key2 in ('circuits', 'shown_bom', 'drawing_items', 'auxiliary_materials', 'wire_requirements', 'external_cable_requirements'):
                    if key2 in group and (not isinstance(group[key2], list)):
                        errors.append(cid + '：' + key2 + '必须为数组')
                        group[key2] = []
                for circuit in group.get('circuits', []):
                    if not isinstance(circuit, dict):
                        continue
                    circuitkey = str(circuit.pop('source_circuit_key', '') or '')
                    if circuitkey and norm_source(circuitkey) in norm_source(all_raw):
                        circuit['circuit_id'] = 'C-' + stable_key(circuitkey)
                    else:
                        circuit['circuit_id'] = cid + ':' + str(circuit.get('circuit_id') or 'UNNAMED')
                    if not isinstance(circuit.get('components', []), list):
                        errors.append(cid + '：回路元件必须为数组')
                        circuit['components'] = []
                    for item in circuit.get('components', []):
                        if isinstance(item, dict):
                            item['circuit_id'] = circuit['circuit_id']
            natural = str(group.pop('source_scheme_key', '') or '').strip()
            global_scope = natural == '__PROJECT__'
            if natural and (not global_scope) and (norm_source(natural) not in norm_source(all_raw)):
                errors.append(cid + '：方案关联键没有原文依据')
                natural = ''
            if global_scope and len(group_rows) > 1:
                errors.append(cid + '：多方案不能同时使用全项目默认关联键')
            key = natural if natural else cid + ':' + str(oldid or seq)
            gid = ('P-' if kind == 'PROTOCOL' else 'D-') + stable_key(key)
            local_ids[str(oldid or '')] = gid
            group['protocol_scheme_id' if kind == 'PROTOCOL' else 'scheme_group_id'] = gid
            if global_scope:
                group['scope_basis'] = 'GLOBAL_PROTOCOL' if kind == 'PROTOCOL' else 'DOCUMENT_DEFAULT'
            if not group.get('evidence'):
                errors.append(cid + '：方案缺少可定位原文证据')
            if gid not in groups:
                groups[gid] = group
            else:
                target = groups[gid]
                for key2, val in group.items():
                    if key2 == 'circuits':
                        cmap = {str(c.get('circuit_id')): c for c in target.get('circuits', []) if isinstance(c, dict)}
                        for circuit in val if isinstance(val, list) else []:
                            if not isinstance(circuit, dict):
                                errors.append('回路结构错误')
                                continue
                            ck = str(circuit.get('circuit_id') or cid + ':' + str(len(cmap)))
                            cmap[ck] = combine_value(cmap.get(ck), circuit, gid + '.' + ck, errors)
                        target['circuits'] = list(cmap.values())
                    elif key2 == 'evidence':
                        ev = target.get('evidence') or {}
                        other = group.get('evidence') or {}
                        if ev and other and (ev != other):
                            ev = copy.deepcopy(ev)
                            ev['sources'] = (ev.get('sources') or [target['evidence']]) + [other]
                        target[key2] = ev or other
                    else:
                        target[key2] = combine_value(target.get(key2), val, gid + '.' + key2, errors)
        for rule in part.get('component_rules', []) if isinstance(part.get('component_rules'), list) else []:
            if not isinstance(rule, dict):
                errors.append(cid + '：规则格式错误')
                continue
            rule = copy.deepcopy(rule)
            mapped = []
            for ident in rule.get('applicable_protocol_scheme_ids', []):
                if str(ident) in local_ids:
                    mapped.append(local_ids[str(ident)])
                else:
                    errors.append(cid + '：条款引用了本段未声明的方案，需明确条款范围')
            rule['applicable_protocol_scheme_ids'] = mapped
            if not rule.get('evidence'):
                errors.append(cid + '：元器件规则缺少原文证据')
            identity = {k: v for k, v in rule.items() if k not in ('rule_id', 'evidence')}
            sig = jdump(identity)
            if sig in rule_seen:
                continue
            rule_seen.add(sig)
            rule['rule_id'] = 'R-' + stable_key(sig)
            rules.append(rule)
    output = {'schema_version': 'protocol-v3' if kind == 'PROTOCOL' else 'drawing-pdf-text-v3', 'scheme_groups': list(groups.values()), 'warnings': warnings, '_document_errors': list(dict.fromkeys(errors)), 'source_manifest': {'document_hash': meta['document_hash'], 'expected_chunks': len(byid), 'received_chunks': len(parts), 'character_count': meta['character_count'], 'complete': not errors}}
    if kind == 'PROTOCOL':
        output.update(project_requirements=project, component_rules=rules, document_type='technical_agreement')
    else:
        output.update(drawing_info=drawing_info, drawing_sheets=drawing_sheets, recognition_status='PARTIAL' if errors else 'READABLE')
    return {'text': wire_pack(output), 'fragment_summary': '%s资料：%d段，返回%d段，来源或结构问题%d项' % (kind, len(byid), len(parts), len(errors))}

def main(results, chunks, manifest):
    out = collect_document(results, chunks, manifest)
    protocol = preserve_document_facts(normalize_rule_quantities(wire_loads(out['text'])), 'PROTOCOL', source_from_chunks(chunks))
    if protocol.get('_document_errors'):
        protocol.setdefault('source_manifest', {})['complete'] = False
    out['text'] = wire_pack(protocol)
    return out

def _quantity_text_count(rule, group):
    value = clean(rule.get('quantity_rule')).rstrip('。；;')
    if not value:
        return None
    if re.fullmatch('[1-9]\\d{0,3}(?:\\.0+)?', value):
        return num(value)
    m = re.fullmatch('(?:每柜|每台|每个方案)?\\s*([1-9]\\d{0,3})\\s*(?:个|只|台|套|件|根|块|支|组|处|颗)\\s*(?:[（(]按(?:一|1)台柜计[）)]|/柜|/台)?', value)
    if m:
        return num(m.group(1))
    if value in ('每台一套', '每台一处', '每个方案一套', '每个方案一只', '每柜一套', '每柜一只'):
        return 1
    if re.fullmatch('按主进线回路(?:数量|配置)?', value):
        return num(group.get('incoming_count'))
    if re.fullmatch('按出线回路(?:数量|配置)?', value):
        return num(group.get('outgoing_count'))
    return None
import math

def quantity_number(value):
    if isinstance(value, bool) or value in (None, ''):
        return None
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    if not math.isfinite(number) or number < 0:
        return None
    return int(number) if number.is_integer() else number

def quantity_token(value):
    return re.sub('\\s+', '', unicodedata.normalize('NFKC', str(value or ''))).casefold().replace('×', 'x')

def quantity_evidence_rows(value):
    """A model-authored quotation without source anchoring cannot arbitrate."""
    out = []
    if isinstance(value, list):
        for entry in value:
            out.extend(quantity_evidence_rows(entry))
    elif isinstance(value, dict):
        if value.get('source_verified') is True and value.get('document_hash') and value.get('chunk_id'):
            for line in str(value.get('text') or '').replace('\\n', '\n').splitlines():
                if line.strip() and line.strip() not in out:
                    out.append(line.strip())
        for entry in value.get('sources', []) if isinstance(value.get('sources'), list) else []:
            for line in quantity_evidence_rows(entry):
                if line not in out:
                    out.append(line)
    return out

def item_evidence_quantities(rule):
    """Only unambiguous trailing quantities in the cited item's own row.

    This is a consistency check, not a PDF table parser. Unrecognized layouts
    produce no evidence and cannot silently resolve contradictory fields.
    """
    params = rule.get('parameters') if isinstance(rule.get('parameters'), dict) else {}
    model = next((params[k] for k in ('model', 'required_model', 'specified_model', '型号', '规格型号') if params.get(k)), None)
    role = quantity_token(rule.get('component_role'))
    result = []
    for line in quantity_evidence_rows(rule.get('evidence')):
        token = quantity_token(line)
        if model:
            key = quantity_token(model)
            if not key or token.count(key) != 1:
                continue
            tail = token.split(key, 1)[1]
        else:
            if not role or token.count(role) != 1:
                continue
            tail = token.split(role, 1)[1]
        if re.search('项目总|订货总|合计|整批|总计|总数量|所有柜', token):
            continue
        if re.search('至少|不小于|不少于|最多|不超过|每[套组包箱]|/套|/包', tail):
            continue
        hits = list(re.finditer('(?<![\\d.])([0-9]+(?:\\.[0-9]+)?)\\s*(个|只|台|套|件|根|块|支|组|处|颗|米|m)(?![a-z0-9²])', tail))
        hit = re.search('(?<![\\d.])([0-9]+(?:\\.[0-9]+)?)\\s*(个|只|台|套|件|根|块|支|组|处|颗|米|m)[。；;，,]?$', tail)
        if not hit or len(hits) != 1:
            continue
        source_unit = hit.group(2)
        declared_unit = quantity_token(params.get('unit'))
        unit_alias = {'米': 'm'}
        if not declared_unit or unit_alias.get(source_unit, source_unit) != unit_alias.get(declared_unit, declared_unit):
            continue
        qty = quantity_number(hit.group(1))
        if qty is not None and qty not in result:
            result.append(qty)
    return result

def normalize_rule_quantities(protocol):
    protocol = copy.deepcopy(protocol)
    errors = protocol.setdefault('_document_errors', [])
    audit = copy.deepcopy(protocol.get('quantity_resolution_audit') or [])
    rules = protocol.get('component_rules', [])
    for rule in rules if isinstance(rules, list) else []:
        if not isinstance(rule, dict):
            continue
        params = rule.get('parameters')
        if not isinstance(params, dict):
            continue
        values = [params[k] for k in ('quantity_per_cabinet', '每柜数量', '单柜数量') if params.get(k) not in (None, '')]
        if not values:
            continue
        numbers = [quantity_number(v) for v in values]
        label = str(rule.get('rule_id') or '') + ' ' + str(rule.get('component_role') or '') + ' ' + str(params.get('model') or '')
        if None in numbers or len(set(numbers)) != 1 or numbers[0] <= 0:
            problem = label + '：逐项每柜数量字段无效或相互矛盾，需核对原始行'
            if problem not in errors:
                errors.append(problem)
            continue
        structured = numbers[0]
        params['quantity_per_cabinet'] = structured
        text_count = _quantity_text_count(rule, {})
        evidence = item_evidence_quantities(rule)
        if len(evidence) > 1 or (evidence and evidence[0] != structured):
            problem = label + '：模型逐项数量%s与已核验原文行数量%s不一致，需重新核对提取结果' % (structured, evidence)
            if problem not in errors:
                errors.append(problem)
            continue
        if text_count is None or text_count == structured:
            continue
        if evidence == [structured]:
            record = {'rule_id': rule.get('rule_id'), 'original_quantity_rule': rule.get('quantity_rule'), 'structured_quantity': structured, 'text_quantity': text_count, 'evidence_quantities': evidence, 'resolution': 'VERIFIED_ITEM_ROW_OVER_UNSUPPORTED_QUANTITY_TEXT'}
            if record not in audit:
                audit.append(record)
            rule['quantity_rule'] = '每柜%s%s' % (structured, str(params.get('unit') or '件'))
            rule['quantity_resolution'] = copy.deepcopy(record)
        else:
            problem = label + '：逐项数量%s与数量规则%s不一致，缺少足够的本行原文依据，不能自动放行' % (structured, text_count)
            if problem not in errors:
                errors.append(problem)
    if audit:
        protocol['quantity_resolution_audit'] = audit
    return protocol

def clean(value):
    return str(value or '').strip()

def num(value):
    return quantity_number(value)

def fact_text(value):
    return unicodedata.normalize('NFKC', str(value or '')).replace('\r', '')

def fact_key(value):
    return re.sub('\\s+', '', fact_text(value)).casefold().replace('×', 'x')

def evidence_leaves(value):
    out = []
    if isinstance(value, list):
        for child in value:
            out.extend(evidence_leaves(child))
    elif isinstance(value, dict):
        if value.get('text'):
            out.append({k: copy.deepcopy(value[k]) for k in ('text', 'document_hash', 'chunk_id', 'source_verified', 'source_start', 'source_end', 'source_spans', 'page_index', 'location') if k in value})
        else:
            for child in value.values():
                if isinstance(child, (dict, list)):
                    out.extend(evidence_leaves(child))
        for child in value.get('sources', []) if isinstance(value.get('sources'), list) else []:
            out.extend(evidence_leaves(child))
    unique = []
    seen = set()
    for row in out:
        key = json.dumps(row, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            unique.append(row)
    return unique

def is_anchored(ev):
    return ev.get('source_verified') is True and bool(ev.get('document_hash')) and bool(ev.get('chunk_id'))

def source_rows(evidence, raw_text=''):
    """Expand a verified citation only to its own source line, never a document scan."""
    raw = str(raw_text or '').replace('\r\n', '\n').replace('\r', '\n')
    digest = hashlib.sha256(raw.encode()).hexdigest() if raw else ''
    rows = []
    for ev in evidence_leaves(evidence):
        if not is_anchored(ev):
            continue
        for line in str(ev['text']).replace('\\n', '\n').splitlines():
            if line.strip():
                rows.append((line.strip(), ev))
        spans = ev.get('source_spans') or ([[ev['source_start'], ev['source_end']]] if isinstance(ev.get('source_start'), int) and isinstance(ev.get('source_end'), int) else [])
        if raw and digest == ev.get('document_hash'):
            for span in spans:
                if not isinstance(span, (list, tuple)) or len(span) != 2:
                    continue
                start, end = span
                if not isinstance(start, int) or not isinstance(end, int) or (not 0 <= start < end <= len(raw)):
                    continue
                if '\n' in raw[start:end]:
                    continue
                a = raw.rfind('\n', 0, start) + 1
                b = raw.find('\n', end)
                if b < 0:
                    b = len(raw)
                row = raw[a:b].strip()
                expanded = dict(ev, text=row, source_start=a, source_end=b, source_spans=[[a, b]])
                if row:
                    rows.append((row, expanded))
    return rows

def item_source_clause(line, model, symbol, role):
    """Select a clause with an explicit item identity; same-model peers stay separate."""
    text = fact_text(line)
    model = fact_text(model).strip()
    symbol = fact_text(symbol).strip()
    clauses = re.split('[;；\\n]', text)
    selected = []
    for clause in clauses:
        if re.search('例如|示例|举例|推荐示意|可选型号', clause):
            continue
        if model and fact_key(model) not in fact_key(clause):
            continue
        if not model:
            if not symbol or not re.search('(?<![A-Za-z0-9_-])' + re.escape(symbol) + '(?![A-Za-z0-9_-])', clause, re.I):
                continue
            if role and fact_key(role) not in fact_key(clause):
                continue
        if model and fact_key(clause).count(fact_key(model)) > 1:
            if not symbol:
                continue
            hits = list(re.finditer('(?<![A-Za-z0-9_-])' + re.escape(symbol) + '(?![A-Za-z0-9_-])', clause, re.I))
            if len(hits) != 1:
                continue
            tail = clause[hits[0].start():]
            next_position = re.search('\\s+[A-Za-z][A-Za-z0-9_-]*\\s*[=:：]', tail[len(symbol):])
            clause = tail[:len(symbol) + next_position.start()] if next_position else tail
            if fact_key(clause).count(fact_key(model)) != 1:
                continue
        if symbol:
            label = re.match('\\s*([A-Za-z][A-Za-z0-9_-]*)\\s*[=:：]', clause)
            if label and label.group(1).casefold() != symbol.casefold():
                continue
        clause = re.sub('(?:不允许|不得|禁止|不能|不采用|不选用|不使用|排除|不含)[^;；。\\n,，]*', '', clause)
        if clause.strip():
            selected.append(clause.strip())
    return selected

def explicit_item_facts(clause, role=''):
    """Small, transparent grammar; unrecognized prose remains in source evidence."""
    text = fact_text(clause)
    facts = []

    def put(field, value):
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        pair = (field, value)
        if pair not in facts:
            facts.append(pair)
    if '断路器' in str(role) or 'MCB' in str(role).upper():
        for m in re.finditer('(?<![A-Z0-9])([BCD])\\s*(\\d{1,3})(?:\\s*A)?(?![A-Z0-9])', text, re.I):
            put('trip_curve', m.group(1).upper())
            put('rated_current_a', int(m.group(2)))
        for m in re.finditer('(?:脱扣(?:特性|曲线)\\s*[:：=为]?\\s*([BCD])|(?<![A-Z0-9])([BCD])\\s*型脱扣)', text, re.I):
            put('trip_curve', next((x for x in m.groups() if x)).upper())
    for m in re.finditer('(?<![A-Za-z0-9])([1-5])\\s*P\\s*(\\+\\s*N)?(?![A-Za-z0-9])', text, re.I):
        put('pole_count', m.group(1) + 'P' + ('+N' if m.group(2) else ''))
    patterns = [('continuous_operating_voltage_v', '(?:\\bUc|最大持续(?:工作|运行)电压)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V)\\b'), ('max_discharge_current_ka', '(?:\\bImax|最大放电电流)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA|A)\\b'), ('nominal_discharge_current_ka', '(?:\\bIn|标称放电电流)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA)\\b'), ('breaking_capacity_ka', '(?:分断能力|\\bIcn|\\bIcu)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA)\\b'), ('rated_current_a', '额定电流\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(A)\\b'), ('rated_voltage_v', '额定(?:工作)?电压\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V)\\b'), ('control_voltage', '(?:线圈电压|控制电压)\\s*[:：=为]?\\s*((?:AC|DC)\\s*\\d+(?:\\.\\d+)?\\s*V)\\b')]
    for field, pattern in patterns:
        for m in re.finditer(pattern, text, re.I):
            if field == 'control_voltage':
                put(field, re.sub('\\s+', '', m.group(1)).upper())
                continue
            number = float(m.group(1))
            unit = m.group(2).lower()
            if field.endswith('_v') and unit == 'kv':
                number *= 1000
            if field.endswith('_ka') and unit == 'a':
                number /= 1000
            put(field, number)
    return facts

def normalize_fact_value(field, value):
    if field in ('trip_curve', 'pole_count', 'control_voltage'):
        return re.sub('\\s+', '', fact_text(value)).upper()
    if isinstance(value, bool):
        return ('invalid', str(value))
    m = re.fullmatch('\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V|kA|A)?\\s*', str(value), re.I)
    if not m:
        return ('text', fact_key(value))
    number = float(m.group(1))
    unit = (m.group(2) or '').lower()
    if field.endswith('_v') and unit == 'kv':
        number *= 1000
    elif field.endswith('_ka') and unit == 'a':
        number /= 1000
    elif unit and unit not in (('v', 'kv') if field.endswith('_v') else ('a', 'ka')):
        return ('invalid', str(value))
    return number

def recover_item_facts(item, parameter_key, raw_text='', extra_evidence=None):
    params = item.setdefault(parameter_key, {})
    if not isinstance(params, dict):
        return ['物料参数不是对象，无法核对来源']
    model = item.get('shown_model') or next((params[k] for k in ('model', 'required_model', 'designated_model', 'specified_model') if params.get(k)), '')
    symbol = item.get('symbol') or params.get('bit_number') or params.get('symbol') or ''
    role = str(item.get('component_role') or item.get('category') or '')
    ledger = list(item.get('parameter_facts') or [])
    values = {}
    errors = []
    evidence = [item.get('evidence'), extra_evidence]
    for line, ev in source_rows(evidence, raw_text):
        for clause in item_source_clause(line, model, symbol, role):
            for field, value in explicit_item_facts(clause, role):
                proof = {k: copy.deepcopy(ev[k]) for k in ('document_hash', 'chunk_id', 'source_verified', 'source_start', 'source_end', 'source_spans', 'page_index', 'location') if k in ev}
                fact = {'field': field, 'value': value, 'source_text': clause, 'source': proof}
                if fact not in ledger:
                    ledger.append(fact)
                values.setdefault(field, [])
                if value not in values[field]:
                    values[field].append(value)
    for field, found in values.items():
        if len({str(normalize_fact_value(field, v)) for v in found}) != 1:
            errors.append('当前物料原文的' + field + '存在不同值：' + str(found))
            continue
        value = found[0]
        if params.get(field) in (None, '', [], {}):
            params[field] = value
        elif normalize_fact_value(field, params[field]) != normalize_fact_value(field, value):
            errors.append('模型参数' + field + '=' + str(params[field]) + '与当前物料原文' + str(value) + '不一致')
    if ledger:
        item['parameter_facts'] = ledger
    return errors

def preserve_document_facts(document, kind, raw_text=''):
    if not isinstance(document, dict):
        return {'scheme_groups': [], '_document_errors': ['提取结果不是JSON对象，不能作为工程资料']}
    document = copy.deepcopy(document)
    errors = document.setdefault('_document_errors', [])
    if not isinstance(errors, list):
        errors = ['来源错误列表格式异常，需检查提取结果']
        document['_document_errors'] = errors

    def finite(value, path):
        if isinstance(value, float) and (not math.isfinite(value)):
            message = '来源字段含非有限数值：' + path
            if message not in errors:
                errors.append(message)
            return str(value)
        if isinstance(value, dict):
            return {key: finite(child, path + '.' + str(key)) for key, child in value.items()}
        if isinstance(value, list):
            return [finite(child, path + '[' + str(index) + ']') for index, child in enumerate(value)]
        return value
    document = finite(document, kind)
    document['_document_errors'] = errors
    if kind == 'PROTOCOL':
        for rule in document.get('component_rules', []) if isinstance(document.get('component_rules'), list) else []:
            if not isinstance(rule, dict):
                continue
            for error in recover_item_facts(rule, 'parameters', raw_text):
                message = str(rule.get('rule_id') or '') + ' ' + str(rule.get('component_role') or '') + '：' + error
                if message not in errors:
                    errors.append(message)
    else:
        for group in document.get('scheme_groups', []) if isinstance(document.get('scheme_groups'), list) else []:
            if not isinstance(group, dict):
                continue
            seen = set()
            for circuit in group.get('circuits', []) if isinstance(group.get('circuits'), list) else []:
                if not isinstance(circuit, dict):
                    continue
                for item in circuit.get('components', []) if isinstance(circuit.get('components'), list) else []:
                    if not isinstance(item, dict):
                        continue
                    seen.add(id(item))
                    for error in recover_item_facts(item, 'shown_parameters', raw_text, circuit.get('evidence')):
                        message = str(item.get('item_id') or '') + '：' + error
                        if message not in errors:
                            errors.append(message)
            for key in ('drawing_items', 'shown_bom', 'auxiliary_materials', 'wire_requirements'):
                for item in group.get(key, []) if isinstance(group.get(key), list) else []:
                    if not isinstance(item, dict) or id(item) in seen:
                        continue
                    seen.add(id(item))
                    for error in recover_item_facts(item, 'shown_parameters', raw_text):
                        message = str(item.get('item_id') or '') + '：' + error
                        if message not in errors:
                            errors.append(message)
    return document

def source_from_chunks(chunks):
    pieces = [json.loads(v) if isinstance(v, str) else v for v in chunks]
    pieces = sorted((p for p in pieces if isinstance(p, dict)), key=lambda p: p.get('start', 0))
    raw = ''
    for piece in pieces:
        start = piece.get('start')
        text = str(piece.get('text') or '')
        if not isinstance(start, int) or start < 0 or start > len(raw):
            return ''
        overlap = len(raw) - start
        if overlap > 0 and raw[start:] != text[:overlap]:
            return ''
        raw += text[overlap:]
    return raw

def source_norm(value):
    return re.sub(r'\s+', '', ''.join(unicodedata.normalize('NFKC', c) for c in str(value or '')))
def citation_leaves(value):
    if isinstance(value, list):
        for child in value:
            yield from citation_leaves(child)
    elif isinstance(value, dict):
        if str(value.get('text') or '').strip():
            yield {k: copy.deepcopy(v) for k, v in value.items() if k != 'sources'}
        if isinstance(value.get('sources'), list):
            for child in value['sources']:
                yield from citation_leaves(child)
def exact_citations(value, chunk):
    """Return only quotes actually present in this exact, current chunk."""
    text = chunk['text']
    hay = source_norm(text)
    index = []
    for i, char in enumerate(text):
        index.extend(i for c in unicodedata.normalize('NFKC', char) if not c.isspace())
    valid, rejected, seen = [], [], set()
    for leaf in citation_leaves(value):
        needle = source_norm(leaf['text'])
        if not needle or needle not in hay:
            rejected.append(leaf['text'])
            continue
        if needle in seen:
            continue
        seen.add(needle)
        spans = [[chunk['start'] + index[h.start()], chunk['start'] + index[h.end()-1]+1]
                 for h in re.finditer(re.escape(needle), hay)]
        anchored = dict(leaf, chunk_id=chunk['chunk_id'], document_hash=chunk['document_hash'],
                        source_verified=True, chunk_start=chunk['start'], chunk_end=chunk['end'],
                        source_spans=spans, page_index=None)
        anchored.pop('source_start', None)
        anchored.pop('source_end', None)
        if len(spans) == 1:
            anchored.update(source_start=spans[0][0], source_end=spans[0][1])
        valid.append(anchored)
    return valid, rejected