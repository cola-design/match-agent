import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
import json

def make_advisory_batches(protocol_text, drawing_text, supplementary_notes=''):
    protocol = wire_loads(protocol_text)
    drawing = wire_loads(drawing_text)
    rules = [{k: r.get(k) for k in ('rule_id', 'component_role', 'category', 'scope_type', 'applicable_protocol_scheme_ids', 'parameters', 'quantity_rule')} for r in protocol.get('component_rules', []) if isinstance(r, dict)]
    rows = []
    for group in drawing.get('scheme_groups', []):
        for item in group.get('drawing_items', []):
            rows.append(dict(item, scheme_group_id=group.get('scheme_group_id')))

    def project(v):
        if isinstance(v, list):
            return [project(x) for x in v]
        if isinstance(v, dict):
            return {k: project(x) for k, x in v.items() if k not in ('evidence', 'source_evidence', 'raw_text')}
        return v
    chunks = []
    problems = []
    for start in range(0, len(rows), 8):
        body = {'advisory_id': 'A-%03d' % (len(chunks) + 1), 'component_items': project(rows[start:start + 8]), 'protocol_rule_catalog': rules, 'supplementary_notes': supplementary_notes}
        if len(plain_json(body).encode()) > 54000:
            body = {'advisory_id': body['advisory_id'], 'input_problem': '关联输入超过54KB预算，需按柜号拆分，未截断需求', 'component_items': []}
            problems.append(body['input_problem'])
        chunks.append(plain_json(body))
    if not chunks:
        chunks = [plain_json({'advisory_id': 'A-001', 'component_items': [], 'protocol_rule_catalog': rules})]
    return {'chunks': chunks, 'manifest': plain_json({'ids': [json.loads(c)['advisory_id'] for c in chunks], 'errors': problems})}

def main(protocol_text, drawing_text, supplementary_notes=''):
    return make_advisory_batches(protocol_text, drawing_text, supplementary_notes)
