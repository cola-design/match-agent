import json, math
def main(body: str, status_code: int) -> dict:
    if int(status_code)!=200:
        raise ValueError('API_HTTP_%s：请检查API地址、密钥、网络、数据库连接和文档结构；本次停止。'%status_code)
    try:rows=json.loads(body)
    except (TypeError,ValueError):raise ValueError('API_RESPONSE_INVALID_JSON')
    if not isinstance(rows,list) or any(not isinstance(row,dict) for row in rows):raise ValueError('API_RESPONSE_NOT_DOCUMENT_ARRAY')
    for row in rows:
        if not isinstance(row.get('material_code'),str) or not row['material_code'].strip():raise ValueError('API_MATERIAL_CODE_MUST_BE_STRING')
        for field,expected in (('category',dict),('standard_specs',dict),('source_attributes',list),('quality_flags',list)):
            if not isinstance(row.get(field),expected):raise ValueError('API_PRODUCT_FIELD_TYPE_INVALID:'+field)
    return {'result':rows}
