import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
import base64
import gzip
import json
import re
HEADERS = ['序号', '回路/位号', '元器件名称', '关键技术参数', '推荐型号', '物料编码', '数量', '系统状态', '工程师确认', '修改意见']

def safe(value):
    text = '' if value is None else str(value).strip()
    return "'" + text if text.startswith(('=', '+', '-', '@')) else text

def display_parameter(value):
    text = '' if value is None else str(value)
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    text = re.sub('[ \\t]*[；;][ \\t]*', '\n', text)
    text = re.sub('\\n{3,}', '\n\n', text)
    return text.strip()

def column_name(number):
    result = ''
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result

def parse_rows(markdown):
    rows, active = ([], False)
    for line in str(markdown or '').splitlines():
        heading = re.match('^\\s*##\\s+(.+?)\\s*$', line)
        if heading:
            active = heading.group(1).strip() == 'BOM确认'
            continue
        if not active or not line.strip().startswith('|'):
            continue
        fields = [part.replace('\\|', '|').strip() for part in re.split('(?<!\\\\)\\|', line.strip().strip('|'))]
        if fields == HEADERS or all((re.fullmatch(':?-{3,}:?', x.replace(' ', '')) for x in fields)):
            continue
        if len(fields) == len(HEADERS):
            rows.append(fields)
    if len(rows) > 120:
        raise CapacityError('确认单超过120行，请分批，不会仅保留前120行')
    return rows

def _original_main(markdown: str, selection_json: str) -> dict:
    rows = parse_rows(markdown)
    if not rows:
        raise ValueError('没有可写入BOM确认单的选型结果')
    raw = gzip.compress((selection_json or '{}').encode('utf-8'), compresslevel=9, mtime=0)
    payload_b64 = base64.b64encode(raw).decode('ascii')
    chunks = [payload_b64[i:i + 24000] for i in range(0, len(payload_b64), 24000)]
    if len(chunks) > 25:
        raise ValueError('BOM上下文过大，超过确认Excel的25段容量')
    cells = {}
    cells['BOM确认!A130'] = 'FORM_TYPE'
    cells['BOM确认!B130'] = 'BOM_CONFIRMATION'
    cells['BOM确认!A131'] = 'SCHEMA_VERSION'
    cells['BOM确认!B131'] = 'bom-confirmation-v15.7'
    cells['系统数据!A2'] = 'FORM_TYPE'
    cells['系统数据!B2'] = 'BOM_CONFIRMATION'
    cells['系统数据!A3'] = 'SCHEMA_VERSION'
    cells['系统数据!B3'] = 'bom-confirmation-v15.7'
    for index, chunk in enumerate(chunks, 1):
        for target_sheet, row_no in (('系统数据', 3 + index),):
            cells['%s!A%d' % (target_sheet, row_no)] = 'PAYLOAD_CHUNK_%03d' % index
            cells['%s!B%d' % (target_sheet, row_no)] = 'PAYLOAD_B64_PART_%03d:%s' % (index, chunk)
    for row_number, row in enumerate(rows, 5):
        for column, value in enumerate(row, 1):
            if column in (4, 8):
                value = display_parameter(value)
            if column == 9:
                value = '【请工程师填写】'
            elif column == 10:
                value = '【如需修改请填写】'
            cells['BOM确认!%s%d' % (column_name(column), row_number)] = safe(value)
    return {'payload_json': json.dumps({'cells': cells, 'output_filename': 'BOM人工确认单_V17.3'}, ensure_ascii=False), 'summary': 'BOM确认%d行；参数按分号分行；前24行使用加高模板（插件不保证任意行自动行高）；选型上下文完整保留' % len(rows)}

def main(markdown, selection_json):
    try:
        decoded = wire_loads(selection_json)
        if isinstance(decoded, dict) and decoded.get('capacity_blocked'):
            raise CapacityError(decoded.get('capacity_message') or '本次容量超限，请分批重新提交原始资料')
        context = plain_json(decoded)
        out = _original_main(markdown, context)
        if len(out['payload_json'].encode('utf-8')) > 65000:
            raise CapacityError('确认单内容超过65KB插件请求预算，请分批。本次未生成可提交的完整确认单。')
        return out
    except CapacityError as exc:
        message = str(exc)
        sheet = 'BOM确认'
        cells = {sheet + '!A1': '本次输出容量超限，未生成完整确认单', sheet + '!A2': message, sheet + '!A130': 'FORM_TYPE', sheet + '!B130': 'CAPACITY_BLOCKED', '系统数据!A2': 'FORM_TYPE', '系统数据!B2': 'CAPACITY_BLOCKED'}
        return {'payload_json': plain_json({'cells': cells, 'output_filename': '容量超限提示_请分批重新提交'}), 'summary': message}

_v182_bom_payload_base=main
def main(markdown,selection_json):
    out=_v182_bom_payload_base(markdown,selection_json)
    context=wire_loads(selection_json)
    if context.get('capacity_blocked'):return out
    payload=json.loads(out['payload_json'])
    payload['output_filename']='BOM人工确认单_V18.2.1'
    cells=payload['cells']
    labels={'MATCHED':'参数可匹配','NEED_REVIEW':'待复核','MISSING':'未找到','NOT_RETRIEVED':'未召回'}
    number=4
    for item in context.get('items',[]):
        notes=list(dict.fromkeys(str(x) for x in (item.get('warnings') or [])+(item.get('mismatch_or_missing') or []) if x))
        alternatives=item.get('alternatives') or []
        if not notes and not alternatives and item.get('match_status')=='MATCHED':continue
        choices='\n'.join(str(row.get('material_name') or '')+' ['+str(row.get('material_code') or '')+']' for row in alternatives)
        row=[item.get('position_display') or item.get('symbol') or item.get('request_id'),item.get('shown_model'),
             labels.get(item.get('match_status'),item.get('match_status')),
             '\n'.join(notes) or '参数检查通过，待工程师确认项目适用性。',choices or '—']
        for column,value in enumerate(row,1):cells['选型说明!'+column_name(column)+str(number)]=safe(value)
        number+=1
    out['payload_json']=plain_json(payload)
    if len(out['payload_json'].encode('utf-8'))>65000:
        raise CapacityError('完整BOM及选型说明超过65KB传递预算，请按柜号分批；本次未生成部分确认单')
    out['summary']='已按实际条数生成确认表；参数自动换行并计算行高，核对原因与候选差异见“选型说明”。'
    return out

"""Stdlib-only XLSX geometry, embedded in Dify code nodes. No openpyxl in the sandbox."""
import base64 as _lx_b64
import io as _lx_io
import json as _lx_json
import math as _lx_math
import re as _lx_re
import unicodedata as _lx_unicode
import zipfile as _lx_zip
from xml.etree import ElementTree as _lx_et

_LX_NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
_LX_REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
_lx_et.register_namespace('',_LX_NS)
_lx_et.register_namespace('r',_LX_REL)


class LayoutCapacityError(ValueError):
    pass


def _lx_tag(name):return '{'+_LX_NS+'}'+name


def _lx_insert_before(parent,element,following):
    position=next((i for i,child in enumerate(parent) if child.tag in {_lx_tag(name) for name in following}),len(parent))
    parent.insert(position,element)


def _lx_col(number):
    result=''
    while number:
        number,remainder=divmod(number-1,26);result=chr(65+remainder)+result
    return result


def _lx_col_number(value):
    result=0
    for char in value:result=result*26+ord(char)-64
    return result


def _lx_lines(value,width):
    if value is None:return 1
    text=str(value).replace('\r\n','\n').replace('\r','\n')
    available=max(5,width-2)
    total=0
    for line in text.split('\n'):
        weight=sum(2.1 if _lx_unicode.east_asian_width(c) in ('W','F') else 1 for c in line)
        total+=max(1,_lx_math.ceil(weight/available))
    return total


def layout_template(template_base64,payload_json,spec):
    """Return a styled EMPTY template; the existing Excel plugin fills unchanged cell values."""
    payload=_lx_json.loads(payload_json)
    cells=payload.get('cells',{})
    if not isinstance(cells,dict):raise ValueError('Excel cells必须是对象')
    buffer=_lx_io.BytesIO()
    with _lx_zip.ZipFile(_lx_io.BytesIO(_lx_b64.b64decode(template_base64))) as original:
        files={name:original.read(name) for name in original.namelist()}
    book=_lx_et.fromstring(files['xl/workbook.xml'])
    rels=_lx_et.fromstring(files['xl/_rels/workbook.xml.rels'])
    targets={r.attrib['Id']:r.attrib['Target'].lstrip('/') for r in rels}
    names=book.find(_lx_tag('definedNames'))
    if names is None:
        names=_lx_et.Element(_lx_tag('definedNames'));_lx_insert_before(book,names,('calcPr','oleSize','customWorkbookViews','pivotCaches','extLst'))
    for item in list(names):
        if item.get('name') in ('_xlnm.Print_Area','_xlnm.Print_Titles'):names.remove(item)
    for index,sheet in enumerate(book.find(_lx_tag('sheets'))):
        name=sheet.get('name');config=spec.get(name)
        if name=='系统数据':
            sheet.set('state','veryHidden');continue
        if not config:continue
        target=targets[sheet.get('{'+_LX_REL+'}id')]
        path=target if target.startswith('xl/') else 'xl/'+target
        root=_lx_et.fromstring(files[path]);data=root.find(_lx_tag('sheetData'))
        start=config['start'];columns=config['columns'];minimum=config.get('minimum',start-1)
        values={}
        metadata=set()
        for key,value in cells.items():
            if '!' not in key:continue
            prefix,coordinate=key.rsplit('!',1)
            if prefix.strip("'")!=name:continue
            match=_lx_re.fullmatch(r'([A-Z]+)(\d+)',coordinate)
            if not match:raise ValueError('Excel单元格地址无效')
            row=int(match.group(2))
            if row>=130 and name in ('BOM确认','资料问题确认'):
                metadata.add(row);continue
            values[coordinate]=value
        rows=[int(_lx_re.search(r'\d+$',key).group()) for key in values]
        last=max([minimum]+rows)
        if config.get('hide_if_empty') and last<start:
            sheet.set('state','hidden')
            continue
        if last-start+1>120 and name not in ('01 报价汇总',):
            raise LayoutCapacityError(name+'超过120行，请分批；没有输出截断表格')
        widths=config['widths']
        merged_widths={}
        merges=root.find(_lx_tag('mergeCells'))
        for merged in merges if merges is not None else []:
            hit=_lx_re.fullmatch(r'([A-Z]+)(\d+):([A-Z]+)(\d+)',merged.get('ref',''))
            if hit and hit.group(2)==hit.group(4):
                first=_lx_col_number(hit.group(1));end=_lx_col_number(hit.group(3))
                merged_widths[hit.group(1)+hit.group(2)]=sum(widths[first-1:end])
        for row in list(data):
            number=int(row.get('r','0'))
            if number>=130 and name in ('BOM确认','资料问题确认'):
                row.set('hidden','1');row.set('ht','1');row.set('customHeight','1');continue
            if number>last:
                data.remove(row);continue
            if number<start:continue
            height=max([config.get('min_height',34)]+[
                9+16*_lx_lines(values.get(_lx_col(col)+str(number)),merged_widths.get(_lx_col(col)+str(number),widths[col-1]))
                for col in range(1,columns+1)])
            if height>409:
                raise LayoutCapacityError(name+'第'+str(number)+'行文字过长，超过Excel单行显示上限；请精简重复说明或拆分需求，未输出会截断的表格')
            row.set('ht',str(height));row.set('customHeight','1')
        dimension=root.find(_lx_tag('dimension'))
        if dimension is not None:dimension.set('ref','A1:'+_lx_col(columns)+str(max(last,max(metadata) if metadata else last)))
        filters=root.find(_lx_tag('autoFilter'))
        if filters is not None:filters.set('ref','A'+str(start-1)+':'+_lx_col(columns)+str(max(start-1,last)))
        properties=root.find(_lx_tag('sheetPr'))
        if properties is None:properties=_lx_et.Element(_lx_tag('sheetPr'));root.insert(0,properties)
        setup_properties=properties.find(_lx_tag('pageSetUpPr'))
        if setup_properties is None:setup_properties=_lx_et.SubElement(properties,_lx_tag('pageSetUpPr'))
        setup_properties.set('fitToPage','1');setup_properties.set('autoPageBreaks','1')
        setup=root.find(_lx_tag('pageSetup'))
        if setup is None:
            setup=_lx_et.Element(_lx_tag('pageSetup'));_lx_insert_before(root,setup,('headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        setup.attrib.update(orientation=config.get('orientation','landscape'),paperSize=str(config.get('paper',8)),fitToWidth='1',fitToHeight='0')
        margins=root.find(_lx_tag('pageMargins'))
        if margins is None:
            margins=_lx_et.Element(_lx_tag('pageMargins'));_lx_insert_before(root,margins,('pageSetup','headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        margins.attrib.update(left='0.25',right='0.25',top='0.35',bottom='0.35',header='0.15',footer='0.15')
        escaped="'"+name.replace("'","''")+"'"
        area=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Area','localSheetId':str(index)})
        area.text=escaped+'!$A$1:$'+_lx_col(columns)+'$'+str(last)
        repeat=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Titles','localSheetId':str(index)})
        repeat.text=escaped+'!$1:$'+str(config.get('header_end',start-1))
        files[path]=_lx_et.tostring(root,encoding='utf-8',xml_declaration=True)
    files['xl/workbook.xml']=_lx_et.tostring(book,encoding='utf-8',xml_declaration=True)
    with _lx_zip.ZipFile(buffer,'w',compression=_lx_zip.ZIP_DEFLATED) as output:
        for name,content in files.items():output.writestr(name,content)
    encoded=_lx_b64.b64encode(buffer.getvalue()).decode('ascii')
    if len(encoded)>55000:raise LayoutCapacityError('动态Excel模板超过传递预算，请分批')
    return encoded

_LAYOUT_TEMPLATE='UEsDBBQAAAAIAPEhXF1Gx01IlQAAAM0AAAAQAAAAZG9jUHJvcHMvYXBwLnhtbE3PTQvCMAwG4L9SdreZih6kDkQ9ip68zy51hbYpbYT67+0EP255ecgboi6JIia2mEXxLuRtMzLHDUDWI/o+y8qhiqHke64x3YGMsRoPpB8eA8OibdeAhTEMOMzit7Dp1C5GZ3XPlkJ3sjpRJsPiWDQ6sScfq9wcChDneiU+ixNLOZcrBf+LU8sVU57mym/8ZAW/B7oXUEsDBBQAAAAIAPEhXF1a9i3z8gAAACsCAAARAAAAZG9jUHJvcHMvY29yZS54bWzNksFOwzAMhl8F5d46bceEoi4XECeQkJgE4hY53hbRtFFi1O7tacvWgeABOMb+8/mz5BqDwi7SU+wCRXaUrgbftElh2IgDc1AACQ/kTcrHRDs2d130hsdn3EMw+G72BKWUa/DExho2MAGzsBCFri0qjGS4iye8xQUfPmIzwywCNeSp5QRFXoDQ08RwHJoaLoAJxhR9+iqQXYhz9U/s3AFxSg7JLam+7/O+mnPjDgW8Pj48z+tmrk1sWqTxV3KKj4E24jz5pbq9294LXcpynRUyK2+2cqWKa1VVb5PrD7+LsO+s27l/Zrz6ZnwW1DX8ugv9CVBLAwQUAAAACADxIVxd+lwBWfwCAADaDQAAEwAAAHhsL3RoZW1lL3RoZW1lMS54bWy1V9lS2zAU/RWP34u8LxkCw5K0D+20U/gBxZaXIsseSyHw95UVL7IdhbAkzIAlnXPPse7VVbi8fimw9oxqmpdkqZsXhq4hEpVxTtKlvmXJt0C/vrqEC5ahAmkEFmip32WQff/zqGucS+gCLvWMsWoBAI04CtKLskKEryVlXUDGh3UK4hrueMwCA8swPFDAnOh93BXmvwijzUSE64fogFizFj+ZzR/6Su9wrT1DvNR50LjcPaIXpmsYUsYXlrohProGri5Bz8JMQZaIa/HpiC0jfrIEsU43PdNYWYFjDgrWXmEOXAXNzxBRIGAU8dc1Z2DT9YzA6sASav94IHrom/aEICnYc4XQu7WcMcEeCM78Rdfh6t4dE5yB4M4IN4Z1G9pjgjsQvBnBWd341mpMEKgM5+RpDvf8IPA6eI9JSvzjID70PMO/7/ADDEiltg9A2KjwfidJHiFRdwX8V9ZrDhBZhiwnGnutUAKjpkAhzjd1rv3M04wJHbhA8A1ARI8CwESzyMmbBo5IHxHt5QYFIG+G2JqCKY9kkmP8wF4x+kmFOVriPF7zSTEQrD4VVcYfO8ERMK3h8EzbUCnVqpLyEtSVsUQHyQnbz3l+d+r5Jm2LX2XcFr1pDAsUsmHBcKU+0SuIUUplD66IcKIP31b4GOSmPuwTfZjGe4wE5ruNhEeNACk9/BhpsLklXKdttzSCGMVNwtoAo7R+SYpDR/VG1me39oQU0wzGqItrqJyois00vjDJkhU/OOwkDBVGrONGPpxkMG8HmIxH2q7R97u3+1CzqGrK7iHN9jix1N+vRJIJeZWfX8ZqduZ8MmC6hyhJUMQUM8OQr7VRDi5/Ft0Myi1D9UMW77QN3tZ/IS8K1zf5nmtxTlmXAD6oh/KZf78Y5iGuMth28tGh3ePFc68pmRV2ptbBoZ3apOsvua7eZk26lqrd+uqTeIb7MZTuJal/hIr+oe6p7qmd7F3XpuxDtqdstLbCnn2mRuupBM/YUKclC6SvY2I0+Qeqm7n6D1BLAwQUAAAACADxIVxdNZKu6ZgUAAA5twAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbLWdXXPbRppG/4pKM5XavZgI/YEvW1aV061WtyqOXfbsbO1VirFoWzWSqKHoOJlfvyBIIJTSfbq1VXsTETh48IIPmrROLoTTb6v1Px++LJebo99ub+4eXh1/2WzuX5ycPHz8srxdPHy/ul/eDeTTan272Ayb688nD/fr5eJqDN3enMiqak5uF9d3x2en475367PT1dfNzfXd8t366OHr7e1i/fsPy5vVt1fH4nja8f7685fNdsfJ2en94vPyw3LzX/fv1sPWyXyWq+vb5d3D9eruaL389Or4tXhxKdSYGA/5x/Xy28PB66OHL6tvF+vrqx+H0cM7qY6Ptu/ul9Xqn1scrra7ttPulke/f7i/uR7m6+Ojzer+x+WnjVne3Awz6uOjxcfN9a/Ld8Nhr45/WW02q9stH658s9gMuz6tV/9e3o1XsbxZDscO13f/p4N3J9mfdPu2/7V/D8fzW9xe1OHr6b24seuhu18WD0uzuvnv66vNl1fH3fHR1fLT4uvN5v3qm1/u+6u35/u4unkY/3v0bXdsc3z08evDcDH77PYCNr/fDNfY9MdHt9d3467bxW/7O3AQFSqflfusfJKVIp9V+6x6ktU6n9X7rH46t81n6322fvp++3y22Webp1mZz7b7bPs0W3DN3T7b/R+y/T7bP+2qLlgb1bQ4qnG57tbXuDjtYrM4O12vvh2tx+h2Ear51s3LcjjneL5h9PbA17sd3TBgoNd32y+HD5v1gK+HE2/OvvuLrEWlXw4/ZdeK7c+m7rrhZ1OrVr784e2bYVcl6vEQXal2+KmqTlXbn3Wrt4dKoZR6eXqyGa54e9qTj/vpP+ymi3H49ntqJiZJbJKcJ4lLkosk8UkSkuQyRk6GezLfGLm/MTJ7Y+S4o6+SN0bpSqhty0r1etdy1Yw3Svf19mdVyXG70U2//TncFD3eleF+bbfbVmy3Rd93cjy+rrY51XTteF6pm3Z3w6Ueb7jst8fpqtGa5spG7eZ3XX+4KoTUarfdjvN0p9vd9TT1bkFVu+1uvK5h/m5VCT3ul8OAatzezX96vQPV43VoJeXBeTspq8PDpBZiN0aOi7MRY03DYdvdQsq+iq5VmVyrSWKT5DxJXJJcJIlPkpAklzHyaK2q/VrtsmtV7daqSK7V6R50Td0cLL3tLT/ofliX4x1Tut8dLio1roRmuOXjraqqcUXVqh6PV7quDm7psFL6+mClblf2/rz94XmHlbLL1VLsVli1W1mVlPUu1+9WYL2bPyzYP9bGuHTUft7uk/NoxR+F8cjh1eXReG5xuLqHQ9u2YPUOy7KSh5+i/TId8k23/3Q0kfc+fTri1x5b1yq5rpPEJsl5krgkuUgSnyQhSS5j5NG61vt1XWXXtd6ta5n+x1HL3V0d24+1mz+FlGq8oY0aFtHJ9o6rStA5Tf6cVVftvuuE3C/s/UKvxf6rWDSxU9uSU4+fPdWJfvoM7f+VEbv1p/W4but+WKeREef5EXUtxi/w7ef+T0s8ckqXP2Uv95+i3TfI409H5JQXBVfZ7z6IrZJt7BQ+ewo1fNHUu89yO15dr5rdd0DdRk8ZChZk/B/bx7+SRU59WXDndbO/s0L96d/vx6d89Hmrd5+3XmQ/b/XuGtSfP9U/pJFJI7tHOvJFlU65PaojX1XplE/PCnvURL6t9qhNf101xfU16frSyKSRbdL1pVOuSdeXTvn0rNCk62uy9bXF9bXp+tLIpJFt0/WlU65N15dO+fSs0Kbra7P1dcX1den60sikke3S9aVTrkvXl0759KzQpevrsvX1xfX16frSyKSR7dP1pVOuT9eXTvn0rNCn6+uz9W3/f0dhf9tDUwUCM8DsxGIdQs5NLNYi5DzMCxOLFTkxalKUNymgyTQzwOzEok2mc25i0SbTOQ/zwsSiTYp8k7K8SQlNppkBZicWbTKdcxOLNpnOeZgXJhZtUuabVOVNKmgyzQwwO7Fok+mcm1i0yXTOw7wwsWiTKt+kLm9SQ5NpZoDZiUWbTOfcxKJNpnMe5oWJRZvU+SbLbUWArgAzwKwAY4GcE+AskPMwLwjQFpH3FlEuLgLMBZgBZgXIC+ScAH2BnId5QYDBiLzCiHKHESAxwAwwK8BjIOcEmAzkPMwLAmRG5G1GlOuMAJ8BZoBZAUoDOSdAaiDnYV4Q4DUiLzai3GwEqA0wA8wKsBvIOQF+AzkP84IAxRF5x5HljiPBcYAZYFaC40DOSXAcyHmYFyQ4jsw7jix3HAmOA8wAsxIcB3JOguNAzsO8IMFxZN5xZLnjSHAcYAaYleA4kHMSHAdyHuYFCY4j844jyx1HguMAM8DsxKJNguNMLNokOA7MCxOLNpl3HFnuOBIcB5gBZiU4DuScBMeBnId5QYLjyLzjyL3jyCbfJDgOMAPMSnAcyDkJjgM5D/OCBMeReceRTXmT4DjADDArwXEg5yQ4DuQ8zAsSHEfmHUe25U2C4wAzwKwEx4Gck+A4kPMwL0hwHJl3HNmVNwmOA8wAsxIcB3JOguNAzsO8IMFxZN5xZF/eJDgOMAPMSnAcyDkJjgM5D/OCBMeRecdRVXGTChwHmAFmFTgO5JwCx4Gch3lBgeOovOMoUd4kOA4wA8wqcBzIOQWOAzkP84ICx1F5x1GyvElwHGAGmFXgOJBzChwHch7mBQWOo/KOo1R5k+A4wAwwO7Fok+A4E4s2CY4D88LEok3mHUfp8ibBcYAZYFaB40DOKXAcyHmYFxQ4jso7jip3HAWOA8wAswocB3JOgeNAzsO8oMBxVN5xVLnjKHAcYAaYVeA4kHMKHAdyHuYFBY6j8o6jyh1HgeMAM8CsAseBnFPgOJDzMC8ocByVdxxV7jgKHAeYAWYVOA7knALHgZyHeUGB46i846hyx1HgOMAMMKvAcSDnFDgO5DzMCwocR+UdR5c7jgbHAWaAWQ2OAzmnwXEg52Fe0OA4Ou84utxxNDgOMAPManAcyDkNjgM5D/OCBsfRecfR5Y6jwXGAGWBWg+NAzmlwHMh5mBc0OI7OO44udxwNjgPMALMTizYJjjOxaJPgODAvTCzaZN5xdLnjaHAcYAaY1eA4kHMaHAdyHuYFDY6j846jyx1Hg+MAM8CsBseBnNPgOJDzMC9ocByddxxd7jgaHAeYAWY1OA7knAbHgZyHeUGD4+i84+hyx9HgOMAMMKvBcSDnNDgO5DzMCxocR+cdR5c7jgbHAWaAWQ2OAzmnwXEg52Fe0OA4Ou84utxxNDgOMAPManAcyDkNjgM5D/OCBsfRecepyx2nBscBZoDZGhwHcq4Gx4Gch3mhBsep845TlztODY4DzACzNTgO5FwNjgM5D/NCDY5T5x2nLnecGhwHmAFma3AcyLkaHAdyHuaFGhynzjtOXe44NTgOMAPMTizaJDjOxKJNguPAvDCxaJN5x6nLHacGxwFmgNkaHAdyrgbHgZyHeaEGx6nzjlOXO05Nfz6A/n4A/QEB+gsC9CcE6G8I0B8RoL8iQH9GIO84dbnj1OA4wAwwW4PjQM7V4DiQ8zAv1OA4dd5x6nLHqcFxgBlgtgbHgZyrwXEg52FeqMFx6rzj1OWOU4PjADPAbA2OAzlXg+NAzsO8UIPj1HnHqcsdpwbHAWaA2RocB3KuBseBnId5oQbHqfOO05Q7TgOOA8wAsw04DuRcA44DOQ/zQgOO0+Qdpyl3nAYcB5gBZhtwHMi5BhwHch7mhQYcp8k7TlPuOA04DjADzDbgOJBzDTgO5DzMCw04TpN3nKbccRpwHGAGmJ1YtElwnIlFmwTHgXlhYtEm847TlDtOA44DzACzDTgO5FwDjgM5D/NCA47T5B2nKXecBhwHmAFmG3AcyLkGHAdyHuaFBhynyTtOU+44DTgOMAPMNuA4kHMNOA7kPMwLDThOk3ecptxxGnAcYAaYbcBxIOcacBzIeZgXGnCcJu84TbnjNOA4wAww24DjQM414DiQ8zAvNOA4Td5xmnLHacBxgBlgtgHHgZxrwHEg52FeaMBxmrzjtOWO04LjADPAbAuOAznXguNAzsO80ILjtHnHacsdpwXHAWaA2RYcB3KuBceBnId5oQXHafOO05Y7TguOA8wAsy04DuRcC44DOQ/zQguO0+Ydpy13nBYcB5gBZicWbRIcZ2LRJsFxYF6YWLTJvOO05Y7TguMAM8BsC44DOdeC40DOw7zQguO0ecdpyx2nBccBZoDZFhwHcq4Fx4Gch3mhBcdp847TljtOC44DzACzLTgO5FwLjgM5D/NCC47T5h2nLXecFhwHmAFmW3AcyLkWHAdyHuaFFhynzTtOW+44LTgOMAPMtuA4kHMtOA7kPMwLLThOm3ecttxxWnAcYAaYbcFxIOdacBzIeZgXWnCcNu84XbnjdOA4wAww24HjQM514DiQ8zAvdOA4Xd5xunLH6cBxgBlgtgPHgZzrwHEg52Fe6MBxurzjdOWO04HjADPAbAeOAznXgeNAzsO80IHjdHnH6codpwPHAWaA2YlFmwTHmVi0SXAcmBcmFm0y7zhdueN04DjADDDbgeNAznXgOJDzMC904Dhd3nG6csfpwHGAGWC2A8eBnOvAcSDnYV7owHG6vON05Y7TgeMAM8BsB44DOdeB40DOw7zQgeN0ecfpyh2nA8cBZoDZDhwHcq4Dx4Gch3mhA8fp8o7TlTtOR8/CoYfh0NNw6HE49DwceiAOPRGHHolDz8TJO05X7jgdOA4wA8x24DiQcx04DuQ8zAsdOE6Xd5y+3HF6cBxgBpjtwXEg53pwHMh5mBd6cJw+7zh9ueP04DjADDDbg+NAzvXgOJDzMC/04Dh93nH6csfpwXGAGWC2B8eBnOvBcSDnYV7owXH6vOP05Y7Tg+MAM8DsxKJNguNMLNokOA7MCxOLNpl3nL7ccXpwHGAGmO3BcSDnenAcyHmYF3pwnD7vOH254/TgOMAMMNuD40DO9eA4kPMwL/TgOH3ecfpyx+nBcYAZYLYHx4Gc68FxIOdhXujBcfq84/TljtOD4wAzwGwPjgM514PjQM7DvNCD4/R5x+nLHacHxwFmgNkeHAdyrgfHgZyHeaEHx+nzjtOXO05Pj/6kZ3/Swz/p6Z/0+E96/ic9AJSeAEqPAC15Bmi55IzHprokaAjaGcbqpKSbYaxQSnqaGWYY63SGWGq574zHpksF4yFoZxgvFaRnhvFSQXtoZphhvNS8+YiqXH3GY9Ol0sNBAdoZxkul54NWIECU9DQzzDBeasFDQqtyCxqPTZcKHkTQzjBeKqjQDOOlggzRzDDDeKl5HxJVuRCNx6ZLBSUiaGcYLxWsaIbxUsGLaGaYYbzUvBqJqtyNxmPTpYIdEbQzjJcKgjTDeKmgSDQzzDBeat6SRFWuSeOx6VJBlAjaGcZLBVeaYbxUsCWaGWYYLzUvTKIqN6bx2HSp4EwE7QzjpYI2zTBeKogTzQwzjJeadydRlcvTeGy6VHq8KEA7w3ip9ITRChSKkp5mhhnGSy14zGhV7lHjselS6UmjAO0M46XSw0YrsClKepoZZhgvtcCoxDOMSpBRATQE7QyjpULSzTBaKiQ9zQwzjJYqCoxKPMOoBBkVQEPQzjBeKhmVIKOCpKeZYYbxUguMSjzDqAQZFUBD0M4wXioZlSCjgqSnmWGG8VILjEo8w6gEGRVAQ9DOMF4qGdUE46WSUcHMMMN4qQVGJZ5hVIKMCqAhaGcYL5WMSpBRQdLTzDDDeKkFRiWeYVSCjAqgIWhnGC+VjEqQUUHS08www3ipBUYlnmFUgowKoCFoZxgvlYxKkFFB0tPMMMN4qQVGJZ5hVIKMCqAhaGcYL5WMSpBRQdLTzDDDeKkFRiWeYVSCjAqgIWhnGC+VjEqQUUHS08www3ipBUYlnmFUgowKoCFoZxgvlYxKkFFB0tPMMMN4qQVGJZ9hVJKMCqAhaGcYLRWSbobRUiHpaWaYYbRUWWBU8hlGJcmoABqCdobxUsmoJBkVJD3NDDOMl1pgVPIZRiXJqAAagnaG8VLJqCQZFSQ9zQwzjJdaYFTyGUYlyagAGoJ2hvFSyagmGC+VjApmhhnGSy0wKvkMo5JkVAANQTvDeKlkVJKMCpKeZoYZxkstMCpZH5S2l4UuWloaGoKW4DlBR/CCoCcYCF4m4JPSmoPSGiotDQ1BS/CcoCN4QdATDAQvE/BJae1BaS2VloaGoCV4TtARvCDoCQaClwn4pLTuoLSOSktDQ9ASPCfoCF4Q9AQDwcsEfFLa4T8EPZWWhoagJXhO0BG8IOgJBoKXCfi4NFX9UZra/zLej8df391c3y0/bNbDAdcPZ6ebM/f2/Zuf//4/785PTzbDebY7D1rNpX94++Zn8/YnF96/ef338PanyEnMk5M8aR/gOUFH8IKgJxgIXibgk/bFQfuC+/tg/Pmb1z//4/z9h3h7P2RP8cvq9m8fV3efrte3i8316u5vvwr9fRO/EYJuRBqeE3QELwh6goHgZQLubsTJw5flcmMXm8XZ6eLrZuWubzbL9dF6+Wn7FLAX42+oJ2ent8v156VZ3tw8HH1cfb0bTqOOD/bujxfD8Y+O3u9XLy5VbL98cSm3+0/+OP1w0au7q+vtzVncuNX2Pm2u7z4fPfxrF6lfjL8ZDod9ev/1Znm0+f1++ep4+dv9evnwMISOj+7X16v19eb38dfjq98+hatXx9vP+KfhZF9vFmc/nv/0H3819X9+93nzsjo9mXYPnYxn3L6IXUHmwkL94rL4wuR8YeL//cJeP+fC1Hxh8uDC/vq6/u5m83J7XcfHz7mw4cR3m7f3W/Bw9GWY8e/V3WZxY5Z3wxpbjm9/uPv3i8/LN4v15+vhoJvlp2FtVd8PvyKsd44zvt6s7sdXw++ov6w2gwFNW1+Wi6vlers1XPqn1WozbQzn3TE37jw7XV1d+XHHcLkHr4eX+yO+W9zevzTjf/uj7/6iRK3ky6Nx+912u69k//LoZHgpq073e/TTjMbTTtOWvy7v5nGHG9vX00EnhxvDd9LDZo482ho35tDjrcdv8uTbav3P8RN99r9QSwMEFAAAAAgA8SFcXf9C7MpPAwAApgwAABgAAAB4bC93b3Jrc2hlZXRzL3NoZWV0Mi54bWyFl9Fu2jAYhV8lyqTdtYkdEpIWkKBr1UqjIOg67aoKYCBqEjPHLe2efr+dEOPNmBsc+9ifj81xML09Za/VlhDufBR5WfXdLee7K8+rlltSpNUl3ZESlDVlRcqhyjZetWMkXclBRe5h34+8Is1Kd9CTbVM26NE3nmclmTKneiuKlH2OSE73fRe5h4ZZttly0eANert0Q+aE/9hNGdS8lrLKClJWGS0dRtZ9d4iuRoEvBsgezxnZV0fPjljKgtJXUXlY9V3fFeiSOJ/zXZ7JyRxOd9/Jmt+QPAcgdp10ybN3MoVufXdBOaeF0MEmTzk0rRn9Q0o5J8kJ9AUz9ZAGIVb0u7Hntu6FhePng887uY2wLYu0Ijc0/5mt+Lbvxq6zIuv0Leczur8nzdaEgrekeSU/nX3dF0eus3yrwGgzWDjgnzmYjRLXKbJSNhXpR7O7R2O78fmxuBmL5Wrq6aX3bylPBz1G9w6TA4VH+DoaYOsaiJIGE4uOw7ohBiyoWSliMecM5AzAfPD1S4CSJLyGEne6CZQ4COJAlN2wG1z3PA42RF9v2SBHZ5E4TKJYIMJO2IEyCnEs6kGAQ9mOUOSLMknqqULkN/0SLPqFcYBkP/AkSr8TYdkvQUHDS/6x5sHOtNuD2+Xjej/iE17vJrPxy9Ov6a1pnWfGjibjl5vJ493DbDx8epg8WvwErZ/Azpzf3N+Ohy/Pt7P5f8Ta1BnAghYXS1quMxF0OC0X76hzGVmsdVprnWOyeJ2oSY2ShglbTHgaY5Q0TNRiotMYo6Rhui2mexpjlDRM3GLi0xijpGHUYUxOY4yShkG+OtT+aZBZ00lIkZCFZNR0kjppCFtIRk0nqTOCAgvJqOkkFWlkybRZ00kq1cgSa7Omk1SwkSXZZk0nqWwjS7jNmk5S8UaWfJs1nXT0c2OJuFnTX9wq49iScbOmk1TGsSXjZk0nHf2aWDJu1nSSyji2ZNys6SSVcWzJuFnTSSrj2JJxs6aTVMaxJeNmTSepjGNLxs2aTlIZx5aMmzWdpDKOLRk3a/plQGU8sGTcrNUk7+hGKG7v45RtsrJycrg7w8X7EjaG1fdB+Qy3bvkE32F9xz7UtvBHgjBRg8itKeWHirh7tn9NBn8BUEsDBBQAAAAIAPEhXF1IGvtVDgoAAEJVAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDMueG1sjdxtb9poFsbxr4Ko1JeDn3jwNIk0Ped0Z6XZ3Wqq3X1NE6dBAzgL7mQ6n35tQ7h9M5x/edMEfn64MFSXWnzum5d699v+qaqa0R+b9XZ/O35qmucfJ5P9/VO1We5/qJ+rbSuP9W6zbNqHuy+T/fOuWj70O23WkyxJZpPNcrUd3930z33c3d3UX5v1alt93I32Xzeb5e7b+2pdv9yO0/HrE7+uvjw13ROTu5vn5ZfqU9X8+/njrn00OR3lYbWptvtVvR3tqsfb8U/pj5ZmebdHv8l/VtXLfvD7aP9Uv/xtt3r4pT11+0qS8ah7dZ/r+reO//7QPdWdbVuNvn16Xq/a8+fjUVM//1I9NlKt1+05ivFoed+sfq8+tpvdjj/XTVNvOm+TN8umfepxV/9ZbfsU1bpqt23zPf9l48NBjgftXvb/jq9hfHqJXajh76+v5UN/rdtr93m5r6Re/3f10Dzdjhfj0UP1uPy6bn6tX36ujtdv2h3vvl7v+z9HL4dt0/Z13X/dt2mOO3cJmm/rNuSsHI82q23/1Gb5x/EtGOybTb+/b3bcNzvbNy2/v29+3Dc/23eefX/f4rhvcbZvsfj+vtPjvv0VmxwuWX+9ddks72529cto1+/YXde8eD3g6Uq3R+yP1p642/CnwxNp0n7MWl5tuw/8p2bX+qo9cnP39k0+W8zzd2/fZFmRpt3P2WyRdD/zaTFtf+bTRbbon0+zWfszLctF1j1Opknvr/sXSTHrf+ZZ9u5m0rT5u3NM7o9Z3h+z9Em6v4gnEVfUFbskk/b6nC5SdroIWb9pWf71KO99Ep/UJ7tIUa78lCs/vjmp++ZkSZ70b0palNOLF/X7x8hn6azo38AkKfs3NDsccz5Pi+Eb751DrsiZ5ocPwzwt592xynx2+DBM5/NLx9QrjokfxAvHtGuu59mHNnrt/c9pd848m+bdtcmTeZaenSt6M4vTm1kcT55d+JSBCZiC2WWLwk1P4aYQDkzAFMwuWxRudgo3g3BgAqZgdtmicPNTuDmEAxMwBbPLFoVbnMItIByYgCmYXbYoXKieEsKBCZiC2WWLwqVJKMYE4hEKoRKag3HENERMKSKgECqhORhHDM2aZhQRUAiV0ByMI4aSTXOKCCiESmgOxhFDdaTUHYRCqITmYBwxFEhKDUIohEpoDsYRQ42k1COEQqiE5mAcMZRJSm1CKIRKaA7GEUOlpNQphEKohOZgHHHwbxpqFkIhVEJzMP4HR2iXjNqFUAiV0ByMI4Z2yahdCIVQCc3BOOLg323ULoRCqITmYBwxtEtG7UIohEpoDsYRQ7tk1C6EQqiE5mAcMbRLRu1CKIRKaA7GEUO7ZNQuhEKohOZgHDG0S0btQiiESmgOxhFDu2TULoRCqITmYBwxtEtG7UIohEpoDsb/bRTaJad2IRRCJTQH44ihXXJqF0IhVEJzMI4Y2iWndiEUQiU0B+OIg/8gpHYhFEIlNAfjiKFdcmoXQiFUQnMwjhjaJad2IRRCJTQH44ihXXJqF0IhVEJzMI4Y2iWndiEUQiU0B+OIoV1yahdCIVRCczCOGNolp3YhFEIlNAfj/8cO7VJQuxAKoRKag3HE0C4FtQuhECqhORhHDO1SULsQCqESmoNxxNAuBbULoRAqoTkYRxx8qYLfquDXKvi9Cn6xckW7FKFdCmoXQiFUQnMwjhjapaB2IRRCJTQH44ihXQpqF0IhVEJzMI4Y2qWgdiEUQiU0B+OIoV0KahdCIVRCczD+IjK0y5TahVAIldAcjCOGdplSuxAKoRKag3HE0C5TahdCIVRCczCOGNplSu1CKIRKaA7GEUO7TKldCIVQCc3BOOLgi3v85h6/usfv7vHL+yvaZRraZUrtQiiESmgOxhFDu0ypXQiFUAnNwThiaJcptQuhECqhORhHDO0ypXYhFEIlNAfjO0lCu8yoXQiFUAnNwThiaJcZtQuhECqhORhHDO0yo3YhFEIlNAfjiKFdZtQuhEKohOZgHDG0y4zahVAIldAcjCOGdplRuxAKoRKag3HEwc1heHcY3h6G94fhDWJXtMsstMuM2oVQCJXQHIwjhnaZUbsQCqESmoNxxNAuM2oXQiFUQnMwvhUwtMuc2oVQCJXQHIwjhnaZU7sQCqESmoNxxNAuc2oXQiFUQnMwjhjaZU7tQiiESmgOxhFDu8ypXQiFUAnNwThiaJc5tQuhECqhORhHDO0yp3YhFEIlNAfjiIMbkPEOZLwFGe9BxpuQr2iXeWiXObULoRAqoTkYRwztMqd2IRRCJTQH43u5Q7ssqF0IhVAJzcE4YmiXBbULoRAqoTkYRwztsqB2IRRCJTQH44ihXRbULoRCqITmYBwxtMuC2oVQCJXQHIwjhnZZULsQCqESmoNxxNAuC2oXQiFUQnMwjhjaZUHtQiiESmgOxhEHQy445YJjLjjngoMuV7TLIrTLgtqFUAiV0ByMh3FCu5TULoRCqITmYBwxtEtJ7UIohEpoDsYRQ7uU1C6EQqiE5mAcMbRLSe1CKIRKaA7GEUO7lNQuhEKohOZgHDG0S0ntQiiESmgOxhFDu5TULoRCqITmYBwxtEtJ7UIohEpoDsYRQ7uU1C6EQqiE5mAccTBIiZOUOEqJs5Q4THnVNOVwnJLnKXmgkicqeaTympnKZDBUmeBUJamgKqp5ehZ0MFqZUNegCqqimqdnQQcDlglOWJIKqqKap2dBB2OWCc5ZkgqqopqnZ0EHw5YJTluSCqqimqdnQQcjlwnOXJIKqqKap2dBB4OXCU5ekgqqopqnZ0EH45cJzl+SCqqimqdnQQdDmAlOYZIKqqKap2dD9INm4kl/HvXnWX8e9r9u2n847s/z/jzwzxP/PPJ/TTMNh/556p/H/nnunwf/r5r8H47+8+w/D//z9D+P/181/z9cAIBXAOAlAHgNAF4E4KpVAIbLAPA6ALwQAK8EwEsBXLUWwHAxAF4NgJcD4PUAeEGAq1YEGC4JwGsC8KIAvCoALwtw1boAw4UBeGUAXhqA1wbgxQGuWh1guDwArw/ACwTwCgG8RMA1awSkg0UCUlwlAFVQFdU8PQs6aCZcKwBVUBXVPD0LOlyOBpsJlwxAVVTz9CzooJlw3QBUQVVU8/QQdDJYaXD5tak/rNZNtTuua5mf1rXcVLsv/aKR+9F9/XXbHqb7qJyeHayD2S9iGDa/u3nerbbNv5675Sj3o6d6t/qz3jbLtVTb9kTVw21YavMfy92XVbvRunpsT5D80H2xvzsscnh40NTP3eajw3qW/a9P1fKh2nUbtP5Y183rg/aYB/vQP3l3Uz88/Nw/0eYb/N7+etzi7XLz/E76P8vR2zd5Os2zd6P+8cfucZlk5bvRZNQtKbcoyiP980T9YV/PVv1ebU+nGz7ofn/daDJ88Lja7ZvTLtGj/sFpp/hR/CInp2VT7/4PUEsDBBQAAAAIAPEhXF1BkwRedAUAAKVQAAANAAAAeGwvc3R5bGVzLnhtbO1cXW+jOBT9K4gfMJjPwCqJlNKi3YddrTTzMPtIEydBgsCA203n168N6QANtwvBDs5MU7UB7Ht87vXxFwXPC/IS4897jIlyTOJDsVD3hGS/aVqx3uMkLD6lGT7QlG2aJyGhp/lOK7Ich5uCGSWxZiDkaEkYHdTl/PCUBAkplHX6dCALFanacr5ND/UV3VarKzRvmGDlOYwXqh/mcURSlrn4Xl3SdXamVTnf5v8zWudpkW6J8k/4O45YzseTGTtep3GaK/nucaEGp08LejYMugVnINO2Vi04NALOnjn3rjEGbojjA2M62m5MZFaWs0ION7iuevtkc665UYBdDg8FvNwSkBFCHTJyxUEPbJpDoJsiLr8KWkQUx3XXpKvVleU8CwnB+SGgJ6VRefEsSTkdf3nJ8ELd5eGLbpzC3segSONow4rc+U0d6K5pWSV1rWE6EvRhFRjBijNoYAcz7qCGYdsu4gyqB9bDzL0JpvxrH6Gy9vm6j5A+Mx37HgQtv2gTe0zzDc5/NDI2/FeXtLOD5TzGtHWXM5KFSvbljKLdR6I75FchZ1mX8zza7ftalHmXc5JmPQ1oTkaNkDTpaVFlLg8qh/o65gV3M98e4ljDop9jDYOejjUsLnQMId+9dx4GONay6ONYy6CXYy2LM8dOB1S5axzHnxnI1209RlCo41apprl/bNgMV2Fjyesh1fzpsIJhJ9XA00SrsJuwyLwAmJ5k0XNK7p6oD4fy/NtTSvDfOd5Gx/L8uK0yapfQ5oxu8OeuT4UeZln8soqj3SHBlS56F7ich692yj7No++0NDZBYc2jVMpxKxUl5RnnJFqz8zXNgPP/JQnVOR9FQSEQji5bnQukNKrOTf4t0ZgKnVOA/83D7As+ktfB4L1IimdzXt2y8zuT4yDGkDb59BhQPISjS6RNkV2R7Py4adPi37OZU6FPoE3xbMZpcwp+YrTJp2eD4iEcXSJtytJvTsGPmzZt/j2bNRX6BNoUz6ZZ95fU9TQMxeiTT+8GRUQ4ukT6FNM38dSnWIbc9Imm74MgNtMoTnxsxNQdv2iN42dLHj+InyzxcySPH8RPlvgZkscP4vfrxI//eCY+ppw4W57kQu1DcFKlXjeCXBau140p77X2jQR5st6AB+OZjF1BD36yjFmNNZiAJwHeQRfl/aUOc78FIOh/zoMdFr+qkGsNIdeKQa71gVyxqaVM0ozbbRiBN/IM2SbFPYZu85fmLDu/q82SJaPcY4YkiwganYFzK53BdR93BDlfGlo5poeCKN1I5PiLssF5disNqcHZlTrO040BN3NPj786xA9d1+P8Eefbui3Fm7FuAHOGa/0nYPAa0K0JT/DQ6mC63qTPig2mO/UaeIwcWk3O+iB8uSCaI/TNBViH7hJ9MObUSei6cL4i2IlYXw5n13h4WEdiRoQx9CyInhzRa9StN5nytNP7yI2XnluvPP+4qrDtOBbqX2wzoLh1D7p+wZmibI71u83szeYNK+Rsm4Hl/PHNhhJm4AbvbClQwvTFomg+vDlFA6v35gPO3cz3Bm0+UFv03HygNui7+UBtcf4qe+ke+1ucrOh3dNjgI974p1MK09rVofowvLcp9ZYq5ymQTZXWncLSoHIgBpBNZQWV8zP544L+VGkQN7czxQVtXNCmsupK8csfqJxuG49+uj31PNN0HCiivt/JwIfi5jjstxsN4sYsoHJYScNiDdc2rJD3dQDV6XsKgTyFlQh5CseapXTHjVl4XndtQ+UwC6gWIO2w8rvLYZrqtjFNVqsQN6gFwymeB6UwLXZr1HGA6Djsp7t+oFZimp7XncLSuhmYJpTCWiOcAjFgHKAU0yxHrTfjkfY6Tmn1xoTL/wBQSwMEFAAAAAgA8SFcXZeKuxzAAAAAEwIAAAsAAABfcmVscy8ucmVsc52SuW7DMAxAf8XQnjAH0CGIM2XxFgT5AVaiD9gSBYpFnb+v2qVxkAsZeT08EtweaUDtOKS2i6kY/RBSaVrVuAFItiWPac6RQq7ULB41h9JARNtjQ7BaLD5ALhlmt71kFqdzpFeIXNedpT3bL09Bb4CvOkxxQmlISzMO8M3SfzL38ww1ReVKI5VbGnjT5f524EnRoSJYFppFydOiHaV/Hcf2kNPpr2MitHpb6PlxaFQKjtxjJYxxYrT+NYLJD+x+AFBLAwQUAAAACADxIVxdB3zK2UYBAAAhAwAADwAAAHhsL3dvcmtib29rLnhtbLWSTUvDMBjHv0oNhd2WrRUPpSsoU5zgC/gBRtY+tWF5KUnUefMqojfBkyJ4noLe9nnc5rcw66x2ICLCTkl4wv/3e/IkPJWq35Oy7ww4E7qFMmPyAGMdZ8CJrsschK2kUnFi7FEdYZ0rIInOAAxn2Gs01jAnVKAoLLMOFI7C4oL+XOfpgfpLvkxTGkNbxscchJkDFDBiqBQ6o7lGjiAcWmhjf3fyMJwOH5FTQDpJCzXt3hBjqydU0x4D5KiA2oLqJE2El6kzeRlNRvfjm+fx1bBi5H0bgTrbpkkCoiLlLVfq/fzi7e5y+vQ6vr2uSPm/PJM/M8Ll+BJIqYBkz6Ytnj4B3QETvN7dosyAahNDekTbNCZjwg5LXAM5WdH4bEBR7WtwtRV33V0N3B236fkhrqT/G+Utoqr9FzQ/cDd/oOHFPnH5laMPUEsDBBQAAAAIAPEhXF27bOrsugAAABoDAAAaAAAAeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHPFkzkOgzAQRa+CfACGJUkRAVUa2ogLWDAsYrHlmShw+xAowFKKNIjK+mP5/VeMoyd2khs1UN1ocsa+GygWNbO+A1BeYy/JVRqH+aZUppc8R1OBlnkrK4TA825g9gyRRHumk00a/yGqsmxyfKj81ePAP8DwVqalGpGFk0lTIccCxm4bEyyH785k4aRFLExa+ALOFgosoeB8odASCg8UIp46pM1mzVb95cB6nt/i1r7EdWgvyfXrANZXSD5QSwMEFAAAAAgA8SFcXab8SlsjAQAA3wQAABMAAABbQ29udGVudF9UeXBlc10ueG1szZTPTsMwDMZfpep1ajKGxAGtuwBX2IEXCI27Rs0/xd7o3h633SaBRsU0JLg0amx/P8efkuXrPgJmnbMey7whivdSYtWAUyhCBM+ROiSniH/TRkZVtWoDcjGf38kqeAJPBfUa+Wr5CLXaWsqeOt5GE3yZJ7CYZw9jYs8qcxWjNZUijsud118oxYEguHLIwcZEnHFCLs8S+sj3gEPdyw5SMhqytUr0rBxnyc5KpL0FFNMSZ3oMdW0q0KHaOi4RGBMojQ0AOStG0dk0mXjCMH5vruYPMlNAzlynEJEdS3A57mhJX11EFoJEZvqIJyJLX30+6N3WoH/I5vG+h9QOfqAclutn/Nnjk/6FfSz+SR+3f9jHWwjtb1+5fhVOGX/ky+FdW30AUEsBAhQDFAAAAAgA8SFcXUbHTUiVAAAAzQAAABAAAAAAAAAAAAAAAIABAAAAAGRvY1Byb3BzL2FwcC54bWxQSwECFAMUAAAACADxIVxdWvYt8/IAAAArAgAAEQAAAAAAAAAAAAAAgAHDAAAAZG9jUHJvcHMvY29yZS54bWxQSwECFAMUAAAACADxIVxd+lwBWfwCAADaDQAAEwAAAAAAAAAAAAAAgAHkAQAAeGwvdGhlbWUvdGhlbWUxLnhtbFBLAQIUAxQAAAAIAPEhXF01kq7pmBQAADm3AAAYAAAAAAAAAAAAAACAgREFAAB4bC93b3Jrc2hlZXRzL3NoZWV0MS54bWxQSwECFAMUAAAACADxIVxd/0Lsyk8DAACmDAAAGAAAAAAAAAAAAAAAgIHfGQAAeGwvd29ya3NoZWV0cy9zaGVldDIueG1sUEsBAhQDFAAAAAgA8SFcXUga+1UOCgAAQlUAABgAAAAAAAAAAAAAAICBZB0AAHhsL3dvcmtzaGVldHMvc2hlZXQzLnhtbFBLAQIUAxQAAAAIAPEhXF1BkwRedAUAAKVQAAANAAAAAAAAAAAAAACAAagnAAB4bC9zdHlsZXMueG1sUEsBAhQDFAAAAAgA8SFcXZeKuxzAAAAAEwIAAAsAAAAAAAAAAAAAAIABRy0AAF9yZWxzLy5yZWxzUEsBAhQDFAAAAAgA8SFcXQd8ytlGAQAAIQMAAA8AAAAAAAAAAAAAAIABMC4AAHhsL3dvcmtib29rLnhtbFBLAQIUAxQAAAAIAPEhXF27bOrsugAAABoDAAAaAAAAAAAAAAAAAACAAaMvAAB4bC9fcmVscy93b3JrYm9vay54bWwucmVsc1BLAQIUAxQAAAAIAPEhXF2m/EpbIwEAAN8EAAATAAAAAAAAAAAAAACAAZUwAABbQ29udGVudF9UeXBlc10ueG1sUEsFBgAAAAALAAsAygIAAOkxAAAAAA=='
_LAYOUT_SPEC={'BOM确认': {'start': 5, 'columns': 10, 'widths': [6, 13, 21, 44, 27, 19, 12, 17, 17, 25], 'header_end': 4}, '选型说明': {'start': 4, 'columns': 5, 'widths': [13, 25, 19, 72, 48], 'header_end': 3, 'hide_if_empty': True}}
_v182_layout_base=main
def main(markdown, selection_json):
    out=_v182_layout_base(markdown, selection_json)
    out["template_base64"]=layout_template(_LAYOUT_TEMPLATE,out['payload_json'],_LAYOUT_SPEC)
    return out
