from decimal import InvalidOperation
import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_CONTEXT_MAX = 5000000
_BATCH_MAX = 120

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
import hashlib
import json
from decimal import Decimal, ROUND_HALF_UP

def clean(value):
    return '' if value is None else str(value).strip()

def money(value):
    return Decimal(str(value or 0)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

def safe_cell(value):
    text = clean(value).replace('\r', ' ').replace('\n', ' ')
    return "'" + text if text.startswith(('=', '+', '-', '@')) else text

def _original_main(results):
    if isinstance(results, str):
        try:
            parsed_results = json.loads(results)
            results = parsed_results if isinstance(parsed_results, list) else [results]
        except Exception:
            results = [results]
    elif isinstance(results, dict):
        candidate = results.get('output', results.get('results', results))
        results = candidate if isinstance(candidate, list) else [candidate]
    elif not isinstance(results, list):
        results = []
    items = []
    for raw in results or []:
        try:
            item = json.loads(raw) if isinstance(raw, str) else raw
            if isinstance(item, dict):
                items.append(item)
        except Exception:
            items.append({'item_status': 'PARSE_ERROR', 'issue': '单项计价结果无法解析'})
    seen_lines = set()
    for item in items:
        if not isinstance(item, dict):
            continue
        try:
            q = Decimal(str(item.get('quantity')))
            if not q.is_finite() or q <= 0:
                raise ValueError()
        except Exception:
            item.update(item_status='INVALID_QUANTITY', issue='缺少大于零的合法数量，不能计价')
        key = (clean(item.get('material_code')), clean(item.get('position') or item.get('symbol') or item.get('tag')), clean(item.get('model_spec')))
        if key[0] and key in seen_lines:
            item.update(item_status='DUPLICATE_BOM_LINE', issue='相同位号型号与物料编码重复，不能重复计价')
        seen_lines.add(key)
    rates = set()
    for item in items:
        if item.get('item_status') != 'PRICED':
            continue
        try:
            rate = Decimal(str(item['tax_rate']))
            if not rate.is_finite() or rate < 0 or rate > 1:
                raise ValueError()
            rates.add(rate)
        except (ValueError, KeyError, TypeError):
            item.update(item_status='TAX_INVALID', issue='缺少合法税率')
    if len(rates) > 1:
        for item in items:
            if item.get('item_status') == 'PRICED':
                item.update(item_status='MIXED_TAX_RATES', issue='多税率项目不能使用单一税率汇总模板，需要财务核准分税率核算')
    effective_rate = next(iter(rates)) if len(rates) == 1 else Decimal('0')
    priced = [x for x in items if x.get('item_status') == 'PRICED']
    blocked = [x for x in items if x.get('item_status') != 'PRICED']
    fingerprint = json.dumps({'items': [{k:x.get(k) for k in ('material_code','quantity','unit_price_ex_tax','tax_rate','price_version','price_validity','price_basis')} for x in items], 'markup':str(_V182_MARKUP),'discount':str(_V182_DISCOUNT)},ensure_ascii=False,sort_keys=True)
    quote_no = 'Q-' + hashlib.sha256(fingerprint.encode('utf-8')).hexdigest()[:16].upper()
    cells = {'01 报价汇总!B6': quote_no, '01 报价汇总!B7': '材料报价' if not blocked and items else '报价已阻断', '01 报价汇总!B8': len(priced), '01 报价汇总!B14': float(_V182_MARKUP), '01 报价汇总!B15': float(_V182_DISCOUNT), '01 报价汇总!B16': float(effective_rate)}
    subtotal = Decimal('0')
    for row_no, item in enumerate(priced, 4):
        qty = Decimal(str(item.get('quantity') or 0))
        price = Decimal(str(item.get('unit_price_ex_tax')))
        subtotal += money(qty * price)
        values = [row_no - 3, safe_cell(item.get('material_code')), safe_cell(item.get('material_name')), safe_cell(item.get('model_spec')), float(qty), safe_cell(item.get('pricing_unit') or item.get('unit')), float(price), None, float(item.get('tax_rate')), None, safe_cell(item.get('price_version')), safe_cell((item.get('approval_status') or '') + '；' + (item.get('price_validity') or '') + ('；价格依据：' + item['price_basis'] if item.get('price_basis') else '') + ('；电气参数待复核：' + '、'.join(item.get('technical_review_notes') or []) if item.get('technical_review_required') else ''))]
        for col, value in enumerate(values, 1):
            if value is not None:
                name = ''
                number = col
                while number:
                    number, remainder = divmod(number - 1, 26)
                    name = chr(65 + remainder) + name
                cells[f'02 报价明细!{name}{row_no}'] = value
    subtotal = money(subtotal)
    pre_tax = money(subtotal * (Decimal('1')+_V182_MARKUP) * (Decimal('1')-_V182_DISCOUNT))
    tax = money(pre_tax * effective_rate)
    total = money(pre_tax + tax)
    cells.update({'01 报价汇总!B9': float(subtotal), '01 报价汇总!B10': float(pre_tax), '01 报价汇总!B11': float(total)})
    for row_no, item in enumerate(blocked, 4):
        values = [row_no - 3, safe_cell(item.get('material_code')), safe_cell(item.get('material_name')), safe_cell(item.get('item_status')), safe_cell(item.get('issue')), '检查产品匹配、价格API响应及有效期、规格与计价单位，修复后重新提交']
        for col, value in enumerate(values, 1):
            name = chr(64 + col)
            cells[f'03 缺价与说明!{name}{row_no}'] = value
    voltage_review_count = sum((1 for x in priced if x.get('technical_review_required')))
    status = 'READY' if items and (not blocked) else 'BLOCKED'
    if not items:
        message = '没有可计价的BOM行。'
    elif blocked:
        message = '共%d项未通过产品或价格校验，报价已停止。系统没有猜测任何价格。' % len(blocked)
    else:
        message = '已核验%d项PRODUCT/PRICE编码、单位及价格有效期。按本次配置的加成与折扣计价（比例见汇总表），税率取所匹配价格记录；人工、加工、试验、运输均未计价，整柜项目总价还需另行核算人工、加工、试验和运输等费用。' % len(priced)
    if status == 'READY' and voltage_review_count:
        message += ' 其中%d项涉及产品状态、临时编码或电压适用性证据待工程核实；明细已标注。当前为材料报价，未含人工、加工、试验和运输等费用；项目总价需另行核算。' % voltage_review_count
    lines = ['| 序号 | 物料编码 | 元器件 | 状态 | 原因 |', '|---:|---|---|---|---|']
    for index, item in enumerate(blocked, 1):
        lines.append('| %d | %s | %s | %s | %s |' % (index, safe_cell(item.get('material_code')), safe_cell(item.get('material_name')), safe_cell(item.get('item_status')), safe_cell(item.get('issue'))))
    return {'pricing_status': status, 'pricing_message': message, 'missing_markdown': '\n'.join(lines) if blocked else '', 'quote_payload_json': json.dumps({'cells': cells, 'output_filename': '成套柜材料报价_V15.9.9_' + quote_no}, ensure_ascii=False), 'output_filename': '成套柜材料报价_V15.9.9_' + quote_no, 'quote_no': quote_no, 'priced_count': len(priced), 'blocked_count': len(blocked), 'voltage_review_count': voltage_review_count, 'material_subtotal': float(subtotal), 'pre_tax_quote': float(pre_tax), 'tax_amount': float(tax), 'tax_included_quote': float(total)}

def main__v16_before_1(results):
    if isinstance(results, list) and len(results) > _BATCH_MAX:
        results = [plain_json({'item_status': 'CAPACITY_BLOCKED', 'issue': '确认BOM超过每批120项，请分批，不能生成部分报价', 'quantity': 1})]
    out = _original_main(results)
    payload = wire_loads(out['quote_payload_json'])
    decoded = [wire_loads(x) if isinstance(x, str) else x for x in results] if isinstance(results, list) else []
    bases = {r.get('quantity_basis', 'PROJECT') for r in decoded if isinstance(r, dict)}
    if bases == {'PER_CABINET'}:
        payload['cells']['01 报价汇总!B7'] = '单柜材料报价（不含项目总量）'
        out['pricing_message'] = '当前按单柜用量计价，不代表项目订货数量或项目总价。' + out['pricing_message']
    elif len(bases) > 1:
        out.update(pricing_status='BLOCKED', pricing_message='本批混有单柜与项目总量口径，请按相同计量口径分开确认，不能直接相加', blocked_count=1, priced_count=0, material_subtotal=0, pre_tax_quote=0, tax_amount=0, tax_included_quote=0)
        payload = {'cells': {}, 'output_filename': out['output_filename']}
    out['quote_payload_json'] = plain_json(payload)
    if len(out['quote_payload_json'].encode('utf-8')) > 65000:
        out.update(pricing_status='BLOCKED', pricing_message='报价Excel请求超过65KB预算，请分批。本次不输出部分报价。', missing_markdown='| 问题 | 处理方式 |\n|---|---|\n| 本批报价内容过长 | 按柜号或回路分批提交 |', quote_payload_json='{}', priced_count=0, blocked_count=1, voltage_review_count=0, material_subtotal=0, pre_tax_quote=0, tax_amount=0, tax_included_quote=0)
    return out
_v1511_quote_main = main__v16_before_1

def main(results, confirmed_bom_json=''):
    if isinstance(results, str):
        try:
            parsed = json.loads(results)
            results = parsed if isinstance(parsed, list) else [parsed]
        except (ValueError, TypeError):
            results = [results]
    if isinstance(results, dict):
        results = results.get('output', results.get('results', results))
        if not isinstance(results, list):
            results = [results]
    if not isinstance(results, list):
        results = []
    checked = []
    for row in results:
        try:
            row = json.loads(row) if isinstance(row, str) else dict(row) if isinstance(row, dict) else None
        except (ValueError, TypeError):
            row = None
        if not isinstance(row, dict):
            row = {'quantity': 1, 'item_status': 'PARSE_ERROR', 'issue': '逐项计价包含非对象或不可解析结果，本批不能只汇总其余行'}
        row = dict(row)
        if row.get('item_status') == 'PRICED':
            try:
                rate = Decimal(str(row.get('tax_rate')))
                if not rate.is_finite() or not Decimal('0') <= rate <= Decimal('1'):
                    raise ValueError()
            except (ValueError, TypeError, InvalidOperation):
                row.update(item_status='TAX_INVALID', issue='计价结果缺少0到1之间的有限税率')
            try:
                price = Decimal(str(row.get('unit_price_ex_tax')))
                if not price.is_finite() or price <= 0:
                    raise ValueError()
            except (ValueError, TypeError, InvalidOperation):
                row.update(item_status='PRICE_INVALID', issue='计价结果缺少有效正数单价')
            try:
                qty = Decimal(str(row.get('quantity')))
                if row.get('unit') in ('台', '件', '只', '个', '套', '根', '支', '块', '颗', '处', '组') and qty != qty.to_integral_value():
                    row.update(item_status='INVALID_QUANTITY', issue='按件计数的器件数量必须为整数')
            except (ValueError, TypeError, InvalidOperation):
                row.update(item_status='INVALID_QUANTITY', issue='数量格式无效')
        checked.append(row)
    if confirmed_bom_json:
        try:
            confirmed = json.loads(confirmed_bom_json)
            expected = confirmed.get('items')
            if confirmed.get('pricing_allowed') is not True or not isinstance(expected, list) or (not expected):
                raise ValueError('缺少允许计价的人工确认BOM')

            def item_key(row):
                return str(row.get('source_request_id') or row.get('line_no') or '')
            byid = {item_key(row): row for row in expected}
            returned = [item_key(row) for row in checked]
            if len(byid) != len(expected) or not all(byid) or len(returned) != len(set(returned)) or (set(returned) != set(byid)):
                raise ValueError('逐项计价结果与已确认BOM行数或来源编号不一致，不能生成部分报价')
            for row in checked:
                original = byid[item_key(row)]
                if clean(row.get('material_code')) != clean(original.get('material_code')) or Decimal(str(row.get('quantity'))) != Decimal(str(original.get('quantity'))) or clean(row.get('unit')) != clean(original.get('unit')):
                    raise ValueError('逐项结果的编码、数量或单位偏离已确认BOM，不能汇总')
        except (ValueError, TypeError, KeyError, InvalidOperation) as exc:
            checked.append({'quantity': 1, 'item_status': 'INCOMPLETE_PRICE_RESULTS', 'issue': str(exc)})
    per_cabinet_groups = {row.get('scheme_group_id') for row in checked if row.get('quantity_basis') == 'PER_CABINET' and row.get('scheme_group_id')}
    if len(per_cabinet_groups) > 1:
        checked.append({'quantity': 1, 'item_status': 'MIXED_CABINET_SCOPES', 'issue': '本批含不同方案组的单柜用量，不能相加称为一台柜的报价；请分别确认或补充项目柜数'})
    out = _v1511_quote_main(checked)
    if out['pricing_status'] != 'READY':
        out.update(material_subtotal=0, pre_tax_quote=0, tax_amount=0, tax_included_quote=0, quote_payload_json='{}')
    return out

_V182_MARKUP=Decimal('0.15')
_V182_DISCOUNT=Decimal('0.02')
_v182_quote_base=main
def main(results,confirmed_bom_json='',markup_rate='0.15',discount_rate='0.02'):
    global _V182_MARKUP,_V182_DISCOUNT
    try:
        _V182_MARKUP=Decimal(str(markup_rate));_V182_DISCOUNT=Decimal(str(discount_rate))
        if not _V182_MARKUP.is_finite() or _V182_MARKUP<0:raise ValueError()
        if not _V182_DISCOUNT.is_finite() or not Decimal('0')<=_V182_DISCOUNT<=Decimal('1'):raise ValueError()
    except Exception:
        raise ValueError('报价加成须为非负有限数，折扣须为0到1之间的有限数；请检查环境变量')
    out=_v182_quote_base(results,confirmed_bom_json)
    if isinstance(results,str):
        try:rows=json.loads(results)
        except (TypeError,ValueError):rows=[]
    else:rows=results
    if isinstance(rows,dict):rows=rows.get('output',rows.get('results',[rows]))
    decoded=[]
    for row in rows if isinstance(rows,list) else []:
        try:row=json.loads(row) if isinstance(row,str) else row
        except (TypeError,ValueError):continue
        if isinstance(row,dict):decoded.append(row)
    confirmed={'SUPPLIER_QUOTE','CONTRACT_PRICE','ACTUAL_PURCHASE','APPROVED_PURCHASE_PRICE','VERIFIED_MARKET_PRICE'}
    references=[row for row in decoded if row.get('item_status')=='PRICED' and (row.get('reference_only') is True or str(row.get('price_basis') or '').upper() not in confirmed)]
    out['reference_price_count']=len(references)
    out['quote_title']='材料参考报价（含估算或未核验价格）' if references else '材料报价'
    if out.get('pricing_status')=='READY':
        payload=wire_loads(out['quote_payload_json']);cells=payload['cells']
        cells['01 报价汇总!A2']=out['quote_title']
        cells['01 报价汇总!B7']=out['quote_title']+('｜单柜用量' if '单柜' in out['pricing_message'] else '')
        cells['01 报价汇总!A3']='估算价格不等于真实采购核价；依据、版本、有效期及单位换算见明细。' if references else '价格依据、版本、有效期及计价单位见明细；按企业审核流程使用。'
        priced=[row for row in decoded if row.get('item_status')=='PRICED']
        for number,row in enumerate(priced,4):
            label='参考价格，尚未经采购核验' if row in references else '来源依据见价格版本'
            suffix='；BOM数量单位：'+str(row.get('unit') or '')+'；计价单位：'+str(row.get('pricing_unit') or row.get('unit') or '')
            if row.get('unit_conversion_note'):suffix+='；'+str(row['unit_conversion_note'])
            cells['02 报价明细!L'+str(number)]=str(cells.get('02 报价明细!L'+str(number)) or '')+'；'+label+suffix
        cells.update({'03 缺价与说明!A4':1,'03 缺价与说明!D4':'参考价格说明' if references else '报价范围',
                      '03 缺价与说明!E4':('本批有'+str(len(references))+'项估算或未核验价格；金额按现有价格记录计算，不能据此认定为真实采购价。') if references else '本次价格字段和有效期校验通过；价格依据按明细所列来源执行。',
                      '03 缺价与说明!F4':'仅材料费用；人工、加工、检验和运输等未计入。'})
        payload['output_filename']='成套柜材料参考报价_'+out['quote_no'] if references else '成套柜材料报价_'+out['quote_no']
        out['output_filename']=payload['output_filename'];out['quote_payload_json']=plain_json(payload)
        if references:out['pricing_message']='本批含%d项估算或未核验价格，以下为材料参考计算。'%len(references)+out['pricing_message']
    return out

"""Stdlib-only XLSX geometry, embedded in Dify code nodes. No openpyxl in the sandbox."""
import base64 as _lx_b64
import io as _lx_io
import json as _lx_json
import math as _lx_math
import re as _lx_re
import unicodedata as _lx_unicode
import zipfile as _lx_zip
from xml.etree import ElementTree as _lx_et

_LX_NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
_LX_REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
_lx_et.register_namespace('',_LX_NS)
_lx_et.register_namespace('r',_LX_REL)


class LayoutCapacityError(ValueError):
    pass


def _lx_tag(name):return '{'+_LX_NS+'}'+name


def _lx_insert_before(parent,element,following):
    position=next((i for i,child in enumerate(parent) if child.tag in {_lx_tag(name) for name in following}),len(parent))
    parent.insert(position,element)


def _lx_col(number):
    result=''
    while number:
        number,remainder=divmod(number-1,26);result=chr(65+remainder)+result
    return result


def _lx_col_number(value):
    result=0
    for char in value:result=result*26+ord(char)-64
    return result


def _lx_lines(value,width):
    if value is None:return 1
    text=str(value).replace('\r\n','\n').replace('\r','\n')
    available=max(5,width-2)
    total=0
    for line in text.split('\n'):
        weight=sum(2.1 if _lx_unicode.east_asian_width(c) in ('W','F') else 1 for c in line)
        total+=max(1,_lx_math.ceil(weight/available))
    return total


def layout_template(template_base64,payload_json,spec):
    """Return a styled EMPTY template; the existing Excel plugin fills unchanged cell values."""
    payload=_lx_json.loads(payload_json)
    cells=payload.get('cells',{})
    if not isinstance(cells,dict):raise ValueError('Excel cells必须是对象')
    buffer=_lx_io.BytesIO()
    with _lx_zip.ZipFile(_lx_io.BytesIO(_lx_b64.b64decode(template_base64))) as original:
        files={name:original.read(name) for name in original.namelist()}
    book=_lx_et.fromstring(files['xl/workbook.xml'])
    rels=_lx_et.fromstring(files['xl/_rels/workbook.xml.rels'])
    targets={r.attrib['Id']:r.attrib['Target'].lstrip('/') for r in rels}
    names=book.find(_lx_tag('definedNames'))
    if names is None:
        names=_lx_et.Element(_lx_tag('definedNames'));_lx_insert_before(book,names,('calcPr','oleSize','customWorkbookViews','pivotCaches','extLst'))
    for item in list(names):
        if item.get('name') in ('_xlnm.Print_Area','_xlnm.Print_Titles'):names.remove(item)
    for index,sheet in enumerate(book.find(_lx_tag('sheets'))):
        name=sheet.get('name');config=spec.get(name)
        if name=='系统数据':
            sheet.set('state','veryHidden');continue
        if not config:continue
        target=targets[sheet.get('{'+_LX_REL+'}id')]
        path=target if target.startswith('xl/') else 'xl/'+target
        root=_lx_et.fromstring(files[path]);data=root.find(_lx_tag('sheetData'))
        start=config['start'];columns=config['columns'];minimum=config.get('minimum',start-1)
        values={}
        metadata=set()
        for key,value in cells.items():
            if '!' not in key:continue
            prefix,coordinate=key.rsplit('!',1)
            if prefix.strip("'")!=name:continue
            match=_lx_re.fullmatch(r'([A-Z]+)(\d+)',coordinate)
            if not match:raise ValueError('Excel单元格地址无效')
            row=int(match.group(2))
            if row>=130 and name in ('BOM确认','资料问题确认'):
                metadata.add(row);continue
            values[coordinate]=value
        rows=[int(_lx_re.search(r'\d+$',key).group()) for key in values]
        last=max([minimum]+rows)
        if config.get('hide_if_empty') and last<start:
            sheet.set('state','hidden')
            continue
        if last-start+1>120 and name not in ('01 报价汇总',):
            raise LayoutCapacityError(name+'超过120行，请分批；没有输出截断表格')
        widths=config['widths']
        merged_widths={}
        merges=root.find(_lx_tag('mergeCells'))
        for merged in merges if merges is not None else []:
            hit=_lx_re.fullmatch(r'([A-Z]+)(\d+):([A-Z]+)(\d+)',merged.get('ref',''))
            if hit and hit.group(2)==hit.group(4):
                first=_lx_col_number(hit.group(1));end=_lx_col_number(hit.group(3))
                merged_widths[hit.group(1)+hit.group(2)]=sum(widths[first-1:end])
        for row in list(data):
            number=int(row.get('r','0'))
            if number>=130 and name in ('BOM确认','资料问题确认'):
                row.set('hidden','1');row.set('ht','1');row.set('customHeight','1');continue
            if number>last:
                data.remove(row);continue
            if number<start:continue
            height=max([config.get('min_height',34)]+[
                9+16*_lx_lines(values.get(_lx_col(col)+str(number)),merged_widths.get(_lx_col(col)+str(number),widths[col-1]))
                for col in range(1,columns+1)])
            if height>409:
                raise LayoutCapacityError(name+'第'+str(number)+'行文字过长，超过Excel单行显示上限；请精简重复说明或拆分需求，未输出会截断的表格')
            row.set('ht',str(height));row.set('customHeight','1')
        dimension=root.find(_lx_tag('dimension'))
        if dimension is not None:dimension.set('ref','A1:'+_lx_col(columns)+str(max(last,max(metadata) if metadata else last)))
        filters=root.find(_lx_tag('autoFilter'))
        if filters is not None:filters.set('ref','A'+str(start-1)+':'+_lx_col(columns)+str(max(start-1,last)))
        properties=root.find(_lx_tag('sheetPr'))
        if properties is None:properties=_lx_et.Element(_lx_tag('sheetPr'));root.insert(0,properties)
        setup_properties=properties.find(_lx_tag('pageSetUpPr'))
        if setup_properties is None:setup_properties=_lx_et.SubElement(properties,_lx_tag('pageSetUpPr'))
        setup_properties.set('fitToPage','1');setup_properties.set('autoPageBreaks','1')
        setup=root.find(_lx_tag('pageSetup'))
        if setup is None:
            setup=_lx_et.Element(_lx_tag('pageSetup'));_lx_insert_before(root,setup,('headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        setup.attrib.update(orientation=config.get('orientation','landscape'),paperSize=str(config.get('paper',8)),fitToWidth='1',fitToHeight='0')
        margins=root.find(_lx_tag('pageMargins'))
        if margins is None:
            margins=_lx_et.Element(_lx_tag('pageMargins'));_lx_insert_before(root,margins,('pageSetup','headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        margins.attrib.update(left='0.25',right='0.25',top='0.35',bottom='0.35',header='0.15',footer='0.15')
        escaped="'"+name.replace("'","''")+"'"
        area=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Area','localSheetId':str(index)})
        area.text=escaped+'!$A$1:$'+_lx_col(columns)+'$'+str(last)
        repeat=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Titles','localSheetId':str(index)})
        repeat.text=escaped+'!$1:$'+str(config.get('header_end',start-1))
        files[path]=_lx_et.tostring(root,encoding='utf-8',xml_declaration=True)
    files['xl/workbook.xml']=_lx_et.tostring(book,encoding='utf-8',xml_declaration=True)
    with _lx_zip.ZipFile(buffer,'w',compression=_lx_zip.ZIP_DEFLATED) as output:
        for name,content in files.items():output.writestr(name,content)
    encoded=_lx_b64.b64encode(buffer.getvalue()).decode('ascii')
    if len(encoded)>55000:raise LayoutCapacityError('动态Excel模板超过传递预算，请分批')
    return encoded

_LAYOUT_TEMPLATE='UEsDBBQAAAAIAPEhXF1Gx01IlQAAAM0AAAAQAAAAZG9jUHJvcHMvYXBwLnhtbE3PTQvCMAwG4L9SdreZih6kDkQ9ip68zy51hbYpbYT67+0EP255ecgboi6JIia2mEXxLuRtMzLHDUDWI/o+y8qhiqHke64x3YGMsRoPpB8eA8OibdeAhTEMOMzit7Dp1C5GZ3XPlkJ3sjpRJsPiWDQ6sScfq9wcChDneiU+ixNLOZcrBf+LU8sVU57mym/8ZAW/B7oXUEsDBBQAAAAIAPEhXF35FXQY7wAAACsCAAARAAAAZG9jUHJvcHMvY29yZS54bWzNklFLwzAQx7+K5L29pJ1DQpcXxScFwYHiW0huW1jThOSk3be3rVuH6AfwMXf//O53cI2J0oSELylETOQw3wy+7bI0ccMORFECZHNAr3M5JrqxuQvJaxqfaQ9Rm6PeI1Scr8EjaatJwwQs4kJkqrFGmoSaQjrjrVnw8TO1M8wawBY9dpRBlAKYmibG09A2cAVMMMLk83cB7UKcq39i5w6wc3LIbkn1fV/29ZwbdxDw/vz0Oq9buC6T7gyOv7KTdIq4YZfJb/X9w/aRqYpX60Lworrb8pUUt7JefUyuP/yuwj5Yt3P/2PgiqBr4dRfqC1BLAwQUAAAACADxIVxd+lwBWfwCAADaDQAAEwAAAHhsL3RoZW1lL3RoZW1lMS54bWy1V9lS2zAU/RWP34u8LxkCw5K0D+20U/gBxZaXIsseSyHw95UVL7IdhbAkzIAlnXPPse7VVbi8fimw9oxqmpdkqZsXhq4hEpVxTtKlvmXJt0C/vrqEC5ahAmkEFmip32WQff/zqGucS+gCLvWMsWoBAI04CtKLskKEryVlXUDGh3UK4hrueMwCA8swPFDAnOh93BXmvwijzUSE64fogFizFj+ZzR/6Su9wrT1DvNR50LjcPaIXpmsYUsYXlrohProGri5Bz8JMQZaIa/HpiC0jfrIEsU43PdNYWYFjDgrWXmEOXAXNzxBRIGAU8dc1Z2DT9YzA6sASav94IHrom/aEICnYc4XQu7WcMcEeCM78Rdfh6t4dE5yB4M4IN4Z1G9pjgjsQvBnBWd341mpMEKgM5+RpDvf8IPA6eI9JSvzjID70PMO/7/ADDEiltg9A2KjwfidJHiFRdwX8V9ZrDhBZhiwnGnutUAKjpkAhzjd1rv3M04wJHbhA8A1ARI8CwESzyMmbBo5IHxHt5QYFIG+G2JqCKY9kkmP8wF4x+kmFOVriPF7zSTEQrD4VVcYfO8ERMK3h8EzbUCnVqpLyEtSVsUQHyQnbz3l+d+r5Jm2LX2XcFr1pDAsUsmHBcKU+0SuIUUplD66IcKIP31b4GOSmPuwTfZjGe4wE5ruNhEeNACk9/BhpsLklXKdttzSCGMVNwtoAo7R+SYpDR/VG1me39oQU0wzGqItrqJyois00vjDJkhU/OOwkDBVGrONGPpxkMG8HmIxH2q7R97u3+1CzqGrK7iHN9jix1N+vRJIJeZWfX8ZqduZ8MmC6hyhJUMQUM8OQr7VRDi5/Ft0Myi1D9UMW77QN3tZ/IS8K1zf5nmtxTlmXAD6oh/KZf78Y5iGuMth28tGh3ePFc68pmRV2ptbBoZ3apOsvua7eZk26lqrd+uqTeIb7MZTuJal/hIr+oe6p7qmd7F3XpuxDtqdstLbCnn2mRuupBM/YUKclC6SvY2I0+Qeqm7n6D1BLAwQUAAAACADxIVxd+Ol4D1YGAACNGAAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbJ1Z25KbOBD9FYqtymPQFZBvVRl7Z7NVyWYqqd19ZsbymIoNXtDMJPn6tC5g8Ahw9sUgHal1TuvSLbx4Kauv9V5KFXw7Hop6Ge6VOs2iqH7Yy2NWvy1PsgBkV1bHTEGxeozqUyWzrel0PEQEoTg6ZnkRrham7q5aLVR2vy4PZRVUj/fL8PYW37LfkzSMVovySR3yQt5VQf10PGbV9xt5KF+WIQ6bis/5417pCmh9yh7lF6n+Pt1VUIpa+9v8KIs6L4ugkrtl+A7PNoTpDqbFP7l8qTvvQb0vX/6o8u0HGBkkojDQsu/L8quG/9zqKj1YIYPvX06HHIbnYaDK0we5U2t5OMAQcRhkDyp/lnfQbBnel0qVR40DcZUpqNpV5Q9ZGBbyIKEt0Du9amyNOKNa9X9OQtgq1KS6742WWzMJ4Lr7rJbg33/zrdovwzQMtnKXPR3U5/LlvXTu49reQ3mozW/wYtsSaPzwVAMb1xkYHPPCPrNvzu3XdCCuA7nogIc6UNeBXtuBuQ5mYiMrxfhhk6lstajKl6DSrcGafjHOBG8ImLllqJdj9OCgm2FoPQxtvFAE47aDgxO0s2kroXV/y4oYIwIZI3mhF/8XVQGcgxy1evMb4RixOTxJmmD9jHmamidj9omQ0E9OONVPRDCfLyIFXLSNV6SoI4WGSVFLCg+TMoPowePUkEM0NeQ447qMga0hJQiPLVlM9BMzjkyZJolpL4gVQYVuTznIM2VMdD9KrL2YU2TaY84SKzLR9iiGjnMPnxgjg8cJN/VIpLHPaZgx044k1rk9JxodAo05k7U+Y8PLaxhaD0MbL9QbnE/PJLczSQZnkgpEtWKKGIsvlFr2kyYISmPjTMpgEQRRANYSSsx8CmSgmBO7aFGKqCsL32hrNxr1OMRBbNghcas7tm35yLbqzzSFIrMrQlxuH+uHnsnaGDvTdmDsoe2gZJh20tJOfpU2ETQ2C5tx2FA+2tMmE5HYvQcvEweJFZsMi00mxaat2HSS2cUpAQwZ74l3p0x7BIo49TqhN5Sm9bxCi+i5KyodFpVOihKtKDEt6uIIgqMRmaOMMDOTlMdJK9Ynxg2RjogRw2LEpBiMzjETTcmhPGXU+j6xJzzHqUdW/0TwyWrGGtPVtPEJa7AxZZ1sAP9vZS4G/YIyfIUyPKIMTysjZ2UupfAmOsPYegTb+LE+gyvyCmwTC4yG051Xexxxju12SJjfu9NG2/QjYcQc9gk2Rx0lMSHeI84Z9cahBhsJRPicF2Dm6I1kU02K12ZJmJtnUy944j8KWuOku7TeYt6urj4tfqbFr6BFGLI00mScBvfSQGSAxjlO4/gaGv1I3RyUw3Riv1foAJ1z/MXJyN4ZxtYj2MaP9RmcgyJOHXc6vEUot0kvgRjikmPjEIRt8oydw5pk+WL1w6yaJJyilCIXadL5zaeP2gTCNhukduovghWNsTUthCDX5Mf4HBmxcMrY6D5FPgUIm2sAMKdJ93rRbJTL+jjF5mgWPO5eR2hT764FFPMYe2Q11w0shLnWNO2Ah+XXhAR3F+sn0ZpPTLuH2KSbyDnkEjTtponbzyBtN/G6HbIJu3ErRDDsZpfhjr3GDSBL8E77V7ctTp37Lm97sHzmI7c9whFyGedVq4l07s142k2Xx2hz+bw81xr6o1FC90fuAELUXkqJcO2FcRujbtapCVnNatKrg3fHQcTYh2kSzLnVJd6ouQSnbjxbj419uF5dt+nIORkgI8nACLYewTZ+rM+AnhnQEQbD2HoE2/ixPoNzBCZshMEwth7BNn7MMog6X6GOsno0X/Pq4KF8KpSLNm21/UAJue9M56+RB8Eznf+9RiBSAJL6+vDZhnttMejBfAiY8ll6R2cb6qsnwJf4+MK+BMTH90bM4O7hYwWDYO8oGLpgX593BAbx2gLp2Ks9mcHd1FMfz+CC7rMEADZIdJ7D1eJU5YX6dNIfb+tgX1b5j7JQ2WEtCyUrue18l/6YVY85NDrIHcw6egtZQGXzYfOuypN5g8zJfv5tSnuZbWWlS7DId2WpmgLYtditqVwtyu32vakAjp13eHUt3mTH03xtfkVgwgEl88CU7wJzLsHFxXyvIShlwkF/tZAx24wmn2XRDtct6PemUdQt7PKqVm2XXskU2k79Ul9k1P4DsfoJUEsDBBQAAAAIAPEhXF1QW6/65R8AANjlAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDIueG1sld3xbxy3mcbxf0XQAUWjK6olOZwhE8fANVPPTDvXBil697MSr22htuWTNnHbv/44+46WO9yXX7e/RBZn+T4iHzkBPmh3X3x+ePzb07v9/nD19w/vPz59e/3ucPj09e3t00/v9h/unn778Gn/MT158/D44e6Qvn18e/v06XF/9/q46cP7W7vbtbcf7u4/Xr98cVz7/vHli8Pdj989vH94vHp8++O3169e+d/F3/X++vbli4efD+/vP+6/f7x6+vnDh7vHf/xu//7h87fX5vp54Yf7t+8Oy0J69ae7t/u/7A9//fT9Y/ru9jT/9f2H/cen+4ePV4/7N99e/5f5ejbWLTuOL/mf+/3np7M/Xz29e/g8PN6/nlN0OuPu+mo5948PD39bHk+vl6Ul7eP+6h9/+fT+PuW766vDw6d5/+bw3f79+5TRXF/d/XS4/2X/fXrZt9c/PhwODx+W5+knP9wd0tKbx4d/7j8ef4r9+316bfr5Pl28WIasQ5dj/996huvTEZcf6vzPz2d5dWwh3d2Pd0/7dMH/e//68O7b63B99Xr/5u7n94cfHj6P+/X+jtf908P7p+M/rz7La9vrq59+fko/zLo3/QAf7j/K17u/r9d+9noTKhvsusEWG6ytbHDrBlduiJUNzbqhKTbUXu/X1/vi9bUTtOvr2/LIrrKhWzd05YamsiGsG0K5YVfZENcNsdzga7XtnnvblddayzCnqsuum2rKc9nm2Pat/FYdfyX7u8PdyxePD5+vHpfXp3nLH46/1+nc6TzpV3H5V8PtT+uj39UffVd/1Ncf/b7+6FX90VB/NNYfTfVHf6g/+mP90aw+uk33ebrUdPfL32d36vP0N/x02/Y4xOz8ccr9x+XfsH85PKbn96mnw8tf/YdtmyZ8s3zd7WL66nzX+OX7nTXHr62x7bJuG9+kr6234fj6XWh2y1fjnDt+Nd4uX73Zra+Lx/3eyuu8Cd1xfmiOr/exO77e7Nq4zo3fvLg9pEMuP9vFad2XT+uOp422ftjG7rpjaJN+uG2Y/A5+eURcfs6z+7LeLed1u86a8/vxMZrj6xpjK+eT3+1/OzIVY45XaaxptZH9F0c6b1tpvQ3LT29tYwxdzO+//FP6eBzpOmc7bcSrL494/l3auZ3RRgxfHpGueyd307Tnv57HX2dl5Phvj1wOeGw+Lr+5ysjpy9f//NNF36k/1R/+hbvyTffv/FR//PLI01/59ZciWt+efoWVkfOXR9pO/hZ0Iezob3dz+kvcyEyv/AeiWf9t1ir/hahv65+3dcp/ItZtQflPRH3i8DxR2TaeJr588ebl9OrXf/7h179vvr2+/s2w/POr36Q//fDnv/6pT6s3Q/Mb+9VXL27fvHzxS5rxy/kv0XOG9l8UJWM8ZkxFxtjc/Nr859R8Vc35Y/2Ys35xm978qTdf781Db/VtvYfefL23+sTBQ29e6c0fe/NFb/5m8PXePPSmZIzHjKnIGP2xNw+91Y856xe36a099dbWe2uht/q2voXe2npv9YlDC721Sm/tsbe26K29Gdp6by30pmSMx4ypyBjbY28t9FY/5qxf3Ka37tRbV++tg97q2/oOeuvqvdUnDh301im9dcfeuqK37mbo6r110JuSMR4zpiJj7I69ddBb/ZizfnGb3sKpt1DvLUBv9W19gN5Cvbf6xCFAb0HpLRx7C0Vv4WYI9d4C9KZkjMeMqcgYw7G3AL3VjznrF7fpLZ56i/XeIvRW39ZH6C3We6tPHCL0FpXe4rG3WPQWb4ZY7y1Cb0rGeMyYiowxHnuL0Fv9mLN+cZvezC6Lw67e3PpMrw429qeNWnnPG7X2YOhwGqr1l4eeFWh2xwaPX84rNLubtFgv8ZSkeoWSNErSVCal9WOTZgdVwpnnykVuyzzjIwNlGiqzvrE/bVTLNFBmfehwGqqWabQyjZRpyjJNKtNAmYbKVJJGSZrKpLQuZRoqs37muXKR2zJtLtNCmZbKrG/sTxvVMi2UWR86nIaqZVqtTCtl2rJMm8q0UKalMpWkUZKmMimtS5mWyqyfea5c5LZMl8t0UKajMusb+9NGtUwHZdaHDqehaplOK9NJma4s06UyHZTpqEwlaZSkqUxK61KmozLrZ54rF7ktMyOMAYUxxDCwsTcEMQYkBoYOhizGaBhjRGNMyTGmSWUCyBgSGS1plKSpTErrUiaxDJx5rlzktswsMwZoxpDNwMb+tFEtE3gGhg6noWqZmtAYIRpTGo3xqUxQmlOSWqbmNJI0lUlpXcokq4Ezz5WL3JaZucaA1xgCG9jYGyIbA2YDQwdDamM0tjHiNqaEG9OmMoFuDNmNljRK0lQmpXUpkwAHzjxXLnJbZjYcA4hjSHFgY2/IcQxADgwdDFGO0SzHCOaYUnNMl8oEzzEEOlrSKElTmZTWpUxSHTjzXLnIbZkZdgzIjiHagY29IdwxoDswdDDkO0YDHiPCY0riMSGVCchjSHm0pFGSpjIprUuZRD1w5rlykdsys/YY4B5D3gMbe0PiY4B8YOhgCH2Mpj5G2MeU7mNiKhPkxxD9aEmjJE1lUlqXMsl/4Mxz5SK3/+uILEAWBMiSAMHG3pIAWRAgGDpYEiCrCZAVAbKlANndTVqsl2lJgLSkUZKmMimtH8u0JEBw5rlykdsyz/4nLSBAlgQINvaWBMiCAMHQwZIAWU2ArAiQLQXImlQmCJAlAdKSRkmayqS0LmWSAMGZ58pFbsvMAmRBgCwJEGzsLQmQBQGCoYMlAbKaAFkrZdqyTJvKBAGyJEBa0ihJU5mU1qVMEiA481y5yG2ZWYAsCJAlAYKNvSUBsiBAMHSwJEBWEyArAmRLAbIulQkCZEmAtKRRkqYyKa1LmSRAcOa5cpHbMrMAWRAgSwIEG3tLAmRBgGDoYEmArCZAVgTIlgJkm1QmCJAlAdKSRkmayqS0LmWSAMGZ58pFbsvMAmRBgCwJEGzsTxvVMkGAYOhwGqqWqQmQFQGypQBZn8oEATolqWVqAiRJU5mU1qVMEiA481y5yG2ZWYAsCJAlAYKNvSUBsiBAMHSwJEBWEyArAmRLAbJtKhMEyJIAaUmjJE1lUlqXMkmA4Mxz5SK3ZWYBsiBAlgQINvaWBMiCAMHQwZIAWU2ArAiQLQXIdqlMECBLAqQljZI0lUlpXcokAYIzz5WL3JaZBciCAFkSINjYWxIgCwIEQwdLAmQ1AbIiQLYUIBtSmSBAlgRISxolaSqT0rqUSQIEZ54rF7ktMwuQBQGyJECwsbckQBYECIYOlgTIagJkRYBsKUA2pjJBgCwJkJY0StJUJqV1KZMECM48Vy5y+/8YyQLkQIAcCRBs7B0JkAMBgqGDIwFymgA5ESBXCpDb3aTFepmOBEhLGiVpKpPS+rFMRwIEZ54rF7kt8+z/5gMC5EiAYGPvSIAcCBAMHRwJkNMEyIkAuVKAnEllggA5EiAtaZSkqUxK61ImCRCcea5c5LbMLEAOBMiRAMHG3pEAORAgGDo4EiCnCZCzUqYty7SpTBAgRwKkJY2SNJVJaV3KJAGCM8+Vi9yWmQXIgQA5EiDY2DsSIAcCBEMHRwLkNAFyIkCuFCDnUpkgQI4ESEsaJWkqk9K6lEkCBGeeKxe5LTMLkAMBciRAsLF3JEAOBAiGDo4EyGkC5ESAXClArkllggA5EiAtaZSkqUxK61ImCRCcea5c5LbMLEAOBMiRAMHG/rRRLRMECIYOp6FqmZoAOREgVwqQ86lMEKBTklqmJkCSNJVJaV3KJAGCM8+Vi9yWmQXIgQA5EiDY2DsSIAcCBEMHRwLkNAFyIkCuFCDXpjJBgBwJkJY0StJUJqV1KZMECM48Vy5yW2YWIAcC5EiAYGPvSIAcCBAMHRwJkNMEyIkAuVKAXJfKBAFyJEBa0ihJU5mU1qVMEiA481y5yG2ZWYAcCJAjAYKNvSMBciBAMHRwJEBOEyAnAuRKAXIhlQkC5EiAtKRRkqYyKa1LmSRAcOa5cpHbMrMAORAgRwIEG3tHAuRAgGDo4EiAnCZATgTIlQLkYioTBMiRAGlJoyRNZVJalzJJgODMc+Uit+8qkAWoAQFqSIBgY9+QADUgQDB0aEiAGk2AGhGgphSgZneTFuEtBkiAtKRRkqYyKa3L+wyQAMGZ58pFbsvMAtSAADUkQLCxb0iAGhAgGDo0JECNJkCNCFBTClBjUpkgQA0JkJY0StJUJqV1KZMECM48Vy5yW2YWoAYEqCEBgo19QwLUgADB0KEhAWo0AWqslGnLMm0qEwSoIQHSkkZJmsqktC5lkgDBmefKRW7LzALUgAA1JECwsW9IgBoQIBg6NCRAjSZAjQhQUwpQ41KZIEANCZCWNErSVCaldSmTBAjOPFcuclvm2Vvx0Hvx4Jvx0Lvx4Nvx0Pvx0Bvy4DvyqG/JIwLUlALULO/KQ2/Lg+/Lo74xjwhQmZTWpUx8cx56d55/QYCaLEANCFBDAgQb+9NGtUwQIBg6nIaqZWoC1IgANaUANT6VCQJ0SlLL1ARIkqYyKa1LmSRAcOa5cpHbMrMANSBADQkQbOwbEqAGBAiGDg0JUKMJUCMC1JQC1LSpTBCghgRISxolaSqT0rqUSQIEZ54rF7ktMwtQAwLUkADBxr4hAWpAgGDo0JAANZoANSJATSlATZfKBAFqSIC0pFGSpjIprUuZJEBw5rlykdsyswA1IEANCRBs7BsSoAYECIYODQlQowlQIwLUlALUhFQmCFBDAqQljZI0lUlpXcokAYIzz5WL3JaZBagBAWpIgGBj35AANSBAMHRoSIAaTYAaEaCmFKAmpjJBgBoSIC1plKSpTErrUiYJEJx5rlzk9v0JswB5ECBPAgQbe08C5EGAYOjgSYC8JkBeBMiXAuR3N2kR3qyQBEhLGiVpKpPSurxjIQkQnHmuXOS2zCxAHgTIkwDBxt6TAHkQIBg6eBIgrwmQFwHypQB5k8oEAfIkQFrSKElTmZTWpUwSIDjzXLnIbZlZgDwIkCcBgo29JwHyIEAwdPAkQF4TIG+lTFuWaVOZIECeBEhLGiVpKpPSupRJAgRnnisXuS0zC5AHAfIkQLCx9yRAHgQIhg6eBMhrAuRFgHwpQN6lMkGAPAmQljRK0lQmpXUpkwQIzjxXLnJbZhYgDwLkSYBgY+9JgDwIEAwdPAmQ1wTIiwD5UoB8k8oEAfIkQFrSKElTmZTWpUwSIDjzXLnIbZln79AMAuRJgGBjf9qolgkCBEOH01C1TE2A/PpWzRfv1by8WTO9WzMJkJY0+vUNmy/esXl9y2Z8z2YQoMpFbsvMAuRBgDwJEGzsPQmQBwGCoYMnAfKaAHkRIF8KkG9TmSBAngRISxolaSqT0rqUSQIEZ54rF7ktMwuQBwHyJECwsfckQB4ECIYOngTIawLkRYB8KUC+S2WCAHkSIC1plKSpTErrUiYJEJx5rlzktswsQB4EyJMAwcbekwB5ECAYOngSIK8JkBcB8qUA+ZDKBAHyJEBa0ihJU5mU1qVMEiA481y5yG2ZWYA8CJAnAYKNvScB8iBAMHTwJEBeEyAvAuRLAfIxlQkC5EmAtKRRkqYyKa1LmSRAcOa5cpHbTzrIAtSCALUkQLCxb0mAWhAgGDq0JECtJkCtCFBbClC7u0mL8LEHJEBa0ihJU5mU1uWzD0iA4Mxz5SK3ZWYBakGAWhIg2Ni3JEAtCBAMHVoSoFYToFYEqC0FqDWpTBCglgRISxolaSqT0rqUSQIEZ54rF7ktMwtQCwLUkgDBxr4lAWpBgGDo0JIAtZoAtVbKtGWZNpUJAtSSAGlJoyRNZVJalzJJgODMc+Uit2VmAWpBgFoSINjYtyRALQgQDB1aEqBWE6BWBKgtBah1qUwQoJYESEsaJWkqk9K6lEkCBGeeKxe5LTMLUAsC1JIAwca+JQFqQYBg6NCSALWaALUiQG0pQG2TygQBakmAtKRRkqYyKa1LmSRAcOa5cpHbMrMAtSBALQkQbOxPG9UyQYBg6HAaqpapCVArAtSWAtT6VCYI0ClJLVMTIEmayqS0LmWSAMGZ58pFbss8++AuEKCWBAg29i0JUAsCBEOHlgSo1QSoXT/B6+IjvJbP8KIP8SIB0pLGdv0cr4sP8lo/yQs/ygsEqHKR2zKzALUgQC0JEGzsWxKgFgQIhg4tCVCrCVArAtSWAtR2qUwQoJYESEsaJWkqk9K6lEkCBGeeKxe5LTMLUAsC1JIAwca+JQFqQYBg6NCSALWaALUiQG0pQG1IZYIAtSRAWtIoSVOZlNalTBIgOPNcuchtmVmAWhCglgQINvYtCVALAgRDh5YEqNUEqBUBaksBamMqEwSoJQHSkkZJmsqktC5lkgDBmefKRW4/MzELUAcC1JEAwca+IwHqQIBg6NCRAHWaAHUiQF0pQN3uJi3CByiSAGlJoyRNZVJal09RJAGCM8+Vi9yWmQWoAwHqSIBgY9+RAHUgQDB06EiAOk2AOhGgrhSgzqQyQYA6EiAtaZSkqUxK61ImCRCcea5c5LbMLEAdCFBHAgQb+44EqAMBgqFDRwLUaQLUWSnTlmXaVCYIUEcCpCWNkjSVSWldyiQBgjPPlYvclpkFqAMB6kiAYGPfkQB1IEAwdOhIgDpNgDoRoK4UoM6lMkGAOhIgLWmUpKlMSutSJgkQnHmuXOS2zCxAHQhQRwIEG/uOBKgDAYKhQ0cC1GkC1IkAdaUAdU0qEwSoIwHSkkZJmsqktC5lkgDBmefKRW7LzALUgQB1JECwsT9tVMsEAYKhw2moWqYmQJ0IUFcKUOdTmSBApyS1TE2AJGkqk9K6lEkCBGeeKxe5LTMLUAcC1JEAwca+IwHqQIBg6NCRAHWaAHUiQF0pQF2bygQB6kiAtKRRkqYyKa1LmSRAcOa5cpHbMs8+zx0EqCMBgo19RwLUgQDB0KEjAeo0AerWD3a/+GT35aPd6bPdSYC0pLFbP9794vPd1w94x094BwGqXOS2zCxAHQhQRwIEG/uOBKgDAYKhQ0cC1GkC1IkAdaUAdSGVCQLUkQBpSaMkTWVSWpcySYDgzHPlIrdlZgHqQIA6EiDY2HckQB0IEAwdOhKgThOgTgSoKwWoi6lMEKCOBEhLGiVpKpPSupRJAgRnnisXuSkzZAEKIECBBAg29oEEKIAAwdAhkAAFTYCCCFAoBSjsbtJivcxAAqQljZI0lUlp/VhmIAGCM8+Vi9yWmQUogAAFEiDY2AcSoAACBEOHQAIUNAEKIkChFKBgUpkgQIEESEsaJWkqk9K6lEkCBGeeKxe5LTMLUAABCiRAsLEPJEABBAiGDoEEKGgCFKyUacsybSoTBCiQAGlJoyRNZVJalzJJgODMc+Uit2VmAQogQIEECDb2gQQogADB0CGQAAVNgIIIUCgFKLhUJghQIAHSkkZJmsqktC5lkgDBmefKRW7LzAIUQIACCRBs7AMJUAABgqFDIAEKmgAFEaBQClBoUpkgQIEESEsaJWkqk9K6lEkCBGeeKxe5LTMLUAABCiRAsLE/bVTLBAGCocNpqFqmJkBBBCiUAhR8KhME6JSklqkJkCRNZVJalzJJgODMc+Uit2VmAQogQIEECDb2gQQogADB0CGQAAVNgIIIUCgFKLSpTBCgQAKkJY2SNJVJaV3KJAGCM8+Vi9yWmQUogAAFEiDY2AcSoAACBEOHQAIUNAEKIkChFKDQpTJBgAIJkJY0StJUJqV1KZMECM48Vy5yW2YWoAACFEiAYGMfSIACCBAMHQIJUNAEKIgAhVKAQkhlggAFEiAtaZSkqUxK61ImCRCcea5c5LbMLEABBCiQAMHGPpAABRAgGDoEEqCgCVAQAQqlAIWYygQBCiRAWtIoSVOZlNalTBIgOPNcuchNmTELUAQBiiRAsLGPJEARBAiGDpEEKGoCFEWAYilAcXeTFutlRhIgLWmUpKlMSuvHMiMJEJx5rlzktswsQBEEKJIAwcY+kgBFECAYOkQSoKgJUBQBiqUARZPKBAGKJEBa0ihJU5mU1qVMEiA481y5yG2ZWYAiCFAkAYKNfSQBiiBAMHSIJEBRE6BopUxblmlTmSBAkQRISxolaSqT0rqUSQIEZ54rF7ktMwtQBAGKJECwsY8kQBEECIYOkQQoagIURYBiKUDRpTJBgCIJkJY0StJUJqV1KZMECM48Vy5yW2YWoAgCFEmAYGMfSYAiCBAMHSIJUNQEKIoAxVKAYpPKBAGKJEBa0ihJU5mU1qVMEiA481y5yG2ZWYAiCFAkAYKN/WmjWiYIEAwdTkPVMjUBiiJAsRSg6FOZIECnJLVMTYAkaSqT0rqUSQIEZ54rF7ktMwtQBAGKJECwsY8kQBEECIYOkQQoagIURYBiKUCxTWWCAEUSIC1plKSpTErrUiYJEJx5rlzktswsQBEEKJIAwcY+kgBFECAYOkQSoKgJUBQBiqUAxS6VCQIUSYC0pFGSpjIprUuZJEBw5rlykdsyswBFEKBIAgQb+0gCFEGAYOgQSYCiJkBRBCiWAhRDKhMEKJIAaUmjJE1lUlqXMkmA4Mxz5SK3ZWYBiiBAkQQINvaRBCiCAMHQIZIARU2AoghQLAUoxlQmCFAkAdKSRkmayqS0LmWSAMGZ58pFbso0u0xAy5+rdT4/1PukrX3eqjV62qpVSnOHPFcr9WzuWatp9VirfD3vNa3cLMv1ZnOeVq2aN65500Xe8uRYb/oK/dIFzLWLLRo2Zw0DDD0/rDUMNJS36g0DDtHcIc/VG9Z8KK2uDZdClFaWhsGIcp7esKZEa950kbc8WRsmKaILmGsXWzRszxoGLXp+WGsYvChv1RsGMaK5Q56rN6yhUVpdG7YXDdulYYCjnKc3rNHRmjdd5C1P1oaJj+gC5trFFg27s4aBkJ4f1hoGRMpb9YaBkWjukOfqDWuSlFbXhktLSitLw6BJOU9vWPOkNW+6yFuerA2TKdEFzLWLLRpuzhoGV3p+WGsYZClv1RsGW6K5Q56rN6zxUlpdGy6BKa0sDQMx5Ty9YQ2Z1rzpIm95sjZM0EQXMNcutmjYnzUM2PT8sNYwcFPeqjcM4ERzhzxXb1gzp7S6NlyqU1pZGgZ3ynl6w5o8rXnTRd7yZG2Y9IkuYK5dbNFwe9YwCNTzw1rDYFB5q94wKBTNHfJcvWENotLq2nBJUWllaRgwKufpDWscteZNF3nLk7VhIim6gLl2sUXD3VnDwFLPD2sNA0zlrXrDQFM0d8hz9YY1nUqra8OlT6WVpWEQqpynN6wZ1Zo3XeQtT9aGyanoAubaxRYNh7OGwaqeH9YaBq3KW/WGwato7pDn6g1rZJVW14ZLtEorS8PAVjlPb1iDqzVvushbnqwNE17RBcy1iy0ajmcNA2A9P6w1DISVt+oNA2LR3CHP1RvWHCutrg2XkpVWlobBsnKe3rCmWWvedJG3PFkbJtGiC5hrF7tt2JyZliHTMmhasLXPW9WGDZkWzB3yXLVho5qWWU3LXJiWWUzLkGkZNC0tb1zzpou85Yk0bNC04ALm2sUWDZ+ZliHTMmhasLXPW/WGybRg7pDn6g2rpmVW0zIXpmUW0zJkWgZNS8sb17zpIm95sjaMpgUXMNcutmj4zLQMmZZB04Ktfd6qN0ymBXOHPFdvWDUtY9eG7UXDi2kZMi2DpqXljWvedJG3PFkbRtOCC5hrF1s0fGZahkzLoGnB1j5v1Rsm04K5Q56rN6yalllNy1yYlllMy5BpGTQtLW9c86aLvOXJ2jCaFlzAXLvYouEz0zJkWgZNC7b2eaveMJkWzB3yXL1h1bTMalrmwrTMYlqGTMugaWl545o3XeQtT9aG0bTgAubaxRYNn5mWIdMyaFqwtc9b9YbJtGDukOfqDaumZVbTMhemZRbTMmRapzy9YdW0zGpaZd7yZG0YTQsuYK5dbNHwmWkZMi2DpgVb+7xVb5hMC+YOea7esGpaZjUtc2FaZjEtQ6Zl0LS0vHHNmy7ylidrw2hacAFz7WKLhs9My5BpGTQt2NrnrXrDZFowd8hz9YZV0zKraZkL0zKLaRkyLYOmpeWNa950kbc8WRtG04ILmGsXWzR8ZlqGTMugacHWPm/VGybTgrlDnqs3rJqWWU3LXJiWWUzLkGkZNC0tb1zzpou85cnaMJoWXMBcu9ii4TPTMmRaBk0LtvZ5q94wmRbMHfJcvWHVtMxqWubCtMxiWoZMy6BpaXnjmjdd5C1P1obRtOAC5trFbhu2Z6ZlybQsmhZs7fNWtWFLpgVzhzxXbdiqpmVX07IXpmUX07JkWhZNS8sb17zpIm95Ig1bNC24gLl2sUXDZ6ZlybQsmhZs7fNWvWEyLZg75Ll6w6pp2dW07IVp2cW0LJmWRdPS8sY1b7rIW56sDaNpwQXMtYstGj4zLUumZdG0YGuft+oNk2nB3CHP1RtWTcvatWF70fBiWpZMy6JpaXnjmjdd5C1P1obRtOAC5trFFg2fmZYl07JoWrC1z1v1hsm0YO6Q5+oNq6ZlV9OyF6ZlF9OyZFoWTUvLG9e86SJvebI2jKYFFzDXLlYavn16t98f+rvD3csXdz8fHl7dvz/sH68e929S1+7r4+7bly8+7B/f7r/bv3//dPXTw88f05jl3+qn1fX19uvZLq++zS9/+eLT4/3Hw58/He4fPj5dvXt4vP/nw8fD3fvv9h9T0P71Milt+XT3dv/fd49v79OL3u/fpIDdb9PP+3j/9t3znw8Pn45/Sof88eFwePjw/N27/d3r/ePyXTrpm4eHw/M3aa48e3VcfPni4fXr8biQfsazP6c/rq/41d2HT998d/xnvPrVfzjjnf3m6vj998v3cWfjN1e36Y92F5q4PvrT6dFx7HPa/pf9x1Pc+TfLn59fdHv+zZv7x6fDacvmu+M3p03b77aHvP388Pi3Y60v/x9QSwMEFAAAAAgA8SFcXRGyuwBbDAAABmIAABgAAAB4bC93b3Jrc2hlZXRzL3NoZWV0My54bWyNnV1z4kYahf8KRapyGdSf6s7Yrtq4481WJbtTSe3uNTOWx1QweEETJ/n1KwlQqwnvM9wMSEdHOq+AeWaMdHzztt39un9umnb2+8t6s7+dP7ft67eLxf7jc/Oy3H+zfW02nfK03b0s225x92mxf901y8fB9LJe6Kryi5flajO/uxnWvd/d3bTLD/fb9XY32336cDt/eLj3Lio1X9zdbD+369Wmeb+b7T+/vCx3f3zXrLdvt3M1P634efXpue1XdFu/Lj81vzTtv1/f77qlxbj/x9VLs9mvtpvZrnm6nf9NffugtOkdwyb/WTVv+8nz2f55+/b33erxx+7Q3YzVfNbP/WG7/bWX//HYr+qPtmlmf/zyul51xzfzWbt9/bF5au+b9bo7hp3Plh/b1W/N+26z2/mHbdtuX3q9S94u227V0277Z7MZUjTrptu2y/f6l40POznutB/7f8cZ5uOIfajp89MsD8Or0J27D8t9053g/64e2+fbeZjPHpun5ed1+/P27YfmeP5cv7+P2/V++HP2dti2ns8+ft53YY7eLsDLanN4XP5+PO2T7VUUDPpo0GcGbQWDORrMuUELBns02DODC4LBHQ3uzGClI/ijwQ+n/nCuhhOdlu3y7ma3fZvt+q27vfVPhlerO93dKelOcP+GX3w8St/J0r0sJVn6XpYeLkqLLu0YuRu4fw+Y6jT4+K4YZ9HDTlTlhr2sNv2n8pd21+mr7iy0d19/pSut3Lvu0ftg+8fKBNU/OuuGZWVdNSxrZ97l7Y1xJvbLWvteNy7oMOxHaf/uZtF2Yftj/CW1+XJqM6SOWg5tdVUfwkV3drDDK/XlXUQdhvy+qvpH043Xz2uqWvfze6fDMI+LcTgf3ip9XB8vHfL+y4esQjWcQq10dTyV9tKu0hXpjff9Lqyr60u7+P6LuzDBhH4gEytvv/ACHt6RX06l68M5i3U17Nrpajh3df2XQYv3hB1fens4hrvw4bPH97K/8OmTbeloU9WFj99JUxc+f5e1IrYbYzs5toPYsi05iO0g9mWtiO3H2F6O7SG2bEseYnuIfVkrYtdj7FqOXUNs2ZZqiF1D7MtaETuMsYMcO0Bs2ZYCxA4Q+7JWxI5j7CjHjhBbtqUIsSPEvqwVsVWVOV7JwY/a5eRgTCfjxeyjeCm8IJbpJ/8KUZBeUXrZmE7Gy+kVpb8slul1Tq8hvab0sjGdjJfTa0p/WSzTm5zeQHpD6WVjOhkvpzeU/rJYps8IVcBQRRAFY1KEUUUcFcQyfSapApQqYikYkyKaKsKpIJbpM1AVEFURUsGYFEFVEVUFsUyfuaoArIrICsakiK2K4CqIZfqMVwV8VQRYMCZFiFXEWEEs02fKKsCsIs6CMSkirSLUCmL5/8/MWg2s1cRaMCZNrNXEWkEs00/+lwys1cRaMCZNrNXEWkEs02fWamCtJtaCMWlirSbWCmKZPrNWA2s1sRaMSRNrNbFWEMv0mbUaWKuJtWBMmliribWCWKbPrNXAWk2sBWPSxFpNrBXEMn1mrQbWamItGJMm1mpirSCW6TNrNbBWE2vBmDSxVhNrBbFMn1mrgbWaWAvGpIm1mlgriGX6zFoNrNXEWjAmTazVxFpBLH9qmllrgLWGWAvGZIi1hlgriGX6yc92gbWGWAvGZIi1hlgriGX6zFoDrDXEWjAmQ6w1xFpBLNNn1hpgrSHWgjEZYq0h1gpimT6z1gBrDbEWjMkQaw2xVhDL9Jm1BlhriLVgTIZYa4i1glimz6w1wFpDrAVjMsRaQ6wVxDJ9Zq0B1hpiLRiTIdYaYq0glukzaw2w1hBrwZgMsdYQawWxTJ9Za4C1hlgLxmSItYZYK4jlt1GZtRZYa4m1YEyWWGuJtYJYps+stcBaS6wFY7LEWkusFcQyfWatBdZaYi0YkyXWWmKtIJbpM2stsNYSa8GYLLHWEmsFsUw/+RqWvofFL2Lpm1j8Kha/i72CtTaz1gJrLbEWjMkSay2xVhDL9Jm1FlhribVgTJZYa4m1glimz6y1wFpLrAVjssRaS6wVxDJ9Zq0F1lpiLRiTJdZaYq0glukzay2w1hJrwZgssdYSawWxvIQis9YBax2xFozJEWsdsVYQy/SZtQ5Y64i1YEyOWOuItYJYps+sdcBaR6wFY3LEWkesFcQyfWatA9Y6Yi0YkyPWOmKtIJbpM2sdsNYRa8GYHLHWEWsFsUw/ufIJWOuItWBMjljriLWCWKbPrHXAWkesBWNyxFpHrBXEMn1mrQPWOmItGJMj1jpirSCW6TNrHbDWEWvBmByx1hFrBbFMn1nrgLWOWAvG5Ii1jlgriOV1f5m1HljribVgTJ5Y64m1glimz6z1wFpPrAVj8sRaT6wVxDJ9Zq0H1npiLRiTJ9Z6Yq0glukzaz2w1hNrwZg8sdYTawWxTJ9Z64G1nlgLxuSJtZ5YK4hl+sxaD6z1xFowJk+s9cRaQSzTTy42pquN8XJjut4YLzjGK46vYK3PrPXAWk+sBWPyxFpPrBXEMn1mrQfWemItGJMn1npirSCW6TNrPbDWE2vBmDyx1hNrBbG8WD2ztgbW1sRaMKaaWFsTawWxTJ9ZWwNra2ItGFNNrK2JtYJYps+srYG1NbEWjKkm1tbEWkEs02fW1sDamlgLxlQTa2tirSCW6TNra2BtTawFY6qJtTWxVhDL9Jm1NbC2JtaCMdXE2ppYK4hl+szaGlhbE2vBmGpibU2sFcQy/eT+HrrBB+/woVt88B4fvMnnCtbWmbU1sLYm1oIx1cTamlgriGX6zNoaWFsTa8GYamJtTawVxPIOq8zaAKwNxFowpkCsDcRaQSzTZ9YGYG0g1oIxBWJtINYKYpk+szYAawOxFowpEGsDsVYQy/SZtQFYG4i1YEyBWBuItYJYps+sDcDaQKwFYwrE2kCsFcQyfWZtANYGYi0YUyDWBmKtIJbpM2sDsDYQa8GYArE2EGsFsUyfWRuAtYFYC8YUiLWBWCuIZfrJLbV0Ty3eVEt31eJttXhf7RWsDZm1AVgbiLVgTIFYG4i1gljeFpxZG4G1kVgLxhSJtZFYK4hl+szaCKyNxFowpkisjcRaQSzTZ9ZGYG0k1oIxRWJtJNYKYpk+szYCayOxFowpEmsjsVYQy/SZtRFYG4m1YEyRWBuJtYJYps+sjcDaSKwFY4rE2kisFcQyfWZtBNZGYi0YUyTWRmKtIJbpM2sjsDYSa8GYIrE2EmsFsUyfWRuBtZFYC8YUibWRWCuIZfpJiwXVWGCPBRVZYJMFVllc1WUxLbMA2p5Eqc4CeDtahUILIq6kng0x6bSoALonURoCsDtahSEIvJJ6NsSk2qKibosKyy3AmkarMAT2Wwjq2RCThouKKi4q7LgAaxqtwhBYcyGoZ0NMii4qarqosOoCrGm0CkNg24Wgng0x6buoAMgnURoCkDxahSEIypJ6NsSk9qICLp9EaQgg82gVhiA2S+rZEJP2i4rqLyrsvwBrGq3CEFiBIahnQ0xKMCpqwaiwBgOsabQKQ2AThqCeDTHpwqioDKPCNgywptEqDIGFGIJ61t80ITb2T3EBFTZQcQUVd1BdV0I1baEiYiskNljTaBWGQGIL6tkQE2JjGxXXUWEfFRdScSPVVZVU004qLKXiViqspeJeKi6muqqZalpNhd1UXE6F7VRcT8X9VFcVVE0bqrCiijuqsKSKW6q4puqqnqppURU2VXFVFXZVcVkVt1VdVVc17avCwipurMLKKu6s4tKqq1qrprVV2FvFxVXYXMXVVdxddVV51bS9CuuruL8KC6y4wYorrK7psFKTEitFLVYKa6zImhQWWSlsspLUsyEmxKYyK4VtVmRNCvusFBZaSerZENP6SOyP5AJJbJDkCknukLyG2JNmK0XVVgq7rciaFLZbKay3ktTDEItJLfryc7t9WK3bZnds3zdj+/5Ls/s0VNvvZx+3nzfdbvq337j2uL3+9mFojV/kze9uXnerTfuv1740fz973u5Wf2437XJ932y6AzWPt/kXAvy03H1adRutm6fuANU33d+qu0NP+PC83b4Oz7oTdKjdPy09N8vHZtcvdZM+bbftaaHb70F7GFbe3WwfH38YVnQZJ8+7p8ctvl6+vL67H/6Ms6+/MsoZ/W42LL+fDcXZOr6bLWZDs7eNR+mfozTs9nS05rdmMx5uutA/P220mC48rXb7drQUS8PCaCqXyiEX469+uPs/UEsDBBQAAAAIAPEhXF1kwcFG/wUAAFFYAAANAAAAeGwvc3R5bGVzLnhtbO1c34+jNhD+VxBVX5efIVAlkXbZjdqHVpXuHtpHNiEJEgEOvNvs/fXFQBKTeDgTbCCnTbQKYM/nb8bj8dgszDL0Efpfdr6PpMM+jLK5vEMo+U1RstXO33vZQ5z4UV6yidO9h/LTdKtkSep76wwL7UNFV1VL2XtBJC9m0dt+uUeZtIrfIjSX9dMlqfz5Yz2XNcuUpRLOjdf+XFYf1F9lhVpzclVT/SX/4NpK1dZitomjc5OaI5dXcjxv70vvXjiXXS8NAxRjsex7eUnTCpCy5mX9xzTwQlz+WlXGx6s4jFMp3b7O5eVSW5ovU7sGOOkE6LiTqarWANVOgOVHrMpMgAEEOHmyJlOjvcoXrHTHmHK0262AoJoCGF51hMlb5W6AFN9rAvwzWKVxFm+Q9K/3ux8wWfChabhRAHmNkzbQFN68oCms+ZmEh71bDQdOzFWVYhabgC5+8IwRhOFpxrDl8sJilngI+Wm0zE8KmeLiVZFUHX/9SPIpaZt6H5pe8WcRyOIwWOMmt+5Fh+quW8AQoh1Bz5GCI+iz8/K4nHIGXbov5rN1D+prtmGaSxC0+Mld7DVO1356TktM+XhtMQv9Dcrl02C7w78oTrBPxwjF+/xgHXjbOPIKFzxKkJJSkbLNZbQrUi4gLCi4atUGo0RRt6DDKJDXPPJmlCgrd9Pxaeo6lasw6khIsOlICDDqSEjw0DEfY/rSaKMjIcGmIyHAqCMhwUPHF+vJfmzlq4QEm46EAKOOhASrjvWR3H7oMAx5pb+B3ILNrQpzjhU9GkcQ8x8bkh6QOHkOp/DI1XN6icA9Gqe3uUNVXfvZepmwx9WaBIuONQEmHWsSRx1PilUHedK08sPwCwb5Z3POnHKow4bYFVLxnlB0OszTreqwhClPcEMkWolNwmr6TcBSErzH6Okt1yEqzr+9xcj/O/U3waE4P2xODCB0TSg6wV3nj64LRSe4G/zRjUHQNdHoXpKEH49hsI32fjlimBtczLyjnLSL0+B73hpeNa/yC35ajKLDpv0w0W9X2RSKXu099zFQCHSTP7opFH0iNEA1oHNy5f9SL/nqH1C1RdTow5ZQXad9oQvw4OkYQw7UXXxCjgB0Onde3VULaALw6e4gIOTY9xIUOLF591MUrFo4fkMkGQGlS38bAaX+YlZ7mg1xplfLsYW+oTqzIZ71Sok1yI7A6S8j81CUxIfzK0qtArwjNC8Tv1hro+sgS8dWDKGVntEhqXPEwgtFh5apvPAHd45ug7fBIv3Onmw+NtSMPhZKrN481Fw1AKVW7j6SnJbLAmrIIToWTsOa6cfdyLAoGDSEjIUUQwgxxSYwHeDZyA+QrRJsJsOzGSb28oi0nFxPADyd/Ag6u0HX0U1afXPqtdO45UvWiPcAjU+aorJP8XvlXEyrQTPvyHiK31/kTfNuPJV0gemIbatp98FT/F2M22n2erOFtzUF3eu4nWbPN2W42FP8XRGSJv7vz/Hv43QYT73u7QgNTz3THNkeEP8gMDqig/mAyCDAb8EnNgiMgWev62eh+/k9cObhtJoufLI9E0Rx0pIdkQoMkk+3Z2wKz7G6sBv6PnZrxtDafyp0T9/m8wALNLa0vuZabubW+DyeAcLz+b/kOzR4H5S70JtAAeMuLKqPmHItKb8X0qSdiWTHvBPK0I63IMqXCVqn+XrE+Q+5uviMwYLconrN231ZGQxyYyYNuMbkk3Inb1aqZ8uJB9hrj6+frkr4rVZz+S/8SsOwlvidH1bPqifn898gWvsHf+1Wp+n21SWfqS8/WPqy5PwuiusSSKYso5fgMqgdiAEkU0pB7fxM+tigPmUZxM2mltigjA3KlFK0Erf4Qu3QZZz8Q9fUcQzDsiCLlq81u2LgQnazLPxHR4O4YQmoHdxSO1vDvQ17SLMfQH3a5CGQprAnQprCtsYldLthCceh9zbUDpaAegHyHdw+vR3sU3QZw8C9CnGDRjBc4jhQCfZFuo9aFmAdC3/p/QONEsNwHHoJLqMzMAyoBI9GuARigDlAJUb51q+L+Ug5zlPK+SXCi/8BUEsDBBQAAAAIAPEhXF2XirscwAAAABMCAAALAAAAX3JlbHMvLnJlbHOdkrluwzAMQH/F0J4wB9AhiDNl8RYE+QFWog/YEgWKRZ2/r9qlcZALGXk9PBLcHmlA7TiktoupGP0QUmla1bgBSLYlj2nOkUKu1CweNYfSQETbY0OwWiw+QC4ZZre9ZBanc6RXiFzXnaU92y9PQW+ArzpMcUJpSEszDvDN0n8y9/MMNUXlSiOVWxp40+X+duBJ0aEiWBaaRcnToh2lfx3H9pDT6a9jIrR6W+j5cWhUCo7cYyWMcWK0/jWCyQ/sfgBQSwMEFAAAAAgA8SFcXS/qTLs7AQAAOQMAAA8AAAB4bC93b3JrYm9vay54bWy1kt1KwzAUx1+lhsLulrUFL0pXEMZgICL4ACNrTm1YPkoSdZdeKXixa1/AaxEExfk4o/MxzD4K3ZQhwq6ScA7/3y85SW6UHo+UGnsTwaXposLaMsbYZAUIYtqqBOkqudKCWHfUl9iUGgg1BYAVHIedzjEWhEmUJnXWucZpsmowm3WdHuu/5Ks8Zxn0VHYlQNo1QAMnlilpClYa5EkioIs6gVc9PM1nb9XLfXU7Q94KNaBdFLi9Jdb1XDPDRhyQp2PmCnpAA4QPKhXWUo/TxeyuIRXukQoPLBV5i88PJzV/n349vzq1hle0xytaeuF6lBRyJoGeuczt0wYznHAp2sM+4xZ0j1gyIsalcZURftGYTcEoBbncpq2d92od+Sd+FPunfhBGCW4w/g0Md4A/3qJm9n9h4u074/qLp99QSwMEFAAAAAgA8SFcXbts6uy6AAAAGgMAABoAAAB4bC9fcmVscy93b3JrYm9vay54bWwucmVsc8WTOQ6DMBBFr4J8AIYlSREBVRraiAtYMCxiseWZKHD7ECjAUoo0iMr6Y/n9V4yjJ3aSGzVQ3Whyxr4bKBY1s74DUF5jL8lVGof5plSmlzxHU4GWeSsrhMDzbmD2DJFEe6aTTRr/IaqybHJ8qPzV48A/wPBWpqUakYWTSVMhxwLGbhsTLIfvzmThpEUsTFr4As4WCiyh4Hyh0BIKDxQinjqkzWbNVv3lwHqe3+LWvsR1aC/J9esA1ldIPlBLAwQUAAAACADxIVxdpvxKWyMBAADfBAAAEwAAAFtDb250ZW50X1R5cGVzXS54bWzNlM9OwzAMxl+l6nVqMobEAa27AFfYgRcIjbtGzT/F3ujeHrfdJoFGxTQkuDRqbH8/x5+S5es+Amadsx7LvCGK91Ji1YBTKEIEz5E6JKeIf9NGRlW1agNyMZ/fySp4Ak8F9Rr5avkItdpayp463kYTfJknsJhnD2NizypzFaM1lSKOy53XXyjFgSC4csjBxkSccUIuzxL6yPeAQ93LDlIyGrK1SvSsHGfJzkqkvQUU0xJnegx1bSrQodo6LhEYEyiNDQA5K0bR2TSZeMIwfm+u5g8yU0DOXKcQkR1LcDnuaElfXUQWgkRm+ognIktffT7o3dagf8jm8b6H1A5+oByW62f82eOT/oV9LP5JH7d/2MdbCO1vX7l+FU4Zf+TL4V1bfQBQSwECFAMUAAAACADxIVxdRsdNSJUAAADNAAAAEAAAAAAAAAAAAAAAgAEAAAAAZG9jUHJvcHMvYXBwLnhtbFBLAQIUAxQAAAAIAPEhXF35FXQY7wAAACsCAAARAAAAAAAAAAAAAACAAcMAAABkb2NQcm9wcy9jb3JlLnhtbFBLAQIUAxQAAAAIAPEhXF36XAFZ/AIAANoNAAATAAAAAAAAAAAAAACAAeEBAAB4bC90aGVtZS90aGVtZTEueG1sUEsBAhQDFAAAAAgA8SFcXfjpeA9WBgAAjRgAABgAAAAAAAAAAAAAAICBDgUAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbFBLAQIUAxQAAAAIAPEhXF1QW6/65R8AANjlAAAYAAAAAAAAAAAAAACAgZoLAAB4bC93b3Jrc2hlZXRzL3NoZWV0Mi54bWxQSwECFAMUAAAACADxIVxdEbK7AFsMAAAGYgAAGAAAAAAAAAAAAAAAgIG1KwAAeGwvd29ya3NoZWV0cy9zaGVldDMueG1sUEsBAhQDFAAAAAgA8SFcXWTBwUb/BQAAUVgAAA0AAAAAAAAAAAAAAIABRjgAAHhsL3N0eWxlcy54bWxQSwECFAMUAAAACADxIVxdl4q7HMAAAAATAgAACwAAAAAAAAAAAAAAgAFwPgAAX3JlbHMvLnJlbHNQSwECFAMUAAAACADxIVxdL+pMuzsBAAA5AwAADwAAAAAAAAAAAAAAgAFZPwAAeGwvd29ya2Jvb2sueG1sUEsBAhQDFAAAAAgA8SFcXbts6uy6AAAAGgMAABoAAAAAAAAAAAAAAIABwUAAAHhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzUEsBAhQDFAAAAAgA8SFcXab8SlsjAQAA3wQAABMAAAAAAAAAAAAAAIABs0EAAFtDb250ZW50X1R5cGVzXS54bWxQSwUGAAAAAAsACwDKAgAAB0MAAAAA'
_LAYOUT_SPEC={'01 报价汇总': {'start': 6, 'minimum': 21, 'columns': 4, 'widths': [28, 28, 18, 18], 'header_end': 5, 'paper': 9, 'orientation': 'portrait', 'min_height': 24}, '02 报价明细': {'start': 4, 'columns': 12, 'widths': [6, 18, 22, 29, 9, 8, 13, 14, 10, 15, 20, 45], 'header_end': 3}, '03 缺价与说明': {'start': 4, 'columns': 6, 'widths': [7, 19, 24, 22, 58, 42], 'header_end': 3}}
_v182_layout_base=main
def main(results, confirmed_bom_json='', markup_rate='0.15', discount_rate='0.02'):
    out=_v182_layout_base(results, confirmed_bom_json, markup_rate, discount_rate)
    out["template_base64"]=layout_template(_LAYOUT_TEMPLATE,out['quote_payload_json'],_LAYOUT_SPEC)
    return out
