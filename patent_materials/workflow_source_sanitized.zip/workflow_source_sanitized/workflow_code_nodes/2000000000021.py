import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)
import json
import re

def clean(value):
    if value is None:
        return ''
    if isinstance(value, list):
        return ' '.join((clean(x) for x in value))
    if isinstance(value, dict):
        return ' '.join((clean(x) for x in value.values()))
    return re.sub('\\s+', ' ', str(value)).strip()

def first_value(data, *keys):
    for key in keys:
        value = data.get(key)
        if value not in (None, '', []):
            return clean(value)
    return ''

def main__v16_before_1(requirement: dict) -> dict:
    item = requirement if isinstance(requirement, dict) else {}
    req = item.get('requirements') if isinstance(item.get('requirements'), dict) else {}
    model = clean(item.get('shown_model'))
    if not model:
        summary = clean(item.get('requirement_summary'))
        m = re.search('\\b([A-Z]{2,}\\d[A-Z0-9_-]*(?:-\\d+[A-Z0-9_-]*)?)\\b', summary, re.I)
        if m:
            model = m.group(1)
    role = clean(item.get('component_role'))
    category = clean(item.get('category_path') or role)
    pole = first_value(req, 'pole_count')
    current = first_value(req, 'rated_current_a', 'rated_current_min_a')
    curve = first_value(req, 'trip_curve', 'tripping_curve')
    voltage = first_value(req, 'rated_voltage_v', 'voltage_v', 'uc_v')
    capacity = first_value(req, 'breaking_capacity_min_ka')
    imax = first_value(req, 'max_discharge_current_ka', 'imax_ka')
    exact = []
    if model:
        exact.append(model)
    if pole:
        exact.append(pole)
    if curve and current:
        exact.append(curve + current)
    elif current:
        exact.append(current + 'A')
    if voltage:
        exact.append(voltage + 'V')
    if imax:
        exact.append('Imax' + imax + 'kA')
    curve_current = (curve + ' ' + current + 'A').strip() if curve or current else ''
    terms = [' '.join(exact), model, role, category, pole, curve_current, ('分断能力 ' + capacity + 'kA').strip() if capacity else '', ('最大放电电流 ' + imax + 'kA').strip() if imax else '']
    unique = []
    for value in terms:
        value = clean(value)
        if value and value not in unique:
            unique.append(value)
    query = '；'.join(unique)[:240]
    return {'retrieval_query': query or '物料编码 PRODUCT ' + role, 'requirement_json': json.dumps(item, ensure_ascii=False), 'request_id': clean(item.get('request_id')), 'scheme_group_id': clean(item.get('scheme_group_id')), 'component_role': role}
_query_previous_main = main__v16_before_1

def main(requirement):
    item = requirement
    if isinstance(item, dict) and item.get('transport_schema') == 'requirement-envelope-v1':
        restored = wire_loads(item.get('payload_json'))
        if not isinstance(restored, dict) or restored.get('request_id') != item.get('request_id'):
            raise ValueError('需求传递内容与关联编号不一致，停止该项检索')
        item = restored
    return _query_previous_main(item)

_v182_query_base=main
import unicodedata
from decimal import Decimal
_v182_first_value=first_value
def first_value(data,*keys):
    value=_v182_first_value(data,*keys)
    return format(Decimal(value).normalize(),'f') if re.fullmatch(r'[0-9]+(?:\.[0-9]+)?',value) else value
def main(requirement):
    out=_v182_query_base(requirement)
    item=wire_loads(out['requirement_json'])
    model=unicodedata.normalize('NFKC',clean(item.get('shown_model')))
    token=re.split(r'[\s;；,，]+',model)[0]
    out['search_model']=token if re.fullmatch(r'(?=.*[A-Za-z])(?=.*\d)[A-Za-z][A-Za-z0-9._/-]{2,}',token) else ''
    out['search_category']=''
    return out
