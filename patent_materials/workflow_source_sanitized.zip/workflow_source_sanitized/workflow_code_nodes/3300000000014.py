import math
import json
import re
EXPECTED_HEADERS = ['序号', '回路/位号', '元器件名称', '关键技术参数', '推荐型号', '物料编码', '数量', '系统状态', '工程师确认', '修改意见']
ACTIONS = {'CONFIRM', 'MODIFIED_CONFIRM', 'EXCLUDE', 'RESELECT', 'RETURN_MATERIAL', 'PENDING', 'NEED_CLARIFICATION'}
CONFIDENCE_LIMIT = 0.85

def clean(value):
    text = '' if value is None else str(value)
    return text.replace('\u200b', '').replace('\ufeff', '').strip()

def safe_cell(value):
    text = clean(value).replace('|', '／').replace('\r', ' ').replace('\n', ' ')
    return "'" + text if text.startswith(('=', '+', '-', '@')) else text

def load_json(value):
    if isinstance(value, dict):
        return value
    text = clean(value)
    text = re.sub('^```(?:json)?\\s*', '', text, flags=re.I)
    text = re.sub('\\s*```$', '', text)
    start, end = (text.find('{'), text.rfind('}'))
    if start < 0 or end <= start:
        raise ValueError('未识别到工程师意见JSON')
    return json.loads(text[start:end + 1])

def number(value, default=0.0):
    try:
        x = float(value)
        return x if math.isfinite(x) and 0 <= x <= 1 else default
    except (ValueError, TypeError, OverflowError):
        return default

def parse_quantity(value):
    text = clean(value)
    match = re.fullmatch('((?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]+)(?:[.][0-9]+)?)\\s*([A-Za-z\\u4e00-\\u9fff²³]*)', text)
    if not match:
        return (None, '')
    qty = float(match.group(1).replace(',', ''))
    unit = match.group(2) or '台'
    if not math.isfinite(qty) or qty <= 0 or (unit in ('台', '件', '只', '个', '套', '根', '支', '块', '颗', '处', '组') and int(qty) != qty):
        return (None, '')
    return (int(qty) if qty.is_integer() else qty, unit)

def issue_line(row):
    return '| %s | %s | %s | %s | %s |' % (safe_cell(row.get('序号')), safe_cell(row.get('回路/位号')), safe_cell(row.get('元器件名称')), safe_cell(row.get('normalized_action')), safe_cell(row.get('issue_reason') or row.get('action_reason') or row.get('修改意见') or '未说明'))

def result(status, message, markdown='', formal_items=None, counts=None):
    formal_items = formal_items or []
    counts = counts or {}
    allowed = status == 'APPROVED'
    formal_bom = {'schema_version': 'formal-bom-v1.1', 'bom_status': 'BOM_CONFIRMED_WAITING_PRICING' if allowed else status, 'pricing_allowed': allowed, 'price_library_status': 'CONNECTED_MONGODB', 'items': formal_items if allowed else []}
    return {'review_status': status, 'review_message': message, 'review_markdown': markdown, 'formal_bom_json': json.dumps(formal_bom, ensure_ascii=False), 'formal_payload_json': json.dumps({'cells': {}, 'output_filename': '成套柜正式BOM_V14'}, ensure_ascii=False), 'formal_items': formal_items if allowed else [], 'confirmed_count': counts.get('confirmed', 0), 'excluded_count': counts.get('excluded', 0), 'adjust_count': counts.get('reselect', 0), 'material_count': counts.get('material', 0), 'incomplete_count': counts.get('incomplete', 0), 'output_filename': '成套柜正式报价_V14.xlsx'}

def explicit_trip_requirements(value):
    curves = set()
    currents = set()
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).lower() in ('forbidden_models', 'excluded_models', 'prohibited_models', 'forbidden_accessories'):
                continue
            if key in ('trip_curve', 'tripping_curve', '脱扣曲线', '脱扣特性'):
                text = clean(child).upper()
                if text in ('B', 'C', 'D'):
                    curves.add(text)
            c, a = explicit_trip_requirements(child)
            curves.update(c)
            currents.update(a)
        return (curves, currents)
    if isinstance(value, (list, tuple)):
        for child in value:
            c, a = explicit_trip_requirements(child)
            curves.update(c)
            currents.update(a)
        return (curves, currents)
    text = clean(value).upper()
    text = re.sub('(?:不允许|不得|禁止|不能|不采用|不选用|不使用|排除|不含)[^;；。\\n,，]*', '', text)
    for match in re.finditer('(?<![A-Z0-9])([BCD])\\s*(\\d{1,3})(?:\\s*A)?(?![A-Z0-9])', text):
        curves.add(match.group(1))
        currents.add(int(match.group(2)))
    for match in re.finditer('(?:脱扣(?:特性|曲线)|TRIP_CURVE|TRIPPING_CURVE)\\s*[:：=为]?\\s*([BCD])(?![A-Z0-9/／])|(?<![A-Z0-9/／])([BCD])\\s*型?\\s*脱扣', text):
        curves.add(next((x for x in match.groups() if x)))
    return (curves, currents)

def trip_mismatch(requirement, product):
    wanted_curves, wanted_currents = explicit_trip_requirements(requirement)
    actual_curves, actual_currents = explicit_trip_requirements(product)
    if len(wanted_curves) > 1 or len(wanted_currents) > 1:
        return '需求中的脱扣特性或对应电流存在冲突，请核实原始资料，不能直接采用'
    if wanted_curves:
        if len(actual_curves) != 1:
            return '产品记录或确认型号未唯一证实所要求的脱扣特性：' + '/'.join(sorted(wanted_curves))
        if wanted_curves != actual_curves:
            return '脱扣特性不一致：要求' + '/'.join(sorted(wanted_curves)) + '型，当前为' + '/'.join(sorted(actual_curves)) + '型；请更正型号及对应物料编码'
    if wanted_currents and actual_currents and (wanted_currents != actual_currents):
        return '脱扣型号额定电流不一致：要求%sA，当前%sA' % (sorted(wanted_currents), sorted(actual_currents))
    return ''

def main(normalized_json):
    try:
        payload = load_json(normalized_json)
        if payload.get('validation_error'):
            return result('INCOMPLETE', clean(payload['validation_error']), counts={'incomplete': 1})
        if clean(payload.get('form_type')) != 'BOM_CONFIRMATION':
            return result('WRONG_FORM', '上传的不是BOM人工确认表。若这是选型前问题确认表，请改用“提交问题确认”入口。', counts={'incomplete': 1})
        rows = payload.get('rows') if isinstance(payload, dict) else None
        if not isinstance(rows, list) or not rows:
            raise ValueError('没有有效BOM行')
        if len(rows) > 120:
            raise ValueError('确认表超过本版每批120项的验证范围，请按柜号或回路分批提交；本次不会仅处理部分行')
    except Exception as exc:
        return result('INCOMPLETE', '确认表解析失败：%s。请上传本系统生成的.xlsx确认表。' % clean(exc), counts={'incomplete': 1})
    formal_items, issues = ([], [])
    confirmed = excluded = reselect = material = incomplete = 0
    for index, raw in enumerate(rows, 1):
        if not isinstance(raw, dict):
            incomplete += 1
            issues.append({'序号': str(index), '元器件名称': '未识别行', 'normalized_action': 'NEED_CLARIFICATION', 'issue_reason': '行格式无效'})
            continue
        row = {key: clean(raw.get(key)) for key in EXPECTED_HEADERS}
        row['序号'] = row['序号'] or str(index)
        row['normalized_action'] = clean(raw.get('normalized_action')).upper()
        row['action_reason'] = clean(raw.get('action_reason'))
        confidence = number(raw.get('action_confidence'), 0.0)
        name = row['元器件名称']
        action = row['normalized_action']
        if action not in ACTIONS:
            action = 'NEED_CLARIFICATION'
            row['normalized_action'] = action
            row['issue_reason'] = 'AI未返回有效标准动作'
        if confidence < CONFIDENCE_LIMIT and action not in {'PENDING', 'NEED_CLARIFICATION'}:
            action = 'NEED_CLARIFICATION'
            row['normalized_action'] = action
            row['issue_reason'] = '意见理解置信度%.2f，低于%.2f，请写得更明确' % (confidence, CONFIDENCE_LIMIT)
        if action == 'EXCLUDE':
            excluded += 1
            continue
        if action in {'PENDING', 'NEED_CLARIFICATION'}:
            incomplete += 1
            row['issue_reason'] = row.get('issue_reason') or row['action_reason'] or '意见尚未明确，暂不进入报价'
            issues.append(row)
            continue
        if action == 'RETURN_MATERIAL':
            material += 1
            row['issue_reason'] = row['action_reason'] or row['修改意见'] or '需要补充资料'
            issues.append(row)
            continue
        if action == 'RESELECT':
            reselect += 1
            row['issue_reason'] = row['action_reason'] or row['修改意见'] or '需要重新选型'
            issues.append(row)
            continue
        model = row['推荐型号']
        code = row['物料编码']
        qty_text = row['数量']
        if action == 'MODIFIED_CONFIRM':
            model = clean(raw.get('final_model_spec')) or model
            code = clean(raw.get('final_material_code')) or code
            qty_text = clean(raw.get('final_quantity')) or qty_text
        if '电压参数含义待确认' in row['关键技术参数']:
            ambiguous = re.search('电压参数含义待确认：([0-9]+(?:[.][0-9]+)?)V（[^）]*）', row['关键技术参数'])
            note = row['修改意见'] + ' ' + row['工程师确认']
            uc = re.search('(?:最大持续运行电压|持续运行电压|最大持续工作电压|Uc)\\s*[:：=为]?\\s*([0-9]+(?:[.][0-9]+)?)\\s*V', note, re.I)
            if ambiguous and uc and (float(ambiguous.group(1)) == float(uc.group(1))):
                row['关键技术参数'] = row['关键技术参数'].replace(ambiguous.group(0), '最大持续运行电压Uc：' + uc.group(1) + 'V')
            else:
                incomplete += 1
                row['issue_reason'] = 'SPD电压含义未确认；请在修改意见明确Uc及数值，例如Uc=385V。若原意为额定工作电压或数值变化，请补充技术要求后重新选型。单写采用不能放行。'
                issues.append(row)
                continue
        trip_error = trip_mismatch(row['关键技术参数'], model)
        if trip_error:
            incomplete += 1
            row['issue_reason'] = trip_error + '。“采用”仅表示确认推荐，不能覆盖原始技术要求。'
            issues.append(row)
            continue
        qty, unit = parse_quantity(qty_text)
        missing = []
        if not model:
            missing.append('最终型号')
        if not code:
            missing.append('最终物料编码')
        if qty is None:
            missing.append('有效数量')
        if missing:
            incomplete += 1
            row['issue_reason'] = '已表达确认，但仍缺少：' + '、'.join(missing)
            issues.append(row)
            continue
        confirmed += 1
        formal_items.append({'line_no': len(formal_items) + 1, 'source_request_id': clean(raw.get('original_request_id')), 'project_cabinet_quantity': raw.get('project_cabinet_quantity'), 'position': row['回路/位号'], 'material_code': code, 'material_name': name, 'model_spec': model, 'key_technical_parameters': row['关键技术参数'], 'scheme_group_id': re.search('方案组：([^；;\\n]+)', row['关键技术参数']).group(1).strip() if re.search('方案组：([^；;\\n]+)', row['关键技术参数']) else '', 'quantity_basis': 'PER_CABINET' if '计量口径：单柜' in row['关键技术参数'] else 'PROJECT', 'quantity': qty, 'unit': unit, 'confirmation_note': row['修改意见'] or row['工程师确认'] or '工程师确认', 'confirmation_action': action, 'requirements_json': clean(raw.get('original_requirements_json') or '{}'), 'pricing_status': 'WAITING_PRICE_LOOKUP'})
    seen = set()
    for item in formal_items:
        key = (clean(item.get('scheme_group_id')), clean(item.get('position')), clean(item.get('material_code')), clean(item.get('model_spec')))
        if key in seen:
            incomplete += 1
            issues.append({'序号': str(item.get('line_no')), '回路/位号': item.get('position'), '元器件名称': item.get('material_name'), 'normalized_action': 'NEED_CLARIFICATION', 'issue_reason': '存在相同回路、编码和型号的重复确认行；请先合并或说明不同位置'})
        seen.add(key)
    counts = {'confirmed': confirmed, 'excluded': excluded, 'reselect': reselect, 'material': material, 'incomplete': incomplete}
    markdown = ['| 序号 | 回路/位号 | 元器件名称 | 标准动作 | 需处理内容 |', '|---:|---|---|---|---|']
    markdown.extend((issue_line(row) for row in issues))
    issue_markdown = '\n'.join(markdown) if issues else ''
    if incomplete:
        return result('INCOMPLETE', '有%d项意见尚未明确或确认字段不完整；这些项目不会进入报价。' % incomplete, issue_markdown, counts=counts)
    if material:
        return result('MATERIAL_REQUIRED', '有%d项需要补充协议、图纸或参数后再选型。' % material, issue_markdown, counts=counts)
    if reselect:
        return result('RESELECT_REQUIRED', '有%d项要求重新选型；请补充要求后执行“重新选型”。' % reselect, issue_markdown, counts=counts)
    if formal_items:
        return result('APPROVED', '已确认%d项、排除%d项。仅确认项进入产品复核和价格查询。' % (confirmed, excluded), formal_items=formal_items, counts=counts)
    if excluded:
        return result('NO_PRICING_ITEMS', '全部%d项均明确不配置，无需生成报价。' % excluded, counts=counts)
    return result('INCOMPLETE', '没有可进入正式BOM的有效项目。', counts={**counts, 'incomplete': max(1, incomplete)})
