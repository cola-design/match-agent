import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_CONTEXT_MAX = 5000000

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
import base64
import gzip
import json
import re
HEADERS = ['序号', '关联位置', '问题类型', '问题说明', '对后续的影响', '工程师确认/补充']

def safe(value):
    text = '' if value is None else str(value).strip()
    return "'" + text if text.startswith(('=', '+', '-', '@')) else text

def display_problem(value):
    text = '' if value is None else str(value)
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    return re.sub('[ \\t]*[；;][ \\t]*', '\n', text)

def column_name(number):
    result = ''
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result

def parse_rows(markdown):
    rows, active = ([], False)
    for line in str(markdown or '').splitlines():
        heading = re.match('^\\s*##\\s+(.+?)\\s*$', line)
        if heading:
            active = heading.group(1).strip() == '资料问题确认'
            continue
        if not active or not line.strip().startswith('|'):
            continue
        fields = [part.replace('\\|', '|').strip() for part in re.split('(?<!\\\\)\\|', line.strip().strip('|'))]
        if fields == HEADERS or all((re.fullmatch(':?-{3,}:?', x.replace(' ', '')) for x in fields)):
            continue
        if len(fields) == len(HEADERS):
            rows.append(fields)
    if len(rows) > 120:
        raise CapacityError('确认单超过120行，请分批，不会仅保留前120行')
    return rows

def _original_main(markdown: str, selection_request_json: str) -> dict:
    rows = parse_rows(markdown)
    if not rows:
        raise ValueError('没有可写入问题确认单的问题行')
    raw = gzip.compress((selection_request_json or '{}').encode('utf-8'), compresslevel=9, mtime=0)
    payload_b64 = base64.b64encode(raw).decode('ascii')
    chunks = [payload_b64[i:i + 24000] for i in range(0, len(payload_b64), 24000)]
    if len(chunks) > 25:
        raise ValueError('选型上下文过大，超过问题确认Excel的25段容量')
    cells = {}
    cells['资料问题确认!A130'] = 'FORM_TYPE'
    cells['资料问题确认!B130'] = 'CLARIFICATION_CONFIRMATION'
    cells['资料问题确认!A131'] = 'SCHEMA_VERSION'
    cells['资料问题确认!B131'] = 'clarification-confirmation-v14.4'
    for index, chunk in enumerate(chunks, 1):
        cells['资料问题确认!A%d' % (131 + index)] = 'PAYLOAD_CHUNK_%03d' % index
        cells['资料问题确认!B%d' % (131 + index)] = 'PAYLOAD_B64_PART_%03d:%s' % (index, chunk)
    for row_number, row in enumerate(rows, 5):
        for column, value in enumerate(row, 1):
            if column in (4, 5):
                value = display_problem(value)
            if column == 6:
                value = '【请工程师填写】'
            cells['资料问题确认!%s%d' % (column_name(column), row_number)] = safe(value)
    return {'payload_json': json.dumps({'cells': cells, 'output_filename': '选型前问题确认单_V14.8.1_动态框线版式'}, ensure_ascii=False), 'summary': '问题确认%d行，已写入文件类型和选型上下文' % len(rows)}

def main(markdown, selection_request_json):
    try:
        decoded = wire_loads(selection_request_json)
        if isinstance(decoded, dict) and decoded.get('capacity_blocked'):
            raise CapacityError(decoded.get('capacity_message') or '本次容量超限，请分批重新提交原始资料')
        context = plain_json(decoded)
        out = _original_main(markdown, context)
        if len(out['payload_json'].encode('utf-8')) > 65000:
            raise CapacityError('确认单内容超过65KB插件请求预算，请分批。本次未生成可提交的完整确认单。')
        return out
    except CapacityError as exc:
        message = str(exc)
        sheet = '资料问题确认'
        cells = {sheet + '!A1': '本次输出容量超限，未生成完整确认单', sheet + '!A2': message, sheet + '!A130': 'FORM_TYPE', sheet + '!B130': 'CAPACITY_BLOCKED', '系统数据!A2': 'FORM_TYPE', '系统数据!B2': 'CAPACITY_BLOCKED'}
        return {'payload_json': plain_json({'cells': cells, 'output_filename': '容量超限提示_请分批重新提交'}), 'summary': message}

"""Stdlib-only XLSX geometry, embedded in Dify code nodes. No openpyxl in the sandbox."""
import base64 as _lx_b64
import io as _lx_io
import json as _lx_json
import math as _lx_math
import re as _lx_re
import unicodedata as _lx_unicode
import zipfile as _lx_zip
from xml.etree import ElementTree as _lx_et

_LX_NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
_LX_REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
_lx_et.register_namespace('',_LX_NS)
_lx_et.register_namespace('r',_LX_REL)


class LayoutCapacityError(ValueError):
    pass


def _lx_tag(name):return '{'+_LX_NS+'}'+name


def _lx_insert_before(parent,element,following):
    position=next((i for i,child in enumerate(parent) if child.tag in {_lx_tag(name) for name in following}),len(parent))
    parent.insert(position,element)


def _lx_col(number):
    result=''
    while number:
        number,remainder=divmod(number-1,26);result=chr(65+remainder)+result
    return result


def _lx_col_number(value):
    result=0
    for char in value:result=result*26+ord(char)-64
    return result


def _lx_lines(value,width):
    if value is None:return 1
    text=str(value).replace('\r\n','\n').replace('\r','\n')
    available=max(5,width-2)
    total=0
    for line in text.split('\n'):
        weight=sum(2.1 if _lx_unicode.east_asian_width(c) in ('W','F') else 1 for c in line)
        total+=max(1,_lx_math.ceil(weight/available))
    return total


def layout_template(template_base64,payload_json,spec):
    """Return a styled EMPTY template; the existing Excel plugin fills unchanged cell values."""
    payload=_lx_json.loads(payload_json)
    cells=payload.get('cells',{})
    if not isinstance(cells,dict):raise ValueError('Excel cells必须是对象')
    buffer=_lx_io.BytesIO()
    with _lx_zip.ZipFile(_lx_io.BytesIO(_lx_b64.b64decode(template_base64))) as original:
        files={name:original.read(name) for name in original.namelist()}
    book=_lx_et.fromstring(files['xl/workbook.xml'])
    rels=_lx_et.fromstring(files['xl/_rels/workbook.xml.rels'])
    targets={r.attrib['Id']:r.attrib['Target'].lstrip('/') for r in rels}
    names=book.find(_lx_tag('definedNames'))
    if names is None:
        names=_lx_et.Element(_lx_tag('definedNames'));_lx_insert_before(book,names,('calcPr','oleSize','customWorkbookViews','pivotCaches','extLst'))
    for item in list(names):
        if item.get('name') in ('_xlnm.Print_Area','_xlnm.Print_Titles'):names.remove(item)
    for index,sheet in enumerate(book.find(_lx_tag('sheets'))):
        name=sheet.get('name');config=spec.get(name)
        if name=='系统数据':
            sheet.set('state','veryHidden');continue
        if not config:continue
        target=targets[sheet.get('{'+_LX_REL+'}id')]
        path=target if target.startswith('xl/') else 'xl/'+target
        root=_lx_et.fromstring(files[path]);data=root.find(_lx_tag('sheetData'))
        start=config['start'];columns=config['columns'];minimum=config.get('minimum',start-1)
        values={}
        metadata=set()
        for key,value in cells.items():
            if '!' not in key:continue
            prefix,coordinate=key.rsplit('!',1)
            if prefix.strip("'")!=name:continue
            match=_lx_re.fullmatch(r'([A-Z]+)(\d+)',coordinate)
            if not match:raise ValueError('Excel单元格地址无效')
            row=int(match.group(2))
            if row>=130 and name in ('BOM确认','资料问题确认'):
                metadata.add(row);continue
            values[coordinate]=value
        rows=[int(_lx_re.search(r'\d+$',key).group()) for key in values]
        last=max([minimum]+rows)
        if config.get('hide_if_empty') and last<start:
            sheet.set('state','hidden')
            continue
        if last-start+1>120 and name not in ('01 报价汇总',):
            raise LayoutCapacityError(name+'超过120行，请分批；没有输出截断表格')
        widths=config['widths']
        merged_widths={}
        merges=root.find(_lx_tag('mergeCells'))
        for merged in merges if merges is not None else []:
            hit=_lx_re.fullmatch(r'([A-Z]+)(\d+):([A-Z]+)(\d+)',merged.get('ref',''))
            if hit and hit.group(2)==hit.group(4):
                first=_lx_col_number(hit.group(1));end=_lx_col_number(hit.group(3))
                merged_widths[hit.group(1)+hit.group(2)]=sum(widths[first-1:end])
        for row in list(data):
            number=int(row.get('r','0'))
            if number>=130 and name in ('BOM确认','资料问题确认'):
                row.set('hidden','1');row.set('ht','1');row.set('customHeight','1');continue
            if number>last:
                data.remove(row);continue
            if number<start:continue
            height=max([config.get('min_height',34)]+[
                9+16*_lx_lines(values.get(_lx_col(col)+str(number)),merged_widths.get(_lx_col(col)+str(number),widths[col-1]))
                for col in range(1,columns+1)])
            if height>409:
                raise LayoutCapacityError(name+'第'+str(number)+'行文字过长，超过Excel单行显示上限；请精简重复说明或拆分需求，未输出会截断的表格')
            row.set('ht',str(height));row.set('customHeight','1')
        dimension=root.find(_lx_tag('dimension'))
        if dimension is not None:dimension.set('ref','A1:'+_lx_col(columns)+str(max(last,max(metadata) if metadata else last)))
        filters=root.find(_lx_tag('autoFilter'))
        if filters is not None:filters.set('ref','A'+str(start-1)+':'+_lx_col(columns)+str(max(start-1,last)))
        properties=root.find(_lx_tag('sheetPr'))
        if properties is None:properties=_lx_et.Element(_lx_tag('sheetPr'));root.insert(0,properties)
        setup_properties=properties.find(_lx_tag('pageSetUpPr'))
        if setup_properties is None:setup_properties=_lx_et.SubElement(properties,_lx_tag('pageSetUpPr'))
        setup_properties.set('fitToPage','1');setup_properties.set('autoPageBreaks','1')
        setup=root.find(_lx_tag('pageSetup'))
        if setup is None:
            setup=_lx_et.Element(_lx_tag('pageSetup'));_lx_insert_before(root,setup,('headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        setup.attrib.update(orientation=config.get('orientation','landscape'),paperSize=str(config.get('paper',8)),fitToWidth='1',fitToHeight='0')
        margins=root.find(_lx_tag('pageMargins'))
        if margins is None:
            margins=_lx_et.Element(_lx_tag('pageMargins'));_lx_insert_before(root,margins,('pageSetup','headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        margins.attrib.update(left='0.25',right='0.25',top='0.35',bottom='0.35',header='0.15',footer='0.15')
        escaped="'"+name.replace("'","''")+"'"
        area=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Area','localSheetId':str(index)})
        area.text=escaped+'!$A$1:$'+_lx_col(columns)+'$'+str(last)
        repeat=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Titles','localSheetId':str(index)})
        repeat.text=escaped+'!$1:$'+str(config.get('header_end',start-1))
        files[path]=_lx_et.tostring(root,encoding='utf-8',xml_declaration=True)
    files['xl/workbook.xml']=_lx_et.tostring(book,encoding='utf-8',xml_declaration=True)
    with _lx_zip.ZipFile(buffer,'w',compression=_lx_zip.ZIP_DEFLATED) as output:
        for name,content in files.items():output.writestr(name,content)
    encoded=_lx_b64.b64encode(buffer.getvalue()).decode('ascii')
    if len(encoded)>55000:raise LayoutCapacityError('动态Excel模板超过传递预算，请分批')
    return encoded

_LAYOUT_TEMPLATE='UEsDBBQAAAAIAPEhXF1Gx01IlQAAAM0AAAAQAAAAZG9jUHJvcHMvYXBwLnhtbE3PTQvCMAwG4L9SdreZih6kDkQ9ip68zy51hbYpbYT67+0EP255ecgboi6JIia2mEXxLuRtMzLHDUDWI/o+y8qhiqHke64x3YGMsRoPpB8eA8OibdeAhTEMOMzit7Dp1C5GZ3XPlkJ3sjpRJsPiWDQ6sScfq9wcChDneiU+ixNLOZcrBf+LU8sVU57mym/8ZAW/B7oXUEsDBBQAAAAIAPEhXF35FXQY7wAAACsCAAARAAAAZG9jUHJvcHMvY29yZS54bWzNklFLwzAQx7+K5L29pJ1DQpcXxScFwYHiW0huW1jThOSk3be3rVuH6AfwMXf//O53cI2J0oSELylETOQw3wy+7bI0ccMORFECZHNAr3M5JrqxuQvJaxqfaQ9Rm6PeI1Scr8EjaatJwwQs4kJkqrFGmoSaQjrjrVnw8TO1M8wawBY9dpRBlAKYmibG09A2cAVMMMLk83cB7UKcq39i5w6wc3LIbkn1fV/29ZwbdxDw/vz0Oq9buC6T7gyOv7KTdIq4YZfJb/X9w/aRqYpX60Lworrb8pUUt7JefUyuP/yuwj5Yt3P/2PgiqBr4dRfqC1BLAwQUAAAACADxIVxd+lwBWfwCAADaDQAAEwAAAHhsL3RoZW1lL3RoZW1lMS54bWy1V9lS2zAU/RWP34u8LxkCw5K0D+20U/gBxZaXIsseSyHw95UVL7IdhbAkzIAlnXPPse7VVbi8fimw9oxqmpdkqZsXhq4hEpVxTtKlvmXJt0C/vrqEC5ahAmkEFmip32WQff/zqGucS+gCLvWMsWoBAI04CtKLskKEryVlXUDGh3UK4hrueMwCA8swPFDAnOh93BXmvwijzUSE64fogFizFj+ZzR/6Su9wrT1DvNR50LjcPaIXpmsYUsYXlrohProGri5Bz8JMQZaIa/HpiC0jfrIEsU43PdNYWYFjDgrWXmEOXAXNzxBRIGAU8dc1Z2DT9YzA6sASav94IHrom/aEICnYc4XQu7WcMcEeCM78Rdfh6t4dE5yB4M4IN4Z1G9pjgjsQvBnBWd341mpMEKgM5+RpDvf8IPA6eI9JSvzjID70PMO/7/ADDEiltg9A2KjwfidJHiFRdwX8V9ZrDhBZhiwnGnutUAKjpkAhzjd1rv3M04wJHbhA8A1ARI8CwESzyMmbBo5IHxHt5QYFIG+G2JqCKY9kkmP8wF4x+kmFOVriPF7zSTEQrD4VVcYfO8ERMK3h8EzbUCnVqpLyEtSVsUQHyQnbz3l+d+r5Jm2LX2XcFr1pDAsUsmHBcKU+0SuIUUplD66IcKIP31b4GOSmPuwTfZjGe4wE5ruNhEeNACk9/BhpsLklXKdttzSCGMVNwtoAo7R+SYpDR/VG1me39oQU0wzGqItrqJyois00vjDJkhU/OOwkDBVGrONGPpxkMG8HmIxH2q7R97u3+1CzqGrK7iHN9jix1N+vRJIJeZWfX8ZqduZ8MmC6hyhJUMQUM8OQr7VRDi5/Ft0Myi1D9UMW77QN3tZ/IS8K1zf5nmtxTlmXAD6oh/KZf78Y5iGuMth28tGh3ePFc68pmRV2ptbBoZ3apOsvua7eZk26lqrd+uqTeIb7MZTuJal/hIr+oe6p7qmd7F3XpuxDtqdstLbCnn2mRuupBM/YUKclC6SvY2I0+Qeqm7n6D1BLAwQUAAAACADxIVxdBX/4F3gOAADObAAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbLWdW3Pbxh1HvwqH7WTah4bYGy62rBl7V9t4Jo49di/TpwwjQTanFKlScBz30xdYEFxIBs4yD30xCRws8N/FEseJgR8uvuwP/374VNfN4re77e7hxfJT09w/W60erj/Vd+uH7/f39a4lt/vD3bppFw8fVw/3h3p9ExrdbVcyy/LV3XqzW15ehHXvDpcX+8/NdrOr3x0WD5/v7taHr6/q7f7Li6VYDivebz5+aroVq8uL+/XH+kPd/P3+3aFdWp32crO5q3cPm/1ucahvXyxfimdeqNAibPKPTf3lYfR98fBp/+Wvh83Nj+2h255ky0XXu1/2+393+PVNt6o72q5efP1wv920x9fLRbO//7G+bWy93bbHMMvF+rrZ/Fq/azd7sfxl3zT7u463lTfrpl11e9j/t96FKupt3W7b1nf/zcb9To477br9n2MflqcudkWNvw998WGs27H7Zf1Q2/32n5ub5tOLZblc3NS368/b5v3+yw/1cfxMt7/r/fYh/Ln40m9bLBfXnx/aYo5tuwKar9u2xlwtF3ebXVh1t/7teAZGTaVMt5XHtvJJW1Gm26pjW/WkbZ6n2+pjW/2krdbptubY1jxta9Jt82PbPJy8frTDqXLrZn15cdh/WRxCw+6UqFMxp5PU7jHsrT1wt+HL44p2tFq62XU/lQ/NocWbdsfN5Xd/kEZk+nn7KctCdJ+5Kcv2MzeqkO2nystCBa5F4CLLq7Be5KFdnmVhuVRl2L7KwnqVlSrrPk2hy9BOKfX8YtW03eqOvbo+lviqL1GECruf9onYWeJmydUs8VNk1Q7oaVTlcVRlclRlv6KaHVWlM9GNWtvnKoxSlsm8HwVZ9KNiulER7bBXYXRlEUZLah0+lTT9qIm8W5bGGBmWdS777fKiP1tSh7Mlq269bgdfTx03EyYs60yF4+tKhPZZmZm+jioct5RhFnxzNk0pQz25CPv7tj6tw/a6DHW0kyW0lzIvw/ZV3vfryIfloW6VV5Xo6wnj1n6GWSbbBv2sU2Woux2IwI0QWd+uCP1qZ2tx6sfULJOzs2yWuFlyNUv8FHk0y9RxlpXJWabCiiKbn2WmVP3o6ONoKxFGUxglny/8IvxchelPhDL9wPYTbjiRw8/0OKHaiRkm4jAhThOvnc+yb5c9uiy0R+pKKKWc2jx1VWibidE0EFUVTrcy7Q6Oy21HXr19s/i2bTuH+2OWwoRRqKp+J7NzQM3OgVniZsnVLPFT5NEc0Mc5kCXngO7ngJi/fmuZFf0cqMxkr9O7yMowgEqWx5Onsn45l3Jqlza5y2/Ouyj761WwyMQu3e/f5aNL0sQur9IdV0aHH0U7gcr+R1CFq3amwtWpvRirMMlF0Tpu4hD+jNNzvOAKqVV/Ae61+mgyr55ekR8f69HcMae5YfqDy29n4Kt5ZOeROyI1MdnnkT8iPT/d81PJ+XzJ88jOI5fPlzyPfJ4suTiVXMyXPI/sPHLFfMnzyBfJkstTyeV8yfPIziNXzpc8j3yZLLk6lVzNlzyP7Dxy1XzJ88hXyZJFFv9unc0XDcwCcwObqhuYHxhVLmLlAiqfZxaYG9hk5fPMD4wql7FyCZXPMwvMDWyy8nnmB0aVj/5LTEHl88wCcwObrHye+YFR5TpWrqHyeWaBuYFNVj7P/MCo8mhIAYoEZoE5AZYE5kXakyKKUoApgVlgToAsgXmR1qWIvhQgTGAWmBPgTGBepK0pojYFeBOYBeYEqBOYF2l5imhPAfoEZoE5AQYF5kXaoTI6VIJDgVlgToJDgXmZdqiMDpXgUGAWmJPgUGBeph0qo0MlOBSYBeYGNlk5OHRgVPno/7uBQ4FZYE6CQ4F5mXaojA6V4FBgFpiT4FBgXqYdKqNDJTgUmAXmJDgUmJdph8roUAkOBWaBOQkOBeZl2qEyOlSCQ4FZYE6CQ4F5mXaojA6V4FBgFpiT4FBgXqYdKqNDJTgUmAXmJDgUmJdph6roUAUOBWaBOQUOBeZV2qEqOlSBQ4FZYE6BQ4F5lXaoig5V4FBgFpgb2GTl4NCBUeWjf1UAhwKzwJwChwLzKu1QFR2qwKHALDCnwKHAvEo7VEWHKnAoMAvMKXAoMK/SDlXRoQocCswCcwocCsyrtENVdKgChwKzwJwChwLzKu1QFR2qwKHALDCnwKHAvEo7VEWHKnAoMAvMKXAoMK/SDtXRoRocCswCcxocCszrtEN1dKgGhwKzwJwGhwLzOu1QHR2qwaHALDA3sMnKwaEDo8pH/yoLDgVmgTkNDgXmddqhOjpUg0OBWWBOg0OBeZ12qI4O1eBQYBaY0+BQYF6nHaqjQzU4FJgF5jQ4FJjXaYfq6FANDgVmgTkNDgXmddqhOjpUg0OBWWBOg0OBeZ12qI4O1eBQYBaY0+BQYF6nHWqiQw04FJgF5gw4FJg3aYea6FADDgVmgTkDDgXmTdqhJjrUgEOBWWBuYJOVg0MHRpVHhxpwKDALzBlwKDBv0g410aEGHArMAnMGHArMm7RDzeiOIbpliO4ZopuG6K4hum0o7VATHWrAocAsMGfAocC8STvURIcacCgwC8wZcCgwb9IONdGhBhwKzAJzBhwKzJu0Q010qAGHArPAnAGHAvMm7dA8OjQHhwKzwFwODgXm87RD8+jQHBwKzAJzOTgUmM/TDs2jQ3NwKDALzA1ssnJw6MCo8ujQHBwKzAJzOTgUmM/TDs2jQ3NwKDALzOXgUGA+Tzs0jw7NwaHALDCXg0OB+Tzt0Hx08y3dfUu339L9t3QDLt2Bm3ZoHh2ag0OBWWAuB4cC83naoXl0aA4OBWaBuRwcCsznaYfm0aE5OBSYBeZycCgwn6cdWkSHFuBQYBaYK8ChwHyRdmgRHVqAQ4FZYK4AhwLzRdqhRXRoAQ4FZoG5gU1WDg4dGFUeHVqAQ4FZYK4AhwLzRdqhRXRoAQ4FZoG5AhwKzBdphxbRoQU4FJgF5gpwKDBfpB1aRIcW4FBgFpgrwKHAfJF2aDF6joUeZKEnWehRFnqWhR5mSTu0iA4twKHALDBXgEOB+SLt0CI6tACHArPAXAEOBeaLtEPL6NASHArMAnMlOBSYL9MOLaNDS3AoMAvMleBQYL5MO7SMDi3BocAsMDewycrBoQOjyqNDS3AoMAvMleBQYL5MO7SMDi3BocAsMFeCQ4H5Mu3QMjq0BIcCs8BcCQ4F5su0Q8vo0BIcCswCcyU4FJgv0w4to0NLcCgwC8yV4FBgvkw7tBw9EkrPhNJDofRUKD0WSs+Fph1aRoeW4FBgFpgrwaHAfJl2aBUdWoFDgVlgrgKHAvNV2qFVdGgFDgVmgbkKHArMV2mHVtGhFTgUmAXmBjZZOTh0YFR5dGgFDgVmgbkKHArMV2mHVtGhFTgUmAXmKnAoMF+lHVpFh1bgUGAWmKvAocB8lXZoFR1agUOBWWCuAocC81XaoVV0aAUOBWaBuQocCsxXaYdW0aEVOBSYBeYqcCgwX6UdWo3SFShegfIVKGCBEhYoYuGcjIVxyAKmLGDMAuYsYNACJi2cEbWQjbIWMgpbAGgJuhOc7gAFLmRpo4psFLmQgVMJWoLuBKc7AF49QezAKHkhA7UStATdCU53APR6gtiBUQBDBoYlaAm6E5zuAFj2BLEDoxyGjIIYAFqC7gSnO0BhDFnatiIbxTFklMcA0BJ0JzjdAcpkyNLSFdkolSGjWAaAlqA7wekOUDRDlnavyEbhDBmlMwC0BN0JTneAEhqytIJFNspoyCikAaAl6E5wugMU1JCdYeJx3BHmHWHgESYeYeQRZh6dFXo0Tj3C2CPMPcLgI0w+wuijM0w8Dj/C9COMP8L8IwxAwgSkcyKQxhlIGIKEKUgYg4Q5SBiEdE4S0jgKCbOQMAwJ05AwDgnzkM4JRBonImEkEmYiYSgSpiJhLNI5uUjjYCRMRsJoJMxGwnAkTEc6Jx5pnI+EAUmYkIQRSZiRhCFJ56QkjWOSMCcJg5IwKQmjkjAr6ZywpHFaEsYlYV4SBiZhYhJGJp2RmSRGoUmCUpMIWoJOUHASQS/OiE4So+wkQeFJBC1BJyg/iaAXZyQoCTmOISQTU4gSQScoRomgF2cEKYlRkpKgKCWClqATlKZE0Isz8pTEKFBJUKISQUvQCQpVIujFGbFKYpSrJIYwIzPZgXloCTqCVwT9DHzSgZGJh0yj6Q7MQ0vQEbwi6Gfgkw6MTDxEG013YB5ago7gFUE/A590YGTiIeFougPz0BJ0BK8I+hn4pAMjEw9BR9MdmIeWoCN4RdDPwCeZriMTD3lHedj+2wRw//b9m5//9q93V5Nvvki1tj++fP/av7Yv//b67U8/27c/+dfv34SFqVT2J7t7MiYArwj6GfhkTEZyH5KU5nr1wf5w9eblz/+4ev9huievkru43q4Pm9vN9bp7J85frve72033Jptu4Vehv9fTwyNoeObhFUE/A/vhWY3e3bL+3Oz9ZtvUh+NLhvSzYL3V5cVdffgY3uDzsLjef9413VsiRmuP26tn/vHWx/XymZdT67uXGIXXyMTdt0XvdzebbqDW2/7tP81m9/H0ziDz7Ooo2dv3n7f1ovl6X79Y1r/dH+qH7vVIy8X9YbM/bJqv4V0FN7/dDu866l7b9Hm7vvzx6qc//dGZP3/3sXmeXayG1e2YhD12X6YqSBTmzTN/dmHyVJj4vxf28vcUpk6FyVFhf3xpvts2z7u6lsvfU1i7413z9r4DD4tP7TH+u981662td+0cq29Gr7x6sz583LQbbevbdm5l37eaOfQvnAjfm/19+NZe9PoXSw1Ln+r1TX3oltrSb/f7Zlho99szH1ZeXuxvbn4IK9pyR9/br8ctvlvf3T+34c9qcXpFSVh+twhvdZDV88VqEd6AoKsj+umEwm6Ho9W/1rvT4cYL3fdho9V4ob0+PDSnJo+WwsKp0eOlx51cnV5hdvk/UEsDBBQAAAAIAPEhXF1pi9X3WwMAALoMAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDIueG1shZdhb6IwHMa/CuGSe3eDFkHY1MR5MzOZm9HdLvdq6bAoGVCvdHO7T39tQWrvan2z0j7//vpQHlgd7Al9rbcYM+ejLKp66G4Z2116Xp1ucYnqC7LDFVcyQkvEeJduvHpHMVrLSWXhQd+PvBLllTsayLEFHQ3IGyvyCi+oU7+VJaKf17gg+6EL3MPAMt9smRjwRoMd2uAVZj92C8p7XkdZ5yWu6pxUDsXZ0B2Dy+vAFxNkxVOO9/XRtSNu5YWQV9GZrYeu7wp0hZ3P1a7I5WIOI7s7nLEJLgoOhK6DUpa/4wUvG7ovhDFSCp3bZIjxoYySP7iSa+IC81puppnSIsQd/W7tuZ17YeH4+uBzKreRb8sLqvGEFD/zNdsO3dh11jhDbwVbkv0tbrcmFLyUFLX86+ybWhi5TvpWc6PtZOGAfRbcbBS4TplXcqhEH+3uHs3tx+fnwnYulHfTLC+9f0cMjQaU7B0qJwqP/HG0wM41J0oaX1gUjpuBMOR7P3TzSsRixSiXcw5mo69fApAk4RVvYa+f8BYGQRyIth/2g6uBx7gNUeulLfL6LBKGSRQLRNgLe7yNQhiLfhDAUI4DEPmiTZJmqRD4bV0CRV0YB0DWcU+i9XsRlHUJCFpe8o81j+9Mtz2wu33Y7Ac84XX6sJw/P/5a3Jju88zcyd14OZvOJuPH2cP98+ThfjpbzmXH4kw9mMBOX01ub+bj56eb5eo/YmPvDCAtEM2zPEXipfmWkirLRfhF5x30LnoWk73OZO94DfGJUcsbJQ0TdpjwNMYoaZiow0SnMUZJw/Q7TP80xihpmLjDxKcxRknDJB0mOY0xShoG+OpF90+DzJpOAooELCSjppPU2weghWTUdNLRZyywkIyaTlKRBpZMmzWdpFINLLE2azpJBRtYkm3WdJLKNrCE26zpJBVvYMm3WdNJKuHAEnGzpn/MVcahJeNmTSepjENLxs2aTjr6D2PJuFnTSSrj0JJxs6aTVMahJeNmTSepjENLxs2aTlIZh5aMmzWdpDIOLRk3azpJZRxaMm7WdJLKOLRk3KzpxwKV8cCScbPWkLyjU6I40c8R3eRV7RT8PM0P4xd8Y2hzRpTX/CQur/gzbM7dh96W/7jAVPR45DJC2KEjzqPdz5XRX1BLAwQUAAAACADxIVxd6/S02rgEAADqOwAADQAAAHhsL3N0eWxlcy54bWztW9uOm0gQ/RXEB4SbwbDCSB4maPchq5WSh+wjY7dtJG6BnoknX7/dgAcYU14w3aG1G48SA9V1+lTV6cuM226JX2P0+YQQls5JnJYb+YRx/puilLsTSsLyQ5ajlFgOWZGEmNwWR6XMCxTuS+qUxIquqpaShFEqe276nAQJLqVd9pzijazKiucesrR9ohly/YS0DRMkvYTxRvbDIo5wRhuXP+pHmkbvlLrl+/afol2RldkBS3+Hv6OItnxq3Oj1LouzQiqOTxs5aF496PU06B6crhrmatuDU2fAmWvr0dbnwE0JfGJOZ/vNycx2ZW1VixncUN0+mIwrNwtwKOCpgPd7AjJS1QEZ2R3o6q0kXURx/DbILbl+4Ll5iDEq0oDcVD7VwyuT1Fx/ec3RRj4W4aumN/zHOJRZHO1pl0e/m1DNNlarirnScZ0J+nEb6MGWMWhgBmvmoLpumrYKglZvpHBPWbFHxVvpVvLlkXJ14bkxIpqpVoyNjE/VjN/XsPqg+nWftKnnFtHxNNajauu5OMtHOpCWlBrGWTLSo25cXdQBjQtMVX370fpojg+s5zEmsJ7DqMB6HleBNRekwDsUx58pyNdDuwoTqPNBqlfrP/Z0oZboQL5cEmk0lzUMvakXgS5ajd2BXa/vwCU3efSS4YdnEkJa3X97zjD6q0CH6Fzdnw91Q+Ue1ozRdfbctaXQwzyPX7dxdEwTVMtidIeeG178pFNWRD9Ib3RxoKOjEsr5IBQl6QUVONrR+x1pgIp/JQnVnI2ioBRwRxet5hwpzaq5wX4k6kuhM0rw9yLMv6AzvqwFtzLJn811uUXndyXHSYwhbbKZMaB8cEcXSJs8pyLR+THT5or9zGYshb6ANvmzmafNJfjx0SabmQ3KB3d0gbQpyry5BD9m2jTZz2yrpdAX0CZ/Nt3a31PrZRjy0Seb2Q3KCHd0gfTJZ25iqU++DJnpU11+DoLYLKM4/rnhUzt22ZrHzxQ8fxA/UfJnCZ4/iJ8o+dMFzx/E7/+TP/brGf+csue8FlynED9RdNrZd3H49O8GOq/o7w2Y+baf0+dMkwPmv5MQa98g1i5BrD2BWLlppYyznNmvXhx/edcFXgh/7qkGkLNY+yIWfyXlv8NgzVjTua9Ct7UweTjbi37mOJmus+if+ifTXXo6myOH3pAzfhFmIggNWj5F5atx58uD3U/dKSnNadjOkdvegdu3pxI9ib+R/6TfqIl726H2eC1B2Z/bk7X0WzN72snVWXDPfXp3mNwI7OARPvddwYzFImg+fDC9gzX6hLj1sPadSSfEW4+RJ8Rbh7EnxFuP64PUVXj0/7LxIu9RukdntPebWwLjdw9m1y+K997Sfpvi2gL51LZhC7VB/UAMIJ/aC+rnvxSPDcZT2yBu9qDFBn1s0Kf2GrL41Q/Uz7CPQ17DkTqOYVgWlFHfH2TgQ3mzLPpvGA3iRj2gfmhP03INVxtWyG0dQDW9pRAoUliJUKRwrqllOG/Uw3GGqw31Qz2gKkDaof0P90M1NexjGLSqEDdoBMMWx4EsVIvDGrUsIDsW/RmuDzRKDMNxhi3UNszAMCALHY2wBWJAOUAWw6hWrXfrkXJZp5T2273eP1BLAwQUAAAACADxIVxdl4q7HMAAAAATAgAACwAAAF9yZWxzLy5yZWxznZK5bsMwDEB/xdCeMAfQIYgzZfEWBPkBVqIP2BIFikWdv6/apXGQCxl5PTwS3B5pQO04pLaLqRj9EFJpWtW4AUi2JY9pzpFCrtQsHjWH0kBE22NDsFosPkAuGWa3vWQWp3OkV4hc152lPdsvT0FvgK86THFCaUhLMw7wzdJ/MvfzDDVF5UojlVsaeNPl/nbgSdGhIlgWmkXJ06IdpX8dx/aQ0+mvYyK0elvo+XFoVAqO3GMljHFitP41gskP7H4AUEsDBBQAAAAIAPEhXF1g1vxwKQEAADMCAAAPAAAAeGwvd29ya2Jvb2sueG1stZHLSsQwGIVfpYbC7CZtFRelLQjD4GxE8AGGtPlrw+RSkqjj3q1LbytRXBdBZjXvM5e3MHMpzuDGjavk8P+c7+QkuVF6lCs18saCS5Oiyto6xtgUFQhiuqoG6Sal0oJYJ/UlNrUGQk0FYAXHURAcY0GYRFnSep1rnCXrBbM9N+6x/ou/KktWQE8VVwKk3QA0cGKZkqZitUGeJAJStJjczR5flk/N8v15/tYsmg/krWkDmqLQ3S2xbu2aGZZzQJ6OmRvoAQ0R/s9c86/pfPo6e/ic3Tc7iaKfRKBvTxmlIHdCRatQuG2NQskk0DNnuK+2jOGYS9Ed9hm3oHvEkpwY90SuCsIvWmKAvGqNWdWRdX731TnwT/yj2O/7YXSY4B1MtqdcBNx+bvYNUEsDBBQAAAAIAPEhXF2N9yxatAAAAIkCAAAaAAAAeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHPFkk0KgzAQRq8ScoCO2tJFUVfduC1eIOj4g9GEzJTq7Wt1oYEuupGuwjch73swiR+oFbdmoKa1JMZeD5TIhtneAKhosFd0MhaH+aYyrlc8R1eDVUWnaoQoCK7g9gyZxnumyCeLvxBNVbUF3k3x7HHgL2B4GddRg8hS5MrVyImEUW9jguUITzNZiqxMpMvKUMK/hSJPKDpQiHjSSJvNmr3684H1PL/FrX2J69DfyeXjAN7PS99QSwMEFAAAAAgA8SFcXW6nJLweAQAAVwQAABMAAABbQ29udGVudF9UeXBlc10ueG1sxZTPTsMwDMZfpcp1ajJ24IDWXYAr7MALhNZdo+afYm90b4/bbpNAo2IqEpdGje3v5/iLsn47RsCsc9ZjIRqi+KAUlg04jTJE8BypQ3Ka+DftVNRlq3egVsvlvSqDJ/CUU68hNusnqPXeUvbc8Taa4AuRwKLIHsfEnlUIHaM1pSaOq4OvvlHyE0Fy5ZCDjYm44AShrhL6yM+AU93rAVIyFWRbnehFO85SnVVIRwsopyWu9Bjq2pRQhXLvuERiTKArbADIWTmKLqbJxBOG8Xs3mz/ITAE5c5tCRHYswe24syV9dR5ZCBKZ6SNeiCw9+3zQu11B9Us2j/cjpHbwA9WwzJ/xV48v+jf2sfrHPt5DaP/6qverdNr4M18N78nmE1BLAQIUAxQAAAAIAPEhXF1Gx01IlQAAAM0AAAAQAAAAAAAAAAAAAACAAQAAAABkb2NQcm9wcy9hcHAueG1sUEsBAhQDFAAAAAgA8SFcXfkVdBjvAAAAKwIAABEAAAAAAAAAAAAAAIABwwAAAGRvY1Byb3BzL2NvcmUueG1sUEsBAhQDFAAAAAgA8SFcXfpcAVn8AgAA2g0AABMAAAAAAAAAAAAAAIAB4QEAAHhsL3RoZW1lL3RoZW1lMS54bWxQSwECFAMUAAAACADxIVxdBX/4F3gOAADObAAAGAAAAAAAAAAAAAAAgIEOBQAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1sUEsBAhQDFAAAAAgA8SFcXWmL1fdbAwAAugwAABgAAAAAAAAAAAAAAICBvBMAAHhsL3dvcmtzaGVldHMvc2hlZXQyLnhtbFBLAQIUAxQAAAAIAPEhXF3r9LTauAQAAOo7AAANAAAAAAAAAAAAAACAAU0XAAB4bC9zdHlsZXMueG1sUEsBAhQDFAAAAAgA8SFcXZeKuxzAAAAAEwIAAAsAAAAAAAAAAAAAAIABMBwAAF9yZWxzLy5yZWxzUEsBAhQDFAAAAAgA8SFcXWDW/HApAQAAMwIAAA8AAAAAAAAAAAAAAIABGR0AAHhsL3dvcmtib29rLnhtbFBLAQIUAxQAAAAIAPEhXF2N9yxatAAAAIkCAAAaAAAAAAAAAAAAAACAAW8eAAB4bC9fcmVscy93b3JrYm9vay54bWwucmVsc1BLAQIUAxQAAAAIAPEhXF1upyS8HgEAAFcEAAATAAAAAAAAAAAAAACAAVsfAABbQ29udGVudF9UeXBlc10ueG1sUEsFBgAAAAAKAAoAhAIAAKogAAAAAA=='
_LAYOUT_SPEC={'资料问题确认': {'start': 5, 'columns': 6, 'widths': [7, 22, 18, 66, 44, 45], 'header_end': 4}}
_v182_layout_base=main
def main(markdown, selection_request_json):
    out=_v182_layout_base(markdown, selection_request_json)
    out["template_base64"]=layout_template(_LAYOUT_TEMPLATE,out['payload_json'],_LAYOUT_SPEC)
    return out
