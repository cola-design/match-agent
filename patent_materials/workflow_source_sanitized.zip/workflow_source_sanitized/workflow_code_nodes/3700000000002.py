import math
import json
import re
ALLOWED = {'START_SELECTION', 'SUBMIT_CLARIFICATION', 'SUBMIT_BOM', 'HELP', 'UNKNOWN'}

def clean(value):
    return '' if value is None else str(value).strip()

def main(model_text: str, query: str='') -> dict:
    action, confidence, reason = ('UNKNOWN', 0.0, '未识别到明确操作')
    try:
        text = clean(model_text)
        text = re.sub('^```(?:json)?\\s*', '', text, flags=re.I)
        text = re.sub('\\s*```$', '', text)
        start, end = (text.find('{'), text.rfind('}'))
        obj = json.loads(text[start:end + 1])
        candidate = clean(obj.get('action')).upper()
        confidence = float(obj.get('confidence') or 0)
        reason = clean(obj.get('reason'))
        if candidate in ALLOWED and math.isfinite(confidence) and (0.85 <= confidence <= 1):
            action = candidate
    except Exception:
        pass
    q = clean(query)
    exact = {'开始选型': 'START_SELECTION', '重新选型': 'START_SELECTION', '提交问题确认': 'SUBMIT_CLARIFICATION', '提交需求确认': 'SUBMIT_CLARIFICATION', '提交问题确认单': 'SUBMIT_CLARIFICATION', '提交确认BOM': 'SUBMIT_BOM', '提交BOM确认': 'SUBMIT_BOM'}
    if q in exact:
        action, confidence, reason = (exact[q], 1.0, '明确标准指令')
    if not q or re.fullmatch('[\\d\\s.,，。]+', q) or q in {'你好', '您好', '在吗', '看看', '测试'}:
        action, confidence, reason = ('UNKNOWN', 0.0, '未提供明确执行指令')
    if not math.isfinite(confidence) or not 0 <= confidence <= 1:
        action, confidence, reason = ('UNKNOWN', 0.0, '意图置信度格式不合法')
    targets = {'START_SELECTION': '(?:开始|重新|进行)?选型', 'SUBMIT_BOM': '(?:提交|确认|上传).{0,5}BOM', 'SUBMIT_CLARIFICATION': '(?:提交|上传).{0,5}(?:问题|需求)确认'}
    if action in targets and re.search('(?:不要|不需要|暂不|先别|别|不想).{0,4}' + targets[action], q, re.I):
        action, confidence, reason = ('UNKNOWN', 0.0, '用户明确暂不执行该动作')
    return {'action': action, 'intent_confidence': confidence, 'intent_reason': reason}
