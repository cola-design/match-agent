import re

def main(extracted_text):
    source = str(extracted_text or '')
    visible = re.sub('PAYLOAD_B64_PART_\\d{3}:\\s*[A-Za-z0-9+/=]{1,24000}', '[系统数据已由代码保留，不属于人工意见]', source)
    if len(visible.encode('utf-8')) > 50000:
        visible = '当前确认表的可见正文超过50KB预算，请按柜号或回路分批；本次不得猜测或只读取前几行。'
    return {'text': visible}
