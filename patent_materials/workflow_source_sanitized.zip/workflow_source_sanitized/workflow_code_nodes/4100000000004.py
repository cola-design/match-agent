import json
import re

def parse_model_object(value):
    if isinstance(value, dict):
        return value
    text = re.sub('^```(?:json)?\\s*|\\s*```$', '', str(value or '').strip(), flags=re.I)
    obj = json.loads(text)
    if not isinstance(obj, dict):
        raise ValueError('模型必须返回JSON对象')
    return obj

def bind_document_fragment(chunk_json, model_text):
    chunk = json.loads(chunk_json) if isinstance(chunk_json, str) else chunk_json
    if not isinstance(chunk, dict) or not chunk.get('chunk_id') or (not chunk.get('document_hash')):
        raise ValueError('程序侧文本段输入缺少关联信息，停止汇总')
    try:
        body = dict(parse_model_object(model_text))
        kind = 'DRAWING' if str(chunk['chunk_id']).startswith('DRAWING-') else 'PROTOCOL'
        if str(body.get('fragment_status') or '').upper() == 'NO_RELEVANT_CONTENT':
            has_facts = bool(body.get('scheme_groups') or body.get('component_rules'))
            project = body.get('project_requirements')
            if isinstance(project, dict):
                has_facts = has_facts or any((v not in (None, '', [], {}) for v in project.values()))
            if has_facts:
                raise ValueError('声明无相关内容但同时返回了工程事实')
            body.setdefault('scheme_groups', [])
            body.setdefault('project_requirements', {})
            body.setdefault('component_rules', [])
        for key in ('scheme_groups', 'warnings'):
            if key in body and (not isinstance(body[key], list)):
                raise ValueError(key + '应为数组')
        if kind == 'DRAWING':
            if not isinstance(body.get('scheme_groups'), list):
                raise ValueError('模型未返回图纸方案数组')
            aliases = {'READABLE': 'READABLE', 'READY': 'READABLE', 'VALID': 'READABLE', 'PARTIAL': 'PARTIAL', 'NEED_REVIEW': 'PARTIAL', 'UNREADABLE': 'UNREADABLE', 'INVALID': 'UNREADABLE'}
            old = aliases.get(str(body.get('recognition_status') or '').upper())
            new = aliases.get(str(body.get('extraction_status') or '').upper())
            if old and new and (old != new):
                raise ValueError('识别状态字段矛盾')
            if old or new:
                body['recognition_status'] = old or new
        elif not isinstance(body.get('project_requirements'), dict) or not isinstance(body.get('scheme_groups'), list) or (not isinstance(body.get('component_rules'), list)):
            raise ValueError('模型未返回完整协议结构（项目参数、方案、器件规则）')
        status = str(body.get('fragment_status') or '').upper()
        if not status:
            status = 'PARTIAL' if body.get('recognition_status') in ('PARTIAL', 'UNREADABLE') else 'COMPLETE'
            body['_completion_basis'] = 'PROGRAM_SCHEMA_VALIDATION_ONLY'
        else:
            body['_completion_basis'] = 'MODEL_EXPLICIT_STATUS'
        body['fragment_status'] = status
    except (ValueError, TypeError) as exc:
        body = {'fragment_status': 'PARTIAL', 'scheme_groups': [], 'warnings': ['模型输出结构无法处理：' + str(exc)], '_binding_error': '模型输出结构无法处理：' + str(exc)}
    if chunk.get('input_problem'):
        body['fragment_status'] = 'PARTIAL'
        body['_binding_error'] = str(chunk['input_problem'])
    body['chunk_id'] = chunk['chunk_id']
    body['document_hash'] = chunk['document_hash']
    return {'result_json': json.dumps(body, ensure_ascii=False, separators=(',', ':'), allow_nan=False)}

def _prior_binding_main(input_json, model_text):
    return bind_document_fragment(input_json, model_text)

"""Exact citations plus one bounded model-assisted repair, never fact repair."""
import copy
import json
import re
import unicodedata


def source_norm(value):
    return re.sub(r'\s+', '', ''.join(unicodedata.normalize('NFKC', c) for c in str(value or '')))


def citation_leaves(value):
    if isinstance(value, list):
        for child in value:
            yield from citation_leaves(child)
    elif isinstance(value, dict):
        if str(value.get('text') or '').strip():
            yield {k: copy.deepcopy(v) for k, v in value.items() if k != 'sources'}
        if isinstance(value.get('sources'), list):
            for child in value['sources']:
                yield from citation_leaves(child)


def exact_citations(value, chunk):
    """Return only quotes actually present in this exact, current chunk."""
    text = chunk['text']
    hay = source_norm(text)
    index = []
    for i, char in enumerate(text):
        index.extend(i for c in unicodedata.normalize('NFKC', char) if not c.isspace())
    valid, rejected, seen = [], [], set()
    for leaf in citation_leaves(value):
        needle = source_norm(leaf['text'])
        if not needle or needle not in hay:
            rejected.append(leaf['text'])
            continue
        if needle in seen:
            continue
        seen.add(needle)
        spans = [[chunk['start'] + index[h.start()], chunk['start'] + index[h.end()-1]+1]
                 for h in re.finditer(re.escape(needle), hay)]
        anchored = dict(leaf, chunk_id=chunk['chunk_id'], document_hash=chunk['document_hash'],
                        source_verified=True, chunk_start=chunk['start'], chunk_end=chunk['end'],
                        source_spans=spans, page_index=None)
        anchored.pop('source_start', None)
        anchored.pop('source_end', None)
        if len(spans) == 1:
            anchored.update(source_start=spans[0][0], source_end=spans[0][1])
        valid.append(anchored)
    return valid, rejected


def anchor_evidence(value, chunk, errors):
    valid, rejected = exact_citations(value, chunk)
    if not valid:
        if not list(citation_leaves(value)):
            return {}
        example = next((str(x.get('text')) for x in citation_leaves(value)), '')
        errors.append(chunk['chunk_id']+'：来源原文未在当前文本段找到，不能用模型生成的原文作证据'
                      + ('；未定位摘录：'+example if example else '；未返回原文摘录'))
        return {}
    first = copy.deepcopy(valid[0])
    if len(valid) > 1:
        first['sources'] = copy.deepcopy(valid)
    if rejected:
        # A model's prose summary is not promoted to source evidence. Preserve
        # it for diagnosis while anchoring the independently valid quotations.
        first['unmatched_summary_texts'] = rejected
    return first


def json_pointer_part(value):
    return str(value).replace('~', '~0').replace('/', '~1')


def pointer_parent(root, pointer):
    if not isinstance(pointer, str) or not pointer.startswith('/'):
        raise ValueError('证据路径无效')
    parts = [p.replace('~1', '/').replace('~0', '~') for p in pointer[1:].split('/')]
    target = root
    for p in parts[:-1]:
        target = target[int(p)] if isinstance(target, list) else target[p]
    return target, parts[-1]


def missing_citations(body, chunk):
    tasks = []
    def walk(value, pointer=''):
        if isinstance(value, list):
            for i, child in enumerate(value):
                walk(child, pointer+'/'+str(i))
        elif isinstance(value, dict):
            entity = (('scheme_group_id' in value or 'protocol_scheme_id' in value)
                      and ('scheme_name' in value or 'circuits' in value))
            entity = entity or ('components' in value and 'circuit_id' in value)
            entity = entity or ('component_role' in value and any(k in value for k in ('item_id','rule_id','shown_model','parameters')))
            has_facts=any(v not in (None,'',[],{}) for k,v in value.items() if k!='evidence' and not k.startswith('_'))
            if entity or ('evidence' in value and (value['evidence'] or has_facts)):
                valid, rejected = exact_citations(value.get('evidence'), chunk)
                if not valid:
                    context = {k:copy.deepcopy(v) for k,v in value.items()
                               if k!='evidence' and (not isinstance(v,(list,dict)) or k in ('shown_parameters','parameters'))}
                    tasks.append({'path':pointer+'/evidence','context':context,
                                  'unmatched_quotes':rejected,'reason':'未找到当前对象可核查的原文摘录'})
            for key, child in value.items():
                if key != 'evidence' and not key.startswith('_'):
                    walk(child, pointer+'/'+json_pointer_part(key))
    walk(body)
    return tasks


def prepare_source_repair(result_json, chunk_json):
    body = json.loads(result_json)
    chunk = json.loads(chunk_json) if isinstance(chunk_json,str) else chunk_json
    tasks = [] if body.get('_binding_error') or chunk.get('input_problem') else missing_citations(body,chunk)
    status = 'REPAIR' if tasks else 'DIRECT'
    request = json.dumps({'source_chunk':chunk,'citation_tasks':tasks},ensure_ascii=False,separators=(',',':')) if tasks else '{}'
    if len(request.encode('utf-8')) > 50000:
        body['_binding_error']='本段原文与待修复证据超过50KB输入预算，请拆分资料；本次不使用截断原文'
        result_json=json.dumps(body,ensure_ascii=False,separators=(',',':'))
        status='DIRECT';request='{}'
    return {'result_json':result_json,'evidence_check_status':status,'repair_input':request}


def facts_without_evidence(value):
    if isinstance(value,list):return [facts_without_evidence(v) for v in value]
    if isinstance(value,dict):
        return {k:facts_without_evidence(v) for k,v in value.items() if k!='evidence' and not k.startswith('_')}
    return value


def identity_in_quotes(token, quotes):
    token=unicodedata.normalize('NFKC',str(token)).strip()
    hay=unicodedata.normalize('NFKC','\n'.join(quotes))
    if re.fullmatch(r'[A-Za-z0-9_.:/\-]+',token):
        return bool(re.search(r'(?<![A-Za-z0-9])'+re.escape(token)+r'(?![A-Za-z0-9])',hay,re.I))
    return source_norm(token).casefold() in source_norm(hay).casefold()


def apply_source_repair(input_json, original_result_json, repair_text):
    body = json.loads(original_result_json)
    chunk = json.loads(input_json) if isinstance(input_json,str) else input_json
    original_facts = facts_without_evidence(body)
    try:
        if body.get('chunk_id') != chunk['chunk_id'] or body.get('document_hash') != chunk['document_hash']:
            raise ValueError('证据修复关联了其他文档或文本段')
        tasks = missing_citations(body,chunk)
        expected = {t['path'] for t in tasks}
        contexts={t['path']:t['context'] for t in tasks}
        text = re.sub(r'^```(?:json)?\s*|\s*```$', '', str(repair_text or '').strip(), flags=re.I)
        repair=json.loads(text)
        if not isinstance(repair,dict) or set(repair)!={'citations'} or not isinstance(repair['citations'],list):
            raise ValueError('修复模型必须仅返回citations数组，不得返回或修改工程事实')
        found={}
        for row in repair['citations']:
            if not isinstance(row,dict) or set(row)!={'path','quotes'}:
                raise ValueError('修复项只能包含证据路径和原文摘录')
            path=row['path']
            if path not in expected or path in found:
                raise ValueError('修复项证据路径无效、重复或越过原请求范围')
            quotes=row['quotes']
            if not isinstance(quotes,list) or not 1<=len(quotes)<=6 or not all(isinstance(q,str) and q.strip() for q in quotes):
                raise ValueError('当前对象仍缺少可核查原文摘录')
            value=[{'text':q,'page_index':None,'location':'本段原文重新摘录'} for q in quotes]
            anchored,rejected=exact_citations(value,chunk)
            if rejected or len(anchored)!=len({source_norm(q) for q in quotes}):
                raise ValueError('补充摘录仍未逐字命中当前原文，不能放行')
            context=contexts[path];parameters=context.get('parameters') or {}
            if not isinstance(parameters,dict):parameters={}
            identities=[context.get('shown_model'),context.get('symbol'),parameters.get('bit_number'),
                        parameters.get('model'),parameters.get('designated_model')]
            key=context.get('source_scheme_key')
            if key and key!='__PROJECT__':identities.append(key)
            if any(not identity_in_quotes(token,quotes) for token in identities if token not in (None,'')):
                raise ValueError('补充原文未包含当前对象的位号、指定型号或方案标识，不能借用其他对象证据')
            found[path]=value[0] if len(value)==1 else dict(value[0],sources=value)
        if set(found)!=expected:
            raise ValueError('修复模型遗漏了待核对对象，不能只处理部分证据')
        result=copy.deepcopy(body)
        for pointer,value in found.items():
            parent,key=pointer_parent(result,pointer)
            if not isinstance(parent,dict) or key!='evidence':
                raise ValueError('修复只能写入对象的evidence字段')
            parent[key]=value
        if facts_without_evidence(result)!=original_facts or missing_citations(result,chunk):
            raise ValueError('工程事实发生变化或仍存在未定位证据')
        result['_source_repair']={'status':'EXACT_QUOTES_VERIFIED','attempts':1,'paths':sorted(found)}
        return {'result_json':json.dumps(result,ensure_ascii=False,separators=(',',':'))}
    except (ValueError,TypeError,KeyError,IndexError) as exc:
        body['_binding_error']='原文证据自动补充一次后仍未通过：'+str(exc)
        body['_source_repair_failure']={'attempts':1,'message':str(exc)}
        return {'result_json':json.dumps(body,ensure_ascii=False,separators=(',',':'))}


def main(input_json, model_text):
    out=_prior_binding_main(input_json,model_text)
    return prepare_source_repair(out['result_json'],input_json)
