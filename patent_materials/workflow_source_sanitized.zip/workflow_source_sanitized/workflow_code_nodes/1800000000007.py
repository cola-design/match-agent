import base64 as _wb64
import gzip as _wgzip
import hashlib as _whash
import io as _wio
import json as _wjson
_WIRE_PREFIX = 'GZJSON1:'
_WIRE_MAX = 55000
_CONTEXT_MAX = 5000000
_BATCH_MAX = 120

class CapacityError(ValueError):
    pass

def wire_loads(value):
    if isinstance(value, (dict, list)):
        return value
    text = str(value or '').strip()
    if text.startswith(_WIRE_PREFIX):
        digest, body = text[len(_WIRE_PREFIX):].split(':', 1)
        compressed = _wb64.b64decode(body, validate=True)
        with _wgzip.GzipFile(fileobj=_wio.BytesIO(compressed)) as stream:
            raw = stream.read(_CONTEXT_MAX + 1)
        if len(raw) > _CONTEXT_MAX:
            raise CapacityError('完整上下文超过本版5MB解码保护上限，请按柜号或回路分批')
        if _whash.sha256(raw).hexdigest() != digest:
            raise ValueError('上下文校验失败，内容可能不完整')
        return _wjson.loads(raw.decode('utf-8'))
    return _wjson.loads(text)

def wire_pack(value):
    raw = _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    if len(raw) > _CONTEXT_MAX:
        raise CapacityError('完整上下文超过本版5MB保护上限，请按柜号或回路分批')
    if len(raw) <= _WIRE_MAX:
        return raw.decode('utf-8')
    result = _WIRE_PREFIX + _whash.sha256(raw).hexdigest() + ':' + _wb64.b64encode(_wgzip.compress(raw, compresslevel=9, mtime=0)).decode('ascii')
    if len(result.encode('utf-8')) > _WIRE_MAX:
        raise CapacityError('上下文无损压缩后仍超过传递预算，请按柜号或回路分批；本次不生成不完整BOM')
    return result

def plain_json(value):
    return _wjson.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def capacity_markdown(message):
    return '## 资料问题确认\n\n| 序号 | 关联位置 | 问题类型 | 问题说明 | 对后续的影响 | 工程师确认/补充 |\n|---:|---|---|---|---|---|\n| 1 | 当前提交 | 处理容量 | ' + message.replace('|', '／') + ' | 本次未进入选型或报价，未生成部分清单 | 请拆分资料后重新开始选型 |'

def check_array_budget(requirements):
    if len(requirements) > _BATCH_MAX:
        return '本次共%d项有效BOM需求，超过本版每次%d项的Excel模板容量。请按柜号或回路分批提交；全部需求仍保留在内部上下文，本次未执行部分选型。' % (len(requirements), _BATCH_MAX)
    if len(plain_json(requirements).encode('utf-8')) > 140000:
        return '本批需求及证据展开后超过140KB数组预算，请按柜号或回路分批。本次未执行部分选型。'
    if any((len(plain_json(r).encode('utf-8')) > 45000 for r in requirements)):
        return '单项需求及证据超过45KB预算，请精简重复原文或将相关页单独提交；本次未静默截断证据。'
    return ''
import json
import re

def strip_fence(text):
    value = (text or '').strip()
    value = re.sub('^```(?:json)?\\s*', '', value, flags=re.I)
    value = re.sub('\\s*```$', '', value)
    return value.strip()

def parse_object(value):
    if isinstance(value, str) and value.strip().startswith(_WIRE_PREFIX):
        return wire_loads(value)
    if isinstance(value, dict):
        return value
    try:
        result = json.loads(strip_fence(value))
        return result if isinstance(result, dict) else {}
    except Exception:
        return {}

def clean(value):
    if value is None:
        return ''
    if isinstance(value, bool):
        return '是' if value else '否'
    if isinstance(value, (dict, list)):
        value = json.dumps(value, ensure_ascii=False)
    return str(value).replace('|', '／').replace('\n', ' ').replace('\r', ' ').strip()

def num__stage_1(value):
    if value in (None, '') or isinstance(value, bool):
        return None
    try:
        x = float(value)
        return int(x) if x.is_integer() else x
    except Exception:
        return None

def evidence_text(value):
    if isinstance(value, list):
        return '；'.join((evidence_text(x) for x in value if x not in (None, '', [], {})))
    if isinstance(value, dict):
        page = value.get('page_index') or value.get('image_index') or ''
        section = clean(value.get('section'))
        location = clean(value.get('location'))
        text = clean(value.get('text'))
        prefix = '第%s页' % page if page else ''
        return clean(' '.join((x for x in [prefix, section, location, text] if x)))
    return clean(value)

def compact_value(value):
    if value in (None, '', [], {}):
        return ''
    if isinstance(value, list):
        return '、'.join((clean(x) for x in value if clean(x)))
    if isinstance(value, dict):
        return parameter_text(value)
    return clean(value)

def field_cn(key):
    mapping = {'system_voltage_v': '系统电压(V)', 'frequency_hz': '频率(Hz)', 'short_circuit_capacity_min_ka': '最低分断能力(kA)', 'protection_level_min': '最低防护等级', 'installation_mode': '安装方式', 'cabinet_material': '箱体材质', 'cabinet_thickness_mm': '箱体板厚(mm)', 'door_hinge_material': '门锁/铰链材质', 'environment_temperature_min_c': '最低环境温度(℃)', 'environment_temperature_max_c': '最高环境温度(℃)', 'altitude_max_m': '最高海拔(m)', 'brand_requirements': '品牌范围', 'standards': '标准', 'general_requirements': '其他总体要求', 'rated_voltage_v': '额定电压(V)', 'voltage_v': '电压(V)', 'rated_current_min_a': '最小额定电流(A)', 'rated_current_a': '额定电流(A)', 'pole_count': '极数', 'breaking_capacity_min_ka': '最小分断能力(kA)', 'leakage_required': '漏电保护', 'leakage_current_ma': '漏电动作电流(mA)', 'operation_mode': '操作方式', 'control_voltage': '控制电压', 'required_accessories': '必需附件', 'brand_constraints': '品牌要求', 'quantity_per_cabinet': '每柜数量', 'cabinet_quantity': '柜体数量', 'project_quantity': '项目总数量', 'max_discharge_current_min_ka': '最大放电电流下限(kA)', 'phase_config': '相线制', 'backup_protection': '后备保护', 'coordination': '配合要求', 'action_value': '动作值', 'action_current_delay': '动作电流/延时', 'function': '功能', 'feature': '功能特征', 'material': '材质', 'material_min': '材质下限', 'grounding_points_min': '最少接地点', 'bonding_requirement': '跨接要求', 'cross_section_rule': '截面规则', 'sizing_rule': '选径规则', 'color_phase_sequence': '颜色/相序', 'spec_match': '规格匹配', 'maintenance_space': '维护空间', 'size_match': '规格匹配', 'installation_position': '安装位置', 'anti_corrosion': '防腐要求', 'content': '内容要求', 'consistency': '一致性要求', 'space_requirement': '空间要求', 'exclusion': '选型范围说明', 'parameter_status': '参数状态', 'capability_requirement': '能力要求', 'rated_current_rule': '额定电流规则', 'rated_current_min_rule': '额定电流下限规则', 'color': '颜色', 'cross_section_mm2': '截面(mm²)', 'structure': '结构', 'marking': '标识', 'trip_curve': '脱扣曲线', 'suffix': '后缀', 'note': '说明', 'rated_current': '额定电流规则', 'match_requirement': '规格匹配', 'cross_section_calc': '选径规则', 'content_requirement': '内容要求', 'table_type': '表位类型', 'disconnection_requirement': '功能特征', 'identification': '标识', 'cross_section': '截面规则', 'protection_function': '保护功能'}
    return mapping.get(clean(key), clean(key) or '参数')

def parameter_text(value):
    if not isinstance(value, dict):
        return clean(value)
    parts = []
    for k, v in value.items():
        if v in (None, '', [], {}):
            continue
        parts.append('%s：%s' % (field_cn(k), compact_value(v)))
    return '；'.join(parts)

def protocol_groups(protocol):
    return protocol.get('scheme_groups') if isinstance(protocol.get('scheme_groups'), list) else []

def protocol_rules(protocol):
    rules = protocol.get('component_rules')
    if isinstance(rules, list):
        return rules
    old = protocol.get('component_requirements')
    return old if isinstance(old, list) else []

def add_issue(issues, severity, message, scheme_group_id='', request_id='', stage='人工确认', blocks_retrieval=False):
    key = (clean(severity).upper(), clean(message), clean(scheme_group_id), clean(request_id), clean(stage), bool(blocks_retrieval))
    existing = {(x.get('severity'), x.get('message'), x.get('scheme_group_id'), x.get('request_id'), x.get('stage'), bool(x.get('blocks_retrieval'))) for x in issues}
    if key not in existing:
        issues.append({'severity': clean(severity).upper() or 'WARNING', 'message': clean(message), 'scheme_group_id': clean(scheme_group_id), 'request_id': clean(request_id), 'stage': clean(stage) or '人工确认', 'blocks_retrieval': bool(blocks_retrieval)})

def severity_cn(value):
    return {'BLOCKER': '阻断', 'WARNING': '提示', 'INFO': '信息'}.get(clean(value).upper(), '提示')

def compare_equal(a, b, mode='text'):
    if a in (None, '') or b in (None, ''):
        return None
    if mode == 'number':
        na, nb = (num(a), num(b))
        return None if na is None or nb is None else abs(float(na) - float(nb)) < 1e-09
    if mode == 'bool':
        if not isinstance(a, bool) or not isinstance(b, bool):
            return None
        return a == b
    if mode == 'poles':
        aa, bb = (normalize_poles(a), normalize_poles(b))
        return None if not aa or not bb else aa == bb
    return clean(a).lower() == clean(b).lower()

def normalize_ip(value):
    m = re.search('IP\\s*(\\d{2})', clean(value).upper())
    return int(m.group(1)) if m else None

def code_conflicts__stage_1(drawing, protocol, selections, pmap, issues):
    conflicts = []
    dgroups = drawing.get('scheme_groups') if isinstance(drawing.get('scheme_groups'), list) else []
    dmap = {clean(g.get('scheme_group_id')): g for g in dgroups if isinstance(g, dict)}
    for sel in selections:
        if sel.get('match_status') != 'UNIQUE':
            continue
        gid = clean(sel.get('scheme_group_id'))
        dg = dmap.get(gid, {})
        pg = pmap.get(clean(sel.get('protocol_scheme_id')), {})
        for key, label, mode in [('main_current_a', '主回路电流', 'number'), ('incoming_count', '进线数量', 'number'), ('outgoing_count', '出线数量', 'number'), ('meter_required', '电表位要求', 'bool'), ('isolator_count', '隔离开关数量', 'number'), ('pole_count', '极数', 'poles')]:
            r = compare_equal(dg.get(key), pg.get(key), mode)
            if r is False:
                c = {'severity': 'BLOCKER', 'scheme_group_id': gid, 'item': label, 'protocol_value': pg.get(key), 'drawing_value': dg.get(key), 'description': '协议与图纸明确值不一致'}
                conflicts.append(c)
                add_issue(issues, 'BLOCKER', '%s：%s协议值与图纸值不一致' % (gid, label), gid, stage='协议图纸差异', blocks_retrieval=True)
    project = protocol.get('project_requirements') if isinstance(protocol.get('project_requirements'), dict) else {}
    for dg in dgroups:
        gid = clean(dg.get('scheme_group_id'))
        if project.get('cabinet_material') and dg.get('cabinet_material'):
            pm, dm = (clean(project.get('cabinet_material')), clean(dg.get('cabinet_material')))
            pg_grade = re.search('\\b(201|304|316)\\b', pm)
            dg_grade = re.search('\\b(201|304|316)\\b', dm)
            if pg_grade and dg_grade and (pg_grade.group(1) != dg_grade.group(1)):
                conflicts.append({'severity': 'BLOCKER', 'scheme_group_id': gid, 'item': '箱体材质', 'protocol_value': pm, 'drawing_value': dm, 'description': '不锈钢牌号不一致'})
                add_issue(issues, 'BLOCKER', '%s：箱体材质牌号协议与图纸不一致' % gid, gid, stage='协议图纸差异', blocks_retrieval=True)
        pth, dth = (num(project.get('cabinet_thickness_mm')), num(dg.get('cabinet_thickness_mm')))
        if pth is not None and dth is not None and (abs(float(pth) - float(dth)) > 1e-09):
            conflicts.append({'severity': 'BLOCKER', 'scheme_group_id': gid, 'item': '箱体板厚', 'protocol_value': pth, 'drawing_value': dth, 'description': '协议与图纸板厚不一致'})
            add_issue(issues, 'BLOCKER', '%s：箱体板厚协议与图纸不一致' % gid, gid, stage='协议图纸差异', blocks_retrieval=True)
        p_ip, d_ip = (normalize_ip(project.get('protection_level_min')), normalize_ip(dg.get('protection_level')))
        if p_ip is not None and d_ip is not None and (d_ip < p_ip):
            conflicts.append({'severity': 'BLOCKER', 'scheme_group_id': gid, 'item': '防护等级', 'protocol_value': 'IP%d及以上' % p_ip, 'drawing_value': 'IP%d' % d_ip, 'description': '图纸防护等级低于协议最低要求'})
            add_issue(issues, 'BLOCKER', '%s：图纸防护等级低于协议最低要求' % gid, gid, stage='协议图纸差异', blocks_retrieval=True)
    return conflicts

def combined_text(obj):
    if not isinstance(obj, dict):
        return clean(obj)
    values = []
    for key in ['component_role', 'category', 'quantity_rule', 'shown_model', 'symbol', 'functional_position']:
        if obj.get(key) not in (None, '', [], {}):
            values.append(clean(obj.get(key)))
    if isinstance(obj.get('parameters'), dict):
        values.append(parameter_text(obj.get('parameters')))
    if isinstance(obj.get('shown_parameters'), dict):
        values.append(parameter_text(obj.get('shown_parameters')))
    return ' '.join(values)

def rule_kind__stage_1(rule):
    rc = ' '.join([clean(rule.get('component_role')), clean(rule.get('category'))]) if isinstance(rule, dict) else clean(rule)
    t = combined_text(rule)
    if 'SPD后级' in rc.upper().replace('SPD', 'SPD') or '浪涌后级' in rc or '浪涌后备' in rc or ('浪涌' in rc and '后备' in rc):
        return 'surge_backup'
    if '浪涌保护器' in rc or ('浪涌保护' in rc and '后备' not in rc):
        return 'surge'
    if '自动重合闸' in t or '重合闸保护' in t:
        return 'recloser'
    if '隔离开关' in t:
        return 'isolator'
    if '漏电' in t:
        return 'leakage'
    if '塑壳断路器' in t:
        return 'main_breaker'
    if '小型断路器' in t or '微型断路器' in t:
        return 'branch_breaker'
    if '电能表安装位' in t or '计量安装' in t:
        return 'metering_space'
    if '工作零线排' in t or '零线排' in t:
        return 'neutral_bar'
    if '保护接地排' in t or '接地排' in t:
        return 'pe_bar'
    if '箱内导线' in t or '铜排' in t or '内部导电' in t:
        return 'internal_conductor'
    if '接线端子' in t:
        return 'terminal'
    if '防水接头' in t:
        return 'gland'
    if '门锁' in t or '铰链' in t:
        return 'hardware'
    if '标识' in t or '铭牌' in t:
        return 'label'
    return 'other'

def item_kind__stage_1(item):
    if not isinstance(item, dict):
        return 'other'
    symbol = clean(item.get('symbol')).upper()
    role = clean(item.get('component_role'))
    category = clean(item.get('category'))
    t = ' '.join([symbol, role, category, clean(item.get('functional_position'))])
    if symbol in {'QF1', 'SCB'} or 'SPD后级' in t.upper().replace('SPD', 'SPD') or '浪涌前级' in t or ('浪涌后备' in t) or ('浪涌后级' in t):
        return 'surge_backup'
    if symbol == 'SPD' or '浪涌保护器' in t:
        return 'surge'
    if symbol == 'ARD' or '自动重合闸' in t or '重合闸' in t:
        return 'recloser'
    if symbol == 'QS' or '隔离开关' in t:
        return 'isolator'
    if symbol == 'PJ' or '电能表' in t or '计量' in t:
        return 'metering_space'
    if symbol == 'QF' or ('断路器' in t and '浪涌' not in t):
        if '塑壳' in t:
            return 'main_breaker'
        if '小型' in t or '微型' in t:
            return 'branch_breaker'
        return 'generic_breaker'
    if '漏电' in t:
        return 'leakage'
    if 'PE排' in t or '保护接地排' in t or '接地排' in t:
        return 'pe_bar'
    if '工作零线排' in t or '零线排' in t:
        return 'neutral_bar'
    if '防水接头' in t:
        return 'gland'
    if '门锁' in t or '铰链' in t:
        return 'hardware'
    if '标识' in t or '铭牌' in t:
        return 'label'
    if '接线端子' in t:
        return 'terminal'
    if '导线' in t or '铜排' in t or role == '门板接地线':
        return 'internal_conductor'
    return 'other'

def rule_index(protocol):
    rules = [r for r in protocol_rules(protocol) if isinstance(r, dict)]
    by_id = {clean(r.get('rule_id')): r for r in rules if clean(r.get('rule_id'))}
    by_kind = {}
    for r in rules:
        by_kind.setdefault(rule_kind(r), []).append(r)
    return (rules, by_id, by_kind)

def all_drawing_items__stage_1(group):
    items = []
    for c in group.get('circuits', []) if isinstance(group.get('circuits'), list) else []:
        if not isinstance(c, dict):
            continue
        cid = clean(c.get('circuit_id'))
        for item in c.get('components', []) if isinstance(c.get('components'), list) else []:
            if not isinstance(item, dict):
                continue
            x = dict(item)
            x['scope_type'] = 'circuit'
            x['circuit_id'] = cid
            x['circuit_type'] = clean(c.get('circuit_type'))
            if not x.get('evidence'):
                x['evidence'] = c.get('evidence')
            items.append(x)
    seen = {clean(x.get('item_id')) for x in items if clean(x.get('item_id'))}
    for item in group.get('drawing_items', []) if isinstance(group.get('drawing_items'), list) else []:
        if not isinstance(item, dict):
            continue
        iid = clean(item.get('item_id'))
        if iid and iid in seen:
            continue
        items.append(dict(item))
        if iid:
            seen.add(iid)
    canonical = {}
    for x in items:
        iid = clean(x.get('item_id')).upper()
        symbol = clean(x.get('symbol')).upper()
        if iid.startswith('BOM-') or not symbol:
            continue
        canonical.setdefault(symbol, []).append(x)
    result = []
    for x in items:
        iid = clean(x.get('item_id')).upper()
        if iid.startswith('BOM-'):
            symbol = iid[4:].strip()
            model = clean(x.get('shown_model')).upper().replace(' ', '')
            qty = num(x.get('quantity_per_cabinet'))
            duplicates = [c for c in canonical.get(symbol, []) if model and model == clean(c.get('shown_model')).upper().replace(' ', '') and (qty is None or num(c.get('quantity_per_cabinet')) in (None, qty))]
            if len(duplicates) == 1:
                canon = duplicates[0]
                if num(canon.get('quantity_per_cabinet')) is None and qty is not None:
                    canon['quantity_per_cabinet'] = qty
                continue
        result.append(x)
    return result

def proposal_indexes(data):
    raw = data.get('component_requirements') if isinstance(data.get('component_requirements'), list) else []
    by_source, by_rule, by_role = ({}, {}, {})
    for p in raw:
        if not isinstance(p, dict):
            continue
        gid = clean(p.get('scheme_group_id'))
        sid = clean(p.get('source_item_id'))
        if sid:
            by_source[gid, sid] = p
        for rid in p.get('matched_protocol_rule_ids', []) if isinstance(p.get('matched_protocol_rule_ids'), list) else []:
            rid = clean(rid)
            if rid:
                by_rule.setdefault((gid, rid), []).append(p)
        role = clean(p.get('component_role'))
        if role:
            by_role.setdefault((gid, role), []).append(p)
    return (by_source, by_rule, by_role)

def proposal_user_confirmed(proposal, supplementary_notes):
    return bool(clean(supplementary_notes)) and isinstance(proposal, dict) and (proposal.get('user_confirmation_applied') is True)

def get_param(params, *names):
    if not isinstance(params, dict):
        return None
    for name in names:
        if name in params and params.get(name) not in (None, ''):
            return params.get(name)
    return None

def make_base_requirement(gid, item, project, request_id):
    shown_params = item.get('shown_parameters') if isinstance(item.get('shown_parameters'), dict) else {}
    req = {'request_id': request_id, 'source_item_id': clean(item.get('item_id')), 'scheme_group_id': gid, 'scope_type': clean(item.get('scope_type')) or ('circuit' if clean(item.get('circuit_id')) else 'auxiliary'), 'circuit_id': clean(item.get('circuit_id')), 'symbol': clean(item.get('symbol')), 'component_role': clean(item.get('component_role')), 'category_path': clean(item.get('category')), 'shown_model': clean(item.get('shown_model')), 'drawing_parameters': shown_params, 'protocol_parameters': {}, 'requirements': {'rated_voltage_v': num(get_param(shown_params, 'rated_voltage_v', 'voltage_v')), 'rated_current_min_a': num(get_param(shown_params, 'rated_current_a', 'current_a')), 'pole_count': clean(get_param(shown_params, 'pole_count', 'poles')), 'breaking_capacity_min_ka': num(get_param(shown_params, 'breaking_capacity_ka', 'breaking_capacity_min_ka')), 'continuous_operating_voltage_v': num(get_param(shown_params, 'continuous_operating_voltage_v', 'maximum_continuous_operating_voltage_v', 'max_continuous_operating_voltage_v', 'uc_v', 'spd_uc_v')), 'leakage_required': None, 'leakage_current_ma': None, 'installation_mode': clean(project.get('installation_mode')), 'operation_mode': clean(get_param(shown_params, 'connection', 'operation_mode', 'note')), 'control_voltage': '', 'required_accessories': [], 'brand_constraints': project.get('brand_requirements') if isinstance(project.get('brand_requirements'), list) else []}, 'quantity_per_cabinet': num(item.get('quantity_per_cabinet')), 'cabinet_quantity': None, 'project_quantity': None, 'unit': clean(item.get('unit')) or '件', 'hard_constraints': [], 'preferences': [], 'source_evidence': {'drawing': [item.get('evidence')] if item.get('evidence') else [], 'protocol': []}, 'matched_protocol_rule_ids': [], 'candidate_protocol_rule_ids': [], 'mapping_status': 'DRAWING_ONLY', 'handling_mode': 'BOM_DIRECT', 'retrieval_required': False, 'missing_parameters': [], 'search_keywords': [clean(item.get('shown_model')), clean(item.get('component_role')), clean(item.get('category'))], 'functional_position': clean(item.get('functional_position'))}
    if req['requirements']['rated_voltage_v'] is None and num(project.get('system_voltage_v')) is not None and (req['scope_type'] == 'circuit'):
        req['requirements']['rated_voltage_v'] = num(project.get('system_voltage_v'))
    return req

def default_unit(kind):
    if kind in {'main_breaker', 'branch_breaker', 'isolator', 'recloser', 'surge', 'surge_backup', 'leakage'}:
        return '台'
    if kind == 'metering_space':
        return '处'
    if kind in {'neutral_bar', 'pe_bar', 'internal_conductor', 'hardware', 'label'}:
        return '套'
    return '个'

def handling_for_kind(kind, has_drawing=True, conditional=False):
    if kind in {'main_breaker', 'branch_breaker', 'generic_breaker', 'isolator', 'recloser', 'surge', 'surge_backup'}:
        return 'PRODUCT_SELECTION'
    if kind == 'leakage':
        return 'HUMAN_CONFIRM' if conditional and (not has_drawing) else 'PRODUCT_SELECTION'
    if kind == 'metering_space':
        return 'SPACE_ONLY'
    if kind in {'neutral_bar', 'pe_bar', 'gland', 'hardware', 'label'}:
        return 'BOM_DIRECT'
    if kind in {'internal_conductor', 'terminal'}:
        return 'BOM_REVIEW'
    return 'BOM_DIRECT' if has_drawing else 'BOM_REVIEW'

def apply_group_defaults(req, group, kind):
    r = req.get('requirements') if isinstance(req.get('requirements'), dict) else {}
    if not r.get('pole_count') and kind in {'main_breaker', 'branch_breaker', 'generic_breaker', 'isolator', 'recloser', 'surge', 'surge_backup', 'leakage'}:
        r['pole_count'] = clean(group.get('pole_count'))
    if r.get('rated_current_min_a') is None and kind in {'main_breaker', 'branch_breaker', 'generic_breaker', 'isolator', 'recloser', 'leakage'}:
        r['rated_current_min_a'] = num(group.get('main_current_a'))
    req['requirements'] = r

def merge_rule_into_requirement__stage_1(req, rule, group, project):
    rid = clean(rule.get('rule_id'))
    if rid and rid not in req['matched_protocol_rule_ids']:
        req['matched_protocol_rule_ids'].append(rid)
    req['mapping_status'] = 'MATCHED'
    params = rule.get('parameters') if isinstance(rule.get('parameters'), dict) else {}
    if params:
        if req.get('protocol_parameters'):
            req['protocol_parameters'][rid or '规则%d' % (len(req['protocol_parameters']) + 1)] = params
        else:
            req['protocol_parameters'] = {rid or '协议规则': params}
    if rule.get('evidence'):
        protocol_evidence = req['source_evidence'].setdefault('protocol', [])
        if rule.get('evidence') not in protocol_evidence:
            protocol_evidence.append(rule.get('evidence'))
    kind = rule_kind(rule)
    apply_group_defaults(req, group, kind)
    r = req.get('requirements') if isinstance(req.get('requirements'), dict) else {}
    if num(project.get('system_voltage_v')) is not None and kind in {'main_breaker', 'branch_breaker', 'isolator', 'recloser', 'surge', 'surge_backup', 'leakage'}:
        if r.get('rated_voltage_v') is None:
            r['rated_voltage_v'] = num(project.get('system_voltage_v'))
    if kind == 'main_breaker' and num(project.get('short_circuit_capacity_min_ka')) is not None:
        r['breaking_capacity_min_ka'] = max(num(r.get('breaking_capacity_min_ka')) or 0, num(project.get('short_circuit_capacity_min_ka')))
    if kind == 'leakage':
        r['leakage_required'] = True
    for k, v in params.items():
        kl = clean(k).lower()
        if v in (None, '', [], {}):
            continue
        if 'pole' in kl or '极数' in kl:
            r['pole_count'] = clean(v)
        elif 'breaking' in kl or '分断' in kl:
            vv = num(v)
            if vv is not None:
                r['breaking_capacity_min_ka'] = vv
        elif 'rated_current' in kl and num(v) is not None:
            r['rated_current_min_a'] = num(v)
    req['requirements'] = r
    if req.get('quantity_per_cabinet') is None:
        req['quantity_per_cabinet'] = quantity_from_rule(rule, group)
    if not req.get('unit'):
        req['unit'] = default_unit(kind)

def make_protocol_requirement(gid, rule, group, project, request_id):
    kind = rule_kind(rule)
    params = rule.get('parameters') if isinstance(rule.get('parameters'), dict) else {}
    qpc = quantity_from_rule(rule, group)
    if qpc is None:
        raw_qty = next((params.get(k) for k in ('quantity_per_cabinet', 'quantity', 'qty', '每柜数量', '单柜数量', '数量') if params.get(k) not in (None, '')), None)
        qpc = num(raw_qty)
        if qpc is None and raw_qty not in (None, ''):
            hit = re.fullmatch('\\s*([1-9]\\d{0,3})(?:\\.0+)?\\s*(?:个|件|套|只|台|根|块|支|组|处|颗)?\\s*', clean(raw_qty))
            if hit:
                qpc = num(hit.group(1))
    conditional = kind == 'leakage' and '按图纸要求' in clean(rule.get('quantity_rule'))
    req = {'request_id': request_id, 'source_item_id': '', 'scheme_group_id': gid, 'scope_type': clean(rule.get('scope_type')) or ('circuit' if kind in {'main_breaker', 'branch_breaker', 'isolator', 'recloser', 'leakage'} else 'auxiliary'), 'circuit_id': '', 'symbol': '', 'component_role': clean(rule.get('component_role')) or clean(rule.get('category')), 'category_path': clean(rule.get('category')), 'shown_model': '', 'drawing_parameters': {}, 'protocol_parameters': {}, 'requirements': {'rated_voltage_v': num(project.get('system_voltage_v')) if kind in {'main_breaker', 'branch_breaker', 'isolator', 'recloser', 'surge', 'surge_backup', 'leakage'} else None, 'rated_current_min_a': num(group.get('main_current_a')) if kind in {'main_breaker', 'isolator', 'recloser', 'leakage'} else None, 'pole_count': clean(group.get('pole_count')) if kind in {'main_breaker', 'branch_breaker', 'isolator', 'recloser', 'surge', 'surge_backup', 'leakage'} else '', 'breaking_capacity_min_ka': num(project.get('short_circuit_capacity_min_ka')) if kind == 'main_breaker' else None, 'leakage_required': True if kind == 'leakage' else None, 'leakage_current_ma': None, 'installation_mode': clean(project.get('installation_mode')), 'operation_mode': '', 'control_voltage': '', 'required_accessories': [], 'brand_constraints': project.get('brand_requirements') if isinstance(project.get('brand_requirements'), list) else []}, 'quantity_per_cabinet': qpc, 'cabinet_quantity': None, 'project_quantity': None, 'unit': clean(params.get('unit')) or default_unit(kind), 'hard_constraints': [], 'preferences': [], 'source_evidence': {'drawing': [], 'protocol': [rule.get('evidence')] if rule.get('evidence') else []}, 'matched_protocol_rule_ids': [clean(rule.get('rule_id'))] if clean(rule.get('rule_id')) else [], 'candidate_protocol_rule_ids': [], 'mapping_status': 'PROTOCOL_ONLY', 'handling_mode': handling_for_kind(kind, has_drawing=False, conditional=conditional), 'retrieval_required': False, 'missing_parameters': [], 'search_keywords': [clean(rule.get('component_role')), clean(rule.get('category'))], 'functional_position': ''}
    merge_rule_into_requirement(req, rule, group, project)
    req['mapping_status'] = 'PROTOCOL_ONLY'
    spec = clean(params.get('model') or params.get('model_name') or params.get('specification') or params.get('spec') or params.get('规格/型号') or params.get('规格型号') or params.get('型号') or params.get('规格'))
    if spec:
        req['shown_model'] = spec
        if spec not in req['search_keywords']:
            req['search_keywords'].insert(0, spec)
    if clean(rule.get('scope_type')) == 'auxiliary' and spec and (qpc is not None):
        req['handling_mode'] = 'BOM_DIRECT'
        req['retrieval_required'] = False
        req['missing_parameters'] = []
    return req

def user_leakage_confirmation(supplementary_notes):
    t = clean(supplementary_notes)
    if not t or '漏电' not in t:
        return None
    if re.search('漏电.{0,12}(不需要|不配置|无需|取消|无)', t) or re.search('(不需要|不配置|无需|取消).{0,12}漏电', t):
        return False
    if re.search('漏电.{0,12}(需要|配置|保留|有)', t) and (not re.search('漏电.{0,12}(不需要|不配置|无需)', t)):
        return True
    return None

def make_requirements__stage_1(data, drawing, protocol, selections, pmap, issues, supplementary_notes='', raw_protocol_text=''):
    project = protocol.get('project_requirements') if isinstance(protocol.get('project_requirements'), dict) else {}
    _, rule_by_id, rules_by_kind = rule_index(protocol)
    proposal_by_source, proposal_by_rule, _ = proposal_indexes(data)
    dgroups = drawing.get('scheme_groups') if isinstance(drawing.get('scheme_groups'), list) else []
    selmap = {clean(s.get('scheme_group_id')): s for s in selections if isinstance(s, dict)}
    requirements = []
    req_counter = 0
    for group in dgroups:
        if not isinstance(group, dict):
            continue
        gid = clean(group.get('scheme_group_id'))
        sel = selmap.get(gid, {})
        pg = pmap.get(clean(sel.get('protocol_scheme_id')), {}) if sel.get('match_status') == 'UNIQUE' else {}
        cabinet_qty = num(pg.get('cabinet_quantity')) if pg else None
        items = all_drawing_items(group)
        req_by_kind = {}
        matched_rule_ids = set()
        for item in items:
            req_counter += 1
            req = make_base_requirement(gid, item, project, 'REQ-%03d' % req_counter)
            kind = item_kind(item)
            req['handling_mode'] = handling_for_kind(kind, has_drawing=True)
            req['retrieval_required'] = req['handling_mode'] == 'PRODUCT_SELECTION'
            apply_group_defaults(req, group, kind)
            proposal = proposal_by_source.get((gid, clean(item.get('item_id'))), {})
            if isinstance(proposal, dict):
                if proposal_user_confirmed(proposal, supplementary_notes):
                    if isinstance(proposal.get('requirements'), dict):
                        for k, v in proposal.get('requirements', {}).items():
                            if v not in (None, '', [], {}):
                                req['requirements'][k] = v
                    if num(proposal.get('quantity_per_cabinet')) is not None:
                        req['quantity_per_cabinet'] = num(proposal.get('quantity_per_cabinet'))
                    if clean(proposal.get('category_path')):
                        req['category_path'] = clean(proposal.get('category_path'))
            explicit_rules = []
            symbol = clean(req.get('symbol')).upper()
            if symbol:
                for rule in protocol_rules(protocol):
                    if not isinstance(rule, dict):
                        continue
                    allowed = rule.get('applicable_protocol_scheme_ids')
                    if isinstance(allowed, list) and allowed and (clean(sel.get('protocol_scheme_id')) not in [clean(x) for x in allowed]):
                        continue
                    ps = rule.get('parameters') if isinstance(rule.get('parameters'), dict) else {}
                    if clean(ps.get('bit_number') or ps.get('symbol')).upper() == symbol:
                        explicit_rules.append(rule)
            if len(explicit_rules) == 1:
                er = explicit_rules[0]
                em = clean((er.get('parameters') or {}).get('model'))
                dm = clean(req.get('shown_model'))
                if em and dm and (em.upper().replace(' ', '') != dm.upper().replace(' ', '')):
                    add_issue(issues, 'BLOCKER', '协议与图纸中%s型号不一致：协议%s，图纸%s' % (symbol, em, dm), gid, req['request_id'], stage='技术参数冲突', blocks_retrieval=True)
                else:
                    merge_rule_into_requirement(req, er, group, project)
                    matched_rule_ids.update(req.get('matched_protocol_rule_ids', []))
                    if not dm and em:
                        req['shown_model'] = em
            if kind in {'isolator', 'recloser', 'surge', 'surge_backup', 'metering_space', 'pe_bar', 'neutral_bar', 'gland', 'hardware', 'label', 'leakage'}:
                candidates = rules_by_kind.get(kind, [])
                if len(candidates) == 1:
                    merge_rule_into_requirement(req, candidates[0], group, project)
                    matched_rule_ids.update(req.get('matched_protocol_rule_ids', []))
                    req['mapping_status'] = 'MATCHED'
            if kind == 'generic_breaker':
                breaker_rules = rules_by_kind.get('main_breaker', []) + rules_by_kind.get('branch_breaker', [])
                matched_explicit = [r for r in explicit_rules if clean(r.get('rule_id')) in req.get('matched_protocol_rule_ids', [])]
                accepted = len(matched_explicit) == 1
                if accepted:
                    req['handling_mode'] = 'PRODUCT_SELECTION'
                    req['retrieval_required'] = True
                    req['mapping_status'] = 'MATCHED'
                if proposal_user_confirmed(proposal, supplementary_notes):
                    proposed_ids = [clean(x) for x in proposal.get('matched_protocol_rule_ids', []) if clean(x) in rule_by_id]
                    proposed_breaker_ids = [x for x in proposed_ids if rule_kind(rule_by_id[x]) in {'main_breaker', 'branch_breaker'}]
                    if len(proposed_breaker_ids) == 1:
                        merge_rule_into_requirement(req, rule_by_id[proposed_breaker_ids[0]], group, project)
                        matched_rule_ids.add(proposed_breaker_ids[0])
                        req['mapping_status'] = 'MATCHED'
                        accepted = True
                if not accepted and len(breaker_rules) <= 1 and clean(req.get('shown_model')) and raw_protocol_text and (clean(req.get('shown_model')).upper() in raw_protocol_text.upper()):
                    req['handling_mode'] = 'PRODUCT_SELECTION'
                    req['retrieval_required'] = True
                    req['mapping_status'] = 'MATCHED'
                    req['source_evidence'].setdefault('protocol', []).append({'page_index': None, 'section': '原始协议文本命中，页码未定位', 'text': '协议列示QF同型号: ' + clean(req.get('shown_model'))})
                    accepted = True
                if not accepted:
                    req['candidate_protocol_rule_ids'] = [clean(r.get('rule_id')) for r in breaker_rules if clean(r.get('rule_id'))]
                    req['mapping_status'] = 'NEED_REVIEW'
                    req['handling_mode'] = 'HUMAN_CONFIRM'
                    req['retrieval_required'] = False
                    req['missing_parameters'].append('断路器功能位置/类别映射')
                    for br in breaker_rules:
                        rid = clean(br.get('rule_id')) or '候选规则'
                        req['protocol_parameters'][rid] = br.get('parameters') if isinstance(br.get('parameters'), dict) else {}
                        if br.get('evidence'):
                            req['source_evidence'].setdefault('protocol', []).append(br.get('evidence'))
                    if len(breaker_rules) >= 2:
                        add_issue(issues, 'BLOCKER', '图纸仅明确一个QF断路器，但协议同时规定主进线塑壳断路器和出线小型断路器；请确认QF对应哪一功能位置，以及另一保护器件是否缺失', gid, req['request_id'], stage='功能映射', blocks_retrieval=True)
                    else:
                        add_issue(issues, 'WARNING', '%s断路器类别/功能位置未能从图纸文字唯一确定' % (clean(req.get('component_role')) or 'QF'), gid, req['request_id'], stage='功能映射')
            if kind == 'internal_conductor':
                req['handling_mode'] = 'BOM_DIRECT'
                req['retrieval_required'] = False
            req['cabinet_quantity'] = cabinet_qty
            qpc = num(req.get('quantity_per_cabinet'))
            req['project_quantity'] = qpc * cabinet_qty if qpc is not None and cabinet_qty is not None else None
            req['quantity'] = req['project_quantity']
            requirements.append(req)
            req_by_kind.setdefault(kind, []).append(req)
        for rule in rules_by_kind.get('internal_conductor', []):
            rid = clean(rule.get('rule_id'))
            if rid in matched_rule_ids:
                continue
            wire_items = [x for x in items if item_kind(x) == 'internal_conductor']
            req_counter += 1
            req = make_protocol_requirement(gid, rule, group, project, 'REQ-%03d' % req_counter)
            req['handling_mode'] = 'BOM_REVIEW'
            req['retrieval_required'] = False
            req['mapping_status'] = 'MATCHED' if wire_items else 'PROTOCOL_ONLY'
            if wire_items:
                req['shown_model'] = ' / '.join(dict.fromkeys((clean(x.get('shown_model')) for x in wire_items if clean(x.get('shown_model')))))
                req['source_evidence']['drawing'] = [x.get('evidence') for x in wire_items if x.get('evidence')]
                req['drawing_parameters'] = {'图纸规格': req['shown_model']}
            req['quantity_per_cabinet'] = quantity_from_rule(rule, group)
            req['missing_parameters'] = ['各规格具体长度/根数']
            req['cabinet_quantity'] = cabinet_qty
            req['project_quantity'] = cabinet_qty if cabinet_qty is not None else None
            req['quantity'] = req['project_quantity']
            requirements.append(req)
            matched_rule_ids.add(rid)
            add_issue(issues, 'WARNING', '箱内导线/铜排已识别规格，但采购前仍需确认各规格具体长度或根数', gid, req['request_id'], stage='BOM数量')
        for rule in protocol_rules(protocol):
            if not isinstance(rule, dict):
                continue
            rid = clean(rule.get('rule_id'))
            kind = rule_kind(rule)
            if rid and rid in matched_rule_ids:
                continue
            if kind in {'main_breaker', 'branch_breaker'} and req_by_kind.get('generic_breaker'):
                continue
            if kind == 'internal_conductor':
                continue
            req_counter += 1
            req = make_protocol_requirement(gid, rule, group, project, 'REQ-%03d' % req_counter)
            req['cabinet_quantity'] = cabinet_qty
            req['project_quantity'] = num(req.get('quantity_per_cabinet')) * cabinet_qty if num(req.get('quantity_per_cabinet')) is not None and cabinet_qty is not None else None
            req['quantity'] = req['project_quantity']
            if kind == 'leakage' and '按图纸要求' in clean(rule.get('quantity_rule')):
                decision = user_leakage_confirmation(supplementary_notes)
                proposals = proposal_by_rule.get((gid, rid), []) if rid else []
                confirmed_proposal = next((p for p in proposals if proposal_user_confirmed(p, supplementary_notes)), None)
                if decision is False or (isinstance(confirmed_proposal, dict) and confirmed_proposal.get('confirmed_presence') is False):
                    req['handling_mode'] = 'EXCLUDED'
                    req['retrieval_required'] = False
                    req['mapping_status'] = 'CONFIRMED_NOT_REQUIRED'
                    req['quantity_per_cabinet'] = 0
                    req['project_quantity'] = 0
                    req['quantity'] = 0
                elif decision is True or (isinstance(confirmed_proposal, dict) and confirmed_proposal.get('confirmed_presence') is True):
                    req['handling_mode'] = 'PRODUCT_SELECTION'
                    req['retrieval_required'] = True
                    req['mapping_status'] = 'USER_CONFIRMED'
                    if isinstance(confirmed_proposal, dict):
                        if num(confirmed_proposal.get('quantity_per_cabinet')) is not None:
                            req['quantity_per_cabinet'] = num(confirmed_proposal.get('quantity_per_cabinet'))
                        if clean(confirmed_proposal.get('circuit_id')):
                            req['circuit_id'] = clean(confirmed_proposal.get('circuit_id'))
                        if isinstance(confirmed_proposal.get('requirements'), dict):
                            for k, v in confirmed_proposal.get('requirements', {}).items():
                                if v not in (None, '', [], {}):
                                    req['requirements'][k] = v
                    if req.get('quantity_per_cabinet') is None:
                        req['missing_parameters'].append('每柜数量')
                else:
                    req['handling_mode'] = 'HUMAN_CONFIRM'
                    req['retrieval_required'] = False
                    req['mapping_status'] = 'NEED_REVIEW'
                    req['missing_parameters'] += ['是否配置漏电保护', '动作电流', '延时时间', '每柜数量']
                    add_issue(issues, 'BLOCKER', '协议规定漏电保护按图纸要求，但当前图纸未明确对应器件；请确认是否配置漏电保护，如配置请补充动作电流、延时和每柜数量', gid, req['request_id'], stage='保护配置', blocks_retrieval=True)
            if kind == 'terminal' and req.get('quantity_per_cabinet') is None:
                req['handling_mode'] = 'BOM_REVIEW'
                req['retrieval_required'] = False
                req['missing_parameters'].append('每柜实际数量')
                add_issue(issues, 'WARNING', '协议要求接线端子按实际回路配置，但图纸未给出可直接统计的端子数量；请确认每柜数量和规格', gid, req['request_id'], stage='BOM数量')
            requirements.append(req)
            if rid:
                matched_rule_ids.add(rid)
        for req in requirements:
            if clean(req.get('scheme_group_id')) != gid:
                continue
            kinds = [rule_kind(rule_by_id[rid]) for rid in req.get('matched_protocol_rule_ids', []) if rid in rule_by_id]
            if 'recloser' in kinds and any(('动作值' in combined_text(rule_by_id.get(rid, {})) or '整定值' in combined_text(rule_by_id.get(rid, {})) for rid in req.get('matched_protocol_rule_ids', []))):
                proposal = proposal_by_source.get((gid, clean(req.get('source_item_id'))), {})
                user_supplied_action = proposal_user_confirmed(proposal, supplementary_notes) and any((k in (proposal.get('requirements') or {}) for k in ['overvoltage_action_v', 'undervoltage_action_v', 'action_value']))
                if not user_supplied_action:
                    if '动作值参数' not in req['missing_parameters']:
                        req['missing_parameters'].append('动作值参数')
                    add_issue(issues, 'WARNING', '自动重合闸保护器的过压/欠压等动作值需按协议确认', gid, req['request_id'], stage='保护参数')
            if 'surge_backup' in kinds:
                if '具体参数待产品库匹配' not in req['missing_parameters']:
                    req['missing_parameters'].append('具体参数待产品库匹配')
    for req in requirements:
        gid = clean(req.get('scheme_group_id'))
        qpc = num(req.get('quantity_per_cabinet'))
        cq = num(req.get('cabinet_quantity'))
        if qpc is not None and cq is not None:
            req['project_quantity'] = qpc * cq
            req['quantity'] = req['project_quantity']
        handling = clean(req.get('handling_mode'))
        if handling == 'PRODUCT_SELECTION':
            req['retrieval_required'] = True
        elif handling in {'HUMAN_CONFIRM', 'BOM_DIRECT', 'BOM_REVIEW', 'SPACE_ONLY', 'EXCLUDED'}:
            req['retrieval_required'] = False
        if handling == 'PRODUCT_SELECTION' and (not clean(req.get('component_role'))):
            add_issue(issues, 'BLOCKER', '产品选型项缺少元器件名称', gid, req.get('request_id'), stage='产品选型', blocks_retrieval=True)
        if handling == 'PRODUCT_SELECTION' and (not clean(req.get('category_path'))) and (not clean(req.get('shown_model'))):
            add_issue(issues, 'BLOCKER', '%s缺少可用于产品检索的类别和图示型号' % (clean(req.get('component_role')) or '产品选型项'), gid, req.get('request_id'), stage='产品选型', blocks_retrieval=True)
        if cq is None:
            add_issue(issues, 'BLOCKER', '%s缺少协议项目柜体数量' % (clean(req.get('component_role')) or '需求项'), gid, req.get('request_id'), stage='数量', blocks_retrieval=True)
    return requirements

def requirement_label(request_id, requirements):
    rid = clean(request_id)
    if not rid:
        return ''
    for r in requirements:
        if not isinstance(r, dict) or clean(r.get('request_id')) != rid:
            continue
        role, symbol, model = (clean(r.get('component_role')), clean(r.get('symbol')), clean(r.get('shown_model')))
        if role and symbol:
            return '%s（%s）' % (role, symbol)
        if role and model:
            return '%s（%s）' % (role, model)
        return role or symbol or model or '该需求'
    return '该需求'

def humanize_issue_message(message, request_id, requirements):
    msg = clean(message)
    rid = clean(request_id)
    if rid:
        msg = msg.replace(rid, requirement_label(rid, requirements) or '该需求')
    msg = re.sub('REQ-\\d+', '该需求', msg, flags=re.I)
    for old, new in {'circuit_id': '回路编号', 'scheme_group_id': '方案组编号', 'mapping_status': '映射状态', 'source_item_id': '图纸物料关联'}.items():
        msg = msg.replace(old, new)
    return msg

def display_issues(issues, requirements):
    grouped, order = ({}, [])
    for x in issues:
        if not isinstance(x, dict):
            continue
        msg = clean(x.get('message'))
        if not msg or msg.startswith('模型提示潜在差异：') or msg.startswith('模型提示') or (clean(x.get('stage')) == '模型提示'):
            continue
        actionable = clean(x.get('severity')).upper() == 'BLOCKER' or any((k in msg for k in ['确认', '缺少', '未明确', '未给出', '不一致', '差异', '冲突', '数量', '长度', '根数', '映射', '待产品库']))
        if not actionable:
            continue
        rid = clean(x.get('request_id'))
        gid = clean(x.get('scheme_group_id'))
        stage = clean(x.get('stage')) or '人工确认'
        label = '系统解析错误（需重新上传/维护）' if stage == '系统解析异常' else requirement_label(rid, requirements) or gid or '总体'
        key = (stage, rid or label)
        if key not in grouped:
            grouped[key] = {'severity': clean(x.get('severity')).upper() or 'WARNING', 'stage': stage, 'label': label, 'messages': []}
            order.append(key)
        if clean(x.get('severity')).upper() == 'BLOCKER':
            grouped[key]['severity'] = 'BLOCKER'
        hm = humanize_issue_message(msg, rid, requirements)
        if hm not in grouped[key]['messages']:
            grouped[key]['messages'].append(hm)
    return [{'severity': grouped[k]['severity'], 'stage': grouped[k]['stage'], 'label': grouped[k]['label'], 'message': '；'.join(grouped[k]['messages'])} for k in order]

def build_review(protocol, drawing, selections, requirements, conflicts, issues, status, summary):
    visible_issues = display_issues(issues, requirements)
    lines = ['## 资料问题确认', '', '| 序号 | 关联位置 | 问题类型 | 问题说明 | 对后续的影响 | 工程师确认/补充 |', '|---:|---|---|---|---|---|']
    if visible_issues:
        for i, issue in enumerate(visible_issues, 1):
            location = clean(issue.get('label')) or clean(issue.get('scheme_group_id')) or clean(issue.get('request_id')) or '总体'
            blocked = bool(issue.get('blocks_retrieval')) or clean(issue.get('severity')).upper() == 'BLOCKER'
            impact = '阻断产品选型；确认后需重新运行' if blocked else '需要工程师核对；不自动作为正式依据'
            lines.append('| %d | %s | %s | %s | %s |  |' % (i, location, severity_cn(issue.get('severity')), clean(issue.get('message')), impact))
    else:
        lines.append('| 1 | 总体 | 信息 | 当前未发现阻断问题 | 可继续进入产品选型 |  |')
    return '\n'.join(lines)

def recover_protocol_auxiliary_rows(raw_text, requirements, selections, pmap, project, issues):
    return requirements

def _original_main(llm_text: str, protocol_text: str='', drawing_text: str='', supplementary_notes: str='', raw_protocol_text: str='') -> dict:
    issues = []
    protocol = parse_object(protocol_text)
    drawing = parse_object(drawing_text)
    data = parse_object(llm_text)
    if not protocol:
        add_issue(issues, 'BLOCKER', '技术协议提取结果为空或不是合法JSON', stage='输入数据', blocks_retrieval=True)
    if not drawing:
        add_issue(issues, 'BLOCKER', '图纸规范化结果为空或不是合法JSON', stage='输入数据', blocks_retrieval=True)
    if not data:
        data = {}
        add_issue(issues, 'WARNING', '语义映射模型输出为空，已改用代码规则构建需求；人工确认项可能增加', stage='系统提示')
    selections, pmap = calculate_scheme_selections(drawing, protocol, issues)
    conflicts = code_conflicts(drawing, protocol, selections, pmap, issues)
    requirements = make_requirements(data, drawing, protocol, selections, pmap, issues, supplementary_notes, raw_protocol_text)
    requirements = recover_protocol_auxiliary_rows(raw_protocol_text, requirements, selections, pmap, protocol.get('project_requirements') or {}, issues)

    def equivalent_protocol_and_drawing(protocol_row, drawing_row):
        if clean(protocol_row.get('scheme_group_id')) != clean(drawing_row.get('scheme_group_id')):
            return False
        role = clean(protocol_row.get('component_role'))
        if not role or role != clean(drawing_row.get('component_role')):
            return False
        pm = clean(protocol_row.get('shown_model')).upper().replace(' ', '').replace('²', '2').replace('×', 'X')
        dm = clean(drawing_row.get('shown_model')).upper().replace(' ', '').replace('²', '2').replace('×', 'X')
        if pm and dm and (pm == dm):
            return True
        if role == '膨胀螺栓' and pm and dm and dm.endswith(pm):
            return True
        if role == '成套柜体' and (not pm) and dm:
            params = protocol_row.get('protocol_parameters') if isinstance(protocol_row.get('protocol_parameters'), dict) else {}
            dim = clean(params.get('dimensions_mm') or params.get('dimensions') or params.get('size'))
            if not dim:
                for inner in params.values():
                    if isinstance(inner, dict):
                        dim = clean(inner.get('dimensions_mm') or inner.get('dimensions') or inner.get('size'))
                        if dim:
                            break
            dim = dim.upper().replace(' ', '').replace('×', 'X')
            return bool(dim) and dim == dm.upper()
        return False
    structured = [r for r in requirements if isinstance(r, dict) and clean(r.get('source_item_id'))]
    consolidated = []
    for row in requirements:
        if not isinstance(row, dict):
            continue
        if clean(row.get('source_item_id')):
            consolidated.append(row)
            continue
        candidates = [existing for existing in structured if equivalent_protocol_and_drawing(row, existing)]
        if len(candidates) != 1:
            consolidated.append(row)
            continue
        target = candidates[0]
        pq, dq = (num(row.get('quantity_per_cabinet')), num(target.get('quantity_per_cabinet')))
        if pq is not None and dq is not None and (pq != dq):
            add_issue(issues, 'BLOCKER', '协议与图纸同规格物料数量冲突：%s %s，协议%s，图纸%s' % (clean(target.get('component_role')), clean(target.get('shown_model')), pq, dq), clean(target.get('scheme_group_id')), clean(target.get('request_id')), stage='数量冲突', blocks_retrieval=True)
            consolidated.append(row)
            continue
        if pq is not None and dq is None:
            target['quantity_per_cabinet'] = pq
            cq = num(target.get('cabinet_quantity'))
            target['project_quantity'] = pq * cq if cq is not None else None
            target['quantity'] = target['project_quantity']
        evidence = row.get('source_evidence') if isinstance(row.get('source_evidence'), dict) else {}
        to_evidence = target.setdefault('source_evidence', {})
        for k in ('protocol', 'drawing'):
            dest = to_evidence.setdefault(k, [])
            for ev in evidence.get(k, []) if isinstance(evidence.get(k), list) else []:
                if ev and ev not in dest:
                    dest.append(ev)
        for field in ('matched_protocol_rule_ids', 'candidate_protocol_rule_ids', 'hard_constraints', 'preferences'):
            dest = target.setdefault(field, [])
            for v in row.get(field, []) if isinstance(row.get(field), list) else []:
                if v not in dest:
                    dest.append(v)
        for field in ('protocol_parameters', 'requirements'):
            dst = target.setdefault(field, {})
            src = row.get(field) if isinstance(row.get(field), dict) else {}
            for key, val in src.items():
                if val in (None, '', [], {}):
                    continue
                if key not in dst or dst[key] in (None, '', [], {}):
                    dst[key] = val
                elif field == 'requirements' and isinstance(dst[key], (int, float)) and isinstance(val, (int, float)) and (dst[key] != val):
                    add_issue(issues, 'BLOCKER', '协议与图纸元器件参数不一致：%s %s %s' % (clean(target.get('component_role')), clean(target.get('shown_model')), key), clean(target.get('scheme_group_id')), clean(target.get('request_id')), stage='技术参数冲突', blocks_retrieval=True)
        target['mapping_status'] = 'MATCHED'
    requirements = consolidated
    modeled_by_key = {}
    for req in requirements:
        if not isinstance(req, dict):
            continue
        if clean(req.get('source_item_id')) and clean(req.get('shown_model')):
            key = (clean(req.get('scheme_group_id')), clean(req.get('component_role')), num(req.get('project_quantity')))
            modeled_by_key.setdefault(key, []).append(req)
    used_targets = set()
    merged_requirements = []
    for req in requirements:
        if not isinstance(req, dict):
            continue
        is_shadow = not clean(req.get('source_item_id')) and (not clean(req.get('shown_model'))) and (clean(req.get('mapping_status')).upper() == 'PROTOCOL_ONLY')
        key = (clean(req.get('scheme_group_id')), clean(req.get('component_role')), num(req.get('project_quantity')))
        candidates = [x for x in modeled_by_key.get(key, []) if id(x) not in used_targets]
        if is_shadow and candidates:
            target = candidates[0]
            used_targets.add(id(target))
            for field in ('matched_protocol_rule_ids', 'candidate_protocol_rule_ids', 'hard_constraints', 'preferences'):
                dest = target.setdefault(field, [])
                for value in req.get(field, []) if isinstance(req.get(field), list) else []:
                    if value not in dest:
                        dest.append(value)
            for field in ('protocol_parameters',):
                dest = target.setdefault(field, {})
                src = req.get(field) if isinstance(req.get(field), dict) else {}
                for name, value in src.items():
                    if name not in dest:
                        dest[name] = value
            ev = req.get('source_evidence') if isinstance(req.get('source_evidence'), dict) else {}
            dest_ev = target.setdefault('source_evidence', {}).setdefault('protocol', [])
            for value in ev.get('protocol', []) if isinstance(ev.get('protocol'), list) else []:
                if value and value not in dest_ev:
                    dest_ev.append(value)
            continue
        merged_requirements.append(req)
    requirements = merged_requirements
    seen_key = {}
    sanitized = []
    for req in requirements:
        if not isinstance(req, dict):
            continue
        sym = clean(req.get('symbol')).upper()
        mod = clean(req.get('shown_model')).upper().replace(' ', '')
        gid = clean(req.get('scheme_group_id'))
        if sym and mod:
            key = (gid, sym, mod)
            if key in seen_key:
                prev = seen_key[key]
                if clean(prev.get('circuit_id')) == clean(req.get('circuit_id')):
                    if num(prev.get('quantity_per_cabinet')) != num(req.get('quantity_per_cabinet')):
                        add_issue(issues, 'BLOCKER', '%s %s重复来源数量不一致' % (sym, mod), gid, req.get('request_id'), stage='技术参数冲突', blocks_retrieval=True)
                    else:
                        prev.setdefault('source_evidence', {}).setdefault('protocol', []).extend(req.get('source_evidence', {}).get('protocol', []))
                    continue
            seen_key[key] = req
        sanitized.append(req)
    requirements = sanitized

    def explicit_configuration_text(req):
        pieces = []
        pp = req.get('protocol_parameters') if isinstance(req.get('protocol_parameters'), dict) else {}
        for value in pp.values():
            if isinstance(value, dict):
                for key in ('configuration_status', '配置状态', 'status', 'note', '说明'):
                    if clean(value.get(key)):
                        pieces.append(clean(value.get(key)))
        ev = req.get('source_evidence') if isinstance(req.get('source_evidence'), dict) else {}
        for item in ev.get('protocol', []) if isinstance(ev.get('protocol'), list) else []:
            if isinstance(item, dict) and clean(item.get('text')):
                pieces.append(clean(item.get('text')))
        return '；'.join(pieces)

    def has_explicit_exclusion(text):
        return bool(re.search('不配置|不包含|不提供|无需配置|取消配置|严禁.{0,12}(?:补入|配置)', clean(text)))
    for req in requirements:
        if not isinstance(req, dict):
            continue
        role = clean(req.get('component_role'))
        category = clean(req.get('category_path'))
        explicit_text = explicit_configuration_text(req)
        if not has_explicit_exclusion(explicit_text):
            continue
        is_meter = '电能表' in role or '电能表' in category
        is_space_only = is_meter and bool(re.search('仅预留|预留.{0,8}(?:安装)?空间|表位', explicit_text))
        req['handling_mode'] = 'SPACE_ONLY' if is_space_only else 'EXCLUDED'
        req['retrieval_required'] = False
        req['mapping_status'] = 'SPACE_RESERVED_BY_SOURCE' if is_space_only else 'EXCLUDED_BY_SOURCE'
        req['quantity_per_cabinet'] = 0
        req['project_quantity'] = 0
        req['quantity'] = 0
        req['missing_parameters'] = []
        requirements_map = req.get('requirements') if isinstance(req.get('requirements'), dict) else {}
        if '漏电' in role or '漏电' in category:
            requirements_map['leakage_required'] = False
        req['requirements'] = requirements_map
    for req in requirements:
        if not isinstance(req, dict):
            continue
        mode = clean(req.get('handling_mode'))
        if mode in {'EXCLUDED', 'SPACE_ONLY'}:
            continue
        quantity = num(req.get('project_quantity'))
        if quantity is None or quantity <= 0:
            add_issue(issues, 'BLOCKER', '物料%s缺少合法项目数量，请核对技术协议和图纸' % (clean(req.get('component_role')) or clean(req.get('request_id'))), clean(req.get('scheme_group_id')), clean(req.get('request_id')), stage='数量完整性', blocks_retrieval=True)
            continue
        if mode in {'BOM_DIRECT', 'BOM_REVIEW'} and clean(req.get('shown_model')):
            req['handling_mode'] = 'PRODUCT_SELECTION'
            req['retrieval_required'] = True
            req['search_keywords'] = [clean(req.get('shown_model')), clean(req.get('component_role')), clean(req.get('category_path'))]
    for c in data.get('potential_conflicts', []) if isinstance(data.get('potential_conflicts'), list) else []:
        add_issue(issues, 'WARNING', '模型提示潜在差异：%s' % clean(c), stage='模型提示')
    for w in data.get('warnings', []) if isinstance(data.get('warnings'), list) else []:
        add_issue(issues, 'WARNING', clean(w), stage='模型提示')
    retrieval_requirements = [r for r in requirements if isinstance(r, dict) and r.get('retrieval_required') is True]
    retrieval_blockers = [x for x in issues if x.get('blocks_retrieval') is True]
    status = 'VALID' if not retrieval_blockers and retrieval_requirements else 'NEED_REVIEW'
    visible_issues = display_issues(issues, requirements)
    visible_blockers = sum((1 for x in visible_issues if clean(x.get('severity')).upper() == 'BLOCKER'))
    visible_warnings = len(visible_issues) - visible_blockers
    unique_count = sum((1 for s in selections if isinstance(s, dict) and clean(s.get('match_status')).upper() == 'UNIQUE'))
    drawing_group_count = len(drawing.get('scheme_groups', []) if isinstance(drawing.get('scheme_groups'), list) else [])
    summary = '协议方案%d个，图纸方案%d个，已唯一匹配%d/%d；产品库待选%d项；人工确认%d项（阻断%d项、提示%d项）。' % (len(protocol_groups(protocol)), drawing_group_count, unique_count, drawing_group_count, len(retrieval_requirements), len(visible_issues), visible_blockers, visible_warnings)
    payload = {'schema_version': 'component-selection-request-v5', 'validation_status': status, 'scheme_selections': selections, 'project_requirements': protocol.get('project_requirements', {}), 'protocol_scheme_groups': protocol_groups(protocol), 'component_rules': protocol_rules(protocol), 'drawing_scheme_groups': drawing.get('scheme_groups', []), 'component_requirements': requirements, 'retrieval_requirements': retrieval_requirements, 'conflicts': conflicts, 'issues': issues}
    return {'validation_status': status, 'validation_message': '；'.join((x.get('message', '') for x in issues)) if issues else '图纸、协议方案和需求结构校验通过', 'selection_request_json': json.dumps(payload, ensure_ascii=False), 'requirements_json': json.dumps(requirements, ensure_ascii=False), 'requirements': requirements, 'requirement_count': len(requirements), 'retrieval_requirements_json': json.dumps(retrieval_requirements, ensure_ascii=False), 'retrieval_requirements': retrieval_requirements, 'retrieval_count': len(retrieval_requirements), 'request_summary': summary, 'requirement_review_markdown': build_review(protocol, drawing, selections, requirements, conflicts, issues, status, summary), 'requirement_review_filename': '协议图纸资料问题确认单_V11.1.xlsx', 'pricing_gate': 'READY_FOR_PRODUCT_RETRIEVAL' if status == 'VALID' else 'BLOCKED_REQUIREMENT_REVIEW'}

def main__stage_1(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    output = _original_main(llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text)
    full = wire_loads(output['selection_request_json'])
    requirements = wire_loads(output['requirements_json'])
    if len(requirements) > _BATCH_MAX or len(plain_json(requirements).encode('utf-8')) > 140000:
        output['requirements'] = []
    active = [r for r in requirements if isinstance(r, dict) and r.get('handling_mode') not in ('EXCLUDED', 'SPACE_ONLY')]
    message = check_array_budget(active)
    if len(output.get('requirement_review_markdown', '').encode('utf-8')) > 45000:
        message = '问题说明展开后超过本版显示预算，请按柜号或回路分批；完整上下文未作截断。'
    if message:
        full['capacity_blocked'] = True
        full['capacity_message'] = message
        output.update(validation_status='NEED_REVIEW', pricing_gate='BLOCKED_CAPACITY', validation_message=message, request_summary=message, retrieval_requirements=[], retrieval_requirements_json='[]', retrieval_count=0, requirements=[], requirement_review_markdown=capacity_markdown(message))
    try:
        output['selection_request_json'] = wire_pack(full)
        output['requirements_json'] = wire_pack(requirements)
        output['retrieval_requirements_json'] = wire_pack(output['retrieval_requirements'])
        if len(output['validation_message'].encode('utf-8')) > 45000:
            output['validation_message'] = '详细问题较多，已完整保存在内部上下文，请下载确认单核对；未删除需求或问题。'
    except CapacityError as exc:
        message = str(exc)
        output.update(validation_status='NEED_REVIEW', pricing_gate='BLOCKED_CAPACITY', validation_message=message, request_summary=message, requirements=[], retrieval_requirements=[], requirements_json='[]', retrieval_requirements_json='[]', retrieval_count=0, selection_request_json=plain_json({'capacity_blocked': True, 'context_available': False, 'capacity_message': message}), requirement_review_markdown=capacity_markdown(message))
    return output
import copy
_previous_item_kind = item_kind__stage_1
_previous_rule_kind = rule_kind__stage_1
_previous_make_requirements = make_requirements__stage_1
_previous_main = main__stage_1
_previous_code_conflicts = code_conflicts__stage_1
_previous_merge_rule = merge_rule_into_requirement__stage_1

def merge_rule_into_requirement(req, rule, group, project):
    before = copy.deepcopy(req.get('requirements') or {})
    _previous_merge_rule(req, rule, group, project)
    params = rule.get('parameters') or {}
    actual = num(before.get('rated_current_a') or before.get('rated_current_min_a'))
    expected = num(params.get('rated_current_a'))
    if actual is not None and expected is not None and (actual != expected):
        req.setdefault('source_parameter_conflicts', []).append({'parameter': 'rated_current_a', 'drawing_value': actual, 'protocol_value': expected, 'rule_id': rule.get('rule_id')})
        req['requirements']['rated_current_min_a'] = actual

def rule_kind__stage_2(rule):
    role = clean(rule.get('component_role')) + ' ' + clean(rule.get('category'))
    if ('防雷' in role or '浪涌' in role or 'SPD' in role.upper()) and ('断路器' in role or '后备' in role or ('保护器' in role and '后备' in role)):
        return 'surge_backup'
    if '铜线' in role or ('电缆' in role and '接头' not in role):
        return 'internal_conductor'
    if '电表支架' in role or '表位' in role or '表架' in role:
        return 'metering_bracket'
    return _previous_rule_kind(rule)

def item_kind(item):
    role = clean(item.get('component_role')) + ' ' + clean(item.get('category'))
    if '表架' in role or '电表支架' in role:
        return 'metering_bracket'
    return _previous_item_kind(item)

def candidate_groups(group, protocol, selections):
    gid = clean(group.get('scheme_group_id'))
    selection = next((x for x in selections if clean(x.get('scheme_group_id')) == gid), {})
    if selection.get('match_status') == 'UNIQUE':
        return [p for p in protocol_groups(protocol) if p.get('protocol_scheme_id') == selection.get('protocol_scheme_id')]
    return [p for p in protocol_groups(protocol) if scheme_match(group, p)[0]]

def allowed_rule(rule, group_ids):
    allowed = rule.get('applicable_protocol_scheme_ids')
    return not isinstance(allowed, list) or not allowed or bool(set(map(clean, allowed)) & group_ids)

def same_part_role__stage_1(req, rule):
    role = clean(req.get('component_role'))
    other = clean(rule.get('component_role'))
    aliases = [('箱体', '柜体'), ('铜线', '导线'), ('表架', '电表支架', '电表安装支架', '表位支架')]
    if role == other:
        return True
    category = clean(rule.get('category_path') or rule.get('category'))
    if role == '断路器' and any((x in other + ' ' + category for x in ('微型断路器', '小型断路器'))) and ('防雷' not in other):
        return True
    return any((any((a in role for a in group)) and any((a in other for a in group)) for group in aliases))

def code_conflicts(drawing, protocol, selections, pmap, issues):
    conflicts = _previous_code_conflicts(drawing, protocol, selections, pmap, issues)
    groups = {clean(g.get('scheme_group_id')): g for g in drawing.get('scheme_groups', [])}
    for selection in selections:
        if selection.get('match_status') != 'UNIQUE':
            continue
        group = groups.get(clean(selection.get('scheme_group_id')), {})
        pg = pmap.get(clean(selection.get('protocol_scheme_id')), {})
        left = pg.get('cabinet_size_mm') or pg.get('cabinet_dimensions_mm')
        right = group.get('cabinet_size_mm') or group.get('cabinet_dimensions_mm')
        parse = lambda v: re.findall('\\d+(?:\\.\\d+)?', clean(v))
        if left and right and (parse(left) != parse(right)):
            gid = clean(group.get('scheme_group_id'))
            add_issue(issues, 'BLOCKER', '适用协议与图纸的箱体尺寸不一致：协议%s，图纸%s；需明确文件优先级或变更记录' % (clean(left), clean(right)), gid, stage='协议图纸差异', blocks_retrieval=True)
            conflicts.append({'scheme_group_id': gid, 'item': '箱体尺寸', 'protocol_value': left, 'drawing_value': right, 'severity': 'BLOCKER'})
    return conflicts

def make_requirements(data, drawing, protocol, selections, pmap, issues, supplementary_notes='', raw_protocol_text=''):
    all_requirements = []
    allocated_request_ids = 0
    groups = drawing.get('scheme_groups') if isinstance(drawing.get('scheme_groups'), list) else []
    for group in groups:
        gid = clean(group.get('scheme_group_id'))
        candidates = candidate_groups(group, protocol, selections)
        ids = {clean(p.get('protocol_scheme_id')) for p in candidates}
        scoped = copy.deepcopy(protocol)
        scoped['component_rules'] = [copy.deepcopy(r) for r in protocol_rules(protocol) if isinstance(r, dict) and allowed_rule(r, ids)]
        conditional = []
        common = []
        for rule in scoped['component_rules']:
            allowed = rule.get('applicable_protocol_scheme_ids')
            if len(ids) > 1 and isinstance(allowed, list) and allowed and (not ids.issubset(set(map(clean, allowed)))):
                conditional.append(rule)
            else:
                common.append(rule)
        scoped['component_rules'] = common
        subset = {'scheme_groups': [copy.deepcopy(group)]}
        subgroup = subset['scheme_groups'][0]
        copied_selections = [copy.deepcopy(s) for s in selections if s.get('scheme_group_id') == gid]
        known_count = None
        if len(candidates) == 1:
            known_count = num(candidates[0].get('cabinet_quantity'))
            if candidates[0].get('cabinet_quantity_basis') in ('CONFIGURATION_SAMPLE', 'PER_CABINET'):
                known_count = None
        if num(group.get('project_cabinet_quantity')) is not None:
            drawing_count = num(group['project_cabinet_quantity'])
            if known_count is not None and drawing_count != known_count:
                add_issue(issues, 'BLOCKER', '协议与图纸的项目柜数不一致，需确认实际订货数量', gid, stage='项目柜数冲突', blocks_retrieval=True)
            known_count = drawing_count
        quantity_basis = 'PROJECT' if known_count is not None and known_count > 0 else 'PER_CABINET'
        calc_count = known_count if quantity_basis == 'PROJECT' else 1
        local_pmap = copy.deepcopy(pmap)
        if copied_selections and copied_selections[0].get('match_status') == 'UNIQUE':
            pid = copied_selections[0].get('protocol_scheme_id')
            local_pmap.setdefault(pid, {})['cabinet_quantity'] = calc_count
        else:
            copied_selections = [{'scheme_group_id': gid, 'match_status': 'UNIQUE', 'protocol_scheme_id': '__CALCULATION_SCOPE__'}]
            local_pmap['__CALCULATION_SCOPE__'] = {'cabinet_quantity': calc_count}
        explicit_breakers = set()
        global item_kind
        base_item_kind = item_kind

        def model_aware_kind(item):
            if clean(item.get('item_id')) in explicit_breakers:
                return 'branch_breaker'
            return base_item_kind(item)
        item_kind = model_aware_kind
        before = len(issues)
        try:
            rows = _previous_make_requirements(data, subset, scoped, copied_selections, local_pmap, issues, supplementary_notes, raw_protocol_text)
        finally:
            item_kind = base_item_kind
        remap = {r['request_id']: 'REQ-%03d' % (allocated_request_ids + i + 1) for i, r in enumerate(rows)}
        allocated_request_ids += len(rows)
        for issue in issues[before:]:
            if issue.get('request_id') in remap:
                issue['request_id'] = remap[issue['request_id']]
        drawing_rows = [r for r in rows if clean(r.get('source_item_id'))]
        retained = []
        for req in rows:
            req['request_id'] = remap[req['request_id']]
            req['quantity_basis'] = quantity_basis
            req['project_cabinet_quantity'] = known_count
            req['calculation_cabinet_count'] = calc_count
            req['cabinet_quantity'] = calc_count
            req['applicable_protocol_candidates'] = sorted(ids)
            req['protocol_scope_confirmed'] = len(ids) == 1
            if clean(req.get('source_item_id')) in explicit_breakers:
                req['category_path'] = '断路器'
                req['handling_mode'] = 'PRODUCT_SELECTION'
                req['retrieval_required'] = True
                req['mapping_status'] = 'DRAWING_MODEL_SPECIFIED'
                req['missing_parameters'] = [x for x in req.get('missing_parameters', []) if x != '断路器功能位置/类别映射']
            if not clean(req.get('source_item_id')):
                peers = [r for r in drawing_rows if same_part_role(r, req)]
                if clean(req.get('shown_model')) and rule_kind(req) != 'internal_conductor':
                    peers = [r for r in peers if identity_spec(r.get('shown_model')) == identity_spec(req['shown_model'])]
                if len(peers) > 1 and rule_kind(req) not in ('internal_conductor', 'metering_bracket'):
                    peers = []
                if peers:
                    pq = num(req.get('quantity_per_cabinet'))
                    count_conflicts = [peer for peer in peers if rule_kind(req) != 'internal_conductor' and clean(req.get('shown_model')) and (pq is not None) and (num(peer.get('quantity_per_cabinet')) is not None) and (pq != num(peer.get('quantity_per_cabinet')))]
                    if count_conflicts:
                        for peer in count_conflicts:
                            add_issue(issues, 'BLOCKER', '同规格物料协议每柜数量%s与图纸%s不一致，不能自动合并或相加' % (pq, peer.get('quantity_per_cabinet')), gid, peer['request_id'], stage='数量冲突', blocks_retrieval=True)
                if peers:
                    for peer in peers:
                        peer.setdefault('protocol_requirements_evidence', []).append(copy.deepcopy(req))
                        restore_peer_protocol_evidence(peer, req)
                        for rid in req.get('matched_protocol_rule_ids', []):
                            if rid not in peer['matched_protocol_rule_ids']:
                                peer['matched_protocol_rule_ids'].append(rid)
                        peer.setdefault('protocol_parameters', {}).update(req.get('protocol_parameters', {}))
                        actual = num((peer.get('requirements') or {}).get('rated_current_a') or (peer.get('requirements') or {}).get('rated_current_min_a'))
                        expected = next((num(p.get('rated_current_a')) for p in req.get('protocol_parameters', {}).values() if isinstance(p, dict) and num(p.get('rated_current_a')) is not None), None)
                        if expected is not None and actual is not None and (actual != expected):
                            add_issue(issues, 'BLOCKER', '同一功能器件协议额定电流%sA与图纸%sA不一致，不能自动替代' % (expected, actual), gid, peer['request_id'], stage='技术参数冲突', blocks_retrieval=True)
                    continue
            if req.get('handling_mode') in ('SPACE_ONLY', 'EXCLUDED'):
                req['retrieval_required'] = False
                retained.append(req)
                continue
            if num(req.get('quantity_per_cabinet')) is None:
                req['handling_mode'] = 'BOM_REVIEW'
                req['retrieval_required'] = False
                if '每柜实际用量（长度/根数/件数）' not in req['missing_parameters']:
                    req['missing_parameters'].append('每柜实际用量（长度/根数/件数）')
                add_issue(issues, 'WARNING', clean(req.get('component_role')) + '已保留规格，每柜实际用量未明确；不妨碍其他已知器件候选检索，正式报价前必须补齐', gid, req['request_id'], stage='单柜用量')
            if '表架' in clean(req.get('component_role')) or '支架' in clean(req.get('component_role')):
                attrs = req.get('drawing_parameters', {})
                if re.search('(?<![A-Za-z0-9])M\\d+\\s*[*×xX]\\s*\\d+', clean(attrs), re.I):
                    req['missing_parameters'].append('表格行列归属')
                    add_issue(issues, 'WARNING', '支架记录出现螺纹尺寸，疑似相邻紧固件信息串行；请确认原表行列归属，不据此认定支架材质', gid, req['request_id'], stage='表格关联')
            retained.append(req)
        for req in retained:
            for difference in req.get('source_parameter_conflicts', []):
                add_issue(issues, 'BLOCKER', '同一功能器件协议额定电流%sA与图纸%sA不一致，不能自动替代' % (difference['protocol_value'], difference['drawing_value']), gid, req['request_id'], stage='技术参数冲突', blocks_retrieval=True)
        if quantity_basis == 'PER_CABINET':
            add_issue(issues, 'WARNING', gid + '需确认项目数量口径：尚无项目柜数，本轮按单柜用量整理；不代表项目订货1台，项目总量及总报价前需补柜数', gid, stage='计量口径')
        if conditional:
            add_issue(issues, 'WARNING', '部分协议条款只适用于尚未确认的其他配置，已保留为候选，未自动新增对应器件', gid, stage='条款适用')
        all_requirements.extend(retained)
    return all_requirements

def build_generic_context(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    output = _previous_main(llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text)
    payload = wire_loads(output['selection_request_json'])
    if payload.get('capacity_blocked'):
        return output
    reqs = payload.get('component_requirements', [])
    old_issues = payload.get('issues', [])
    ids = {clean(r.get('request_id')) for r in reqs}
    issues = []
    for issue in old_issues:
        if issue.get('stage') in ('数量', '数量完整性'):
            continue
        if issue.get('request_id') and issue['request_id'] not in ids:
            continue
        if issue.get('stage') == '模型提示':
            issue = dict(issue, severity='WARNING', blocks_retrieval=False)
        issues.append(issue)
    for req in reqs:
        qpc = num(req.get('quantity_per_cabinet'))
        if req.get('quantity_basis') == 'PER_CABINET':
            req['cabinet_quantity'] = None
            req['project_quantity'] = None
            req['quantity'] = qpc
        if req.get('handling_mode') in ('SPACE_ONLY', 'EXCLUDED'):
            continue
        if qpc is not None and qpc <= 0:
            add_issue(issues, 'BLOCKER', '元器件每柜用量必须大于0，不能凭空补成1', req.get('scheme_group_id'), req['request_id'], stage='实际用量异常', blocks_retrieval=True)
            req['retrieval_required'] = False
        if qpc is None and (not any((i.get('request_id') == req['request_id'] and i.get('stage') == '单柜用量' for i in issues))):
            add_issue(issues, 'WARNING', '每柜用量尚未明确；保留该行，正式报价前必须补齐，不按1套猜测', req.get('scheme_group_id'), req['request_id'], stage='单柜用量')
        if num(req.get('quantity')) is None:
            req['retrieval_required'] = False
    retrieval = [r for r in reqs if r.get('retrieval_required') is True]
    payload['issues'] = issues
    payload['retrieval_requirements'] = retrieval
    visible = display_issues(issues, reqs)
    blockers = sum((i.get('severity') == 'BLOCKER' for i in visible))
    status = 'NEED_REVIEW' if any((i.get('blocks_retrieval') for i in issues)) or not retrieval else 'VALID'
    summary = '协议配置候选%d种，图纸方案%d个；已整理%d项需求，可检索%d项；待确认问题%d类（阻断%d类、提示%d类）。' % (len(payload.get('protocol_scheme_groups', [])), len(payload.get('drawing_scheme_groups', [])), len(reqs), len(retrieval), len(visible), blockers, len(visible) - blockers)
    if any((r.get('quantity_basis') == 'PER_CABINET' for r in reqs)):
        summary += ' 当前为单柜计量，不代表项目总柜数或项目总报价。'
    payload.update(validation_status=status, quantity_scope='PER_CABINET' if any((r.get('quantity_basis') == 'PER_CABINET' for r in reqs)) else 'PROJECT')
    output.update(validation_status=status, validation_message='；'.join(dict.fromkeys((i.get('message', '') for i in visible))), request_summary=summary, selection_request_json=wire_pack(payload), requirements_json=wire_pack(reqs), requirements=reqs if len(reqs) <= _BATCH_MAX else [], requirement_count=len(reqs), retrieval_requirements=retrieval, retrieval_count=len(retrieval), retrieval_requirements_json=wire_pack(retrieval), pricing_gate='READY_FOR_PRODUCT_RETRIEVAL' if status == 'VALID' else 'BLOCKED_REQUIREMENT_REVIEW', requirement_review_markdown=build_review({}, {}, payload.get('scheme_selections', []), reqs, payload.get('conflicts', []), issues, status, summary))
    return output

def main__stage_2(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    return build_generic_context(llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text)
import math
_v1511_main = main__stage_2
_v1511_num = num__stage_1
_v1511_all_drawing_items = all_drawing_items__stage_1

def num(value):
    value = _v1511_num(value)
    return value if value is not None and math.isfinite(value) else None

def normalize_poles(value):
    text = clean(value).upper().replace(' ', '').replace('＋', '+')
    match = re.fullmatch('([1-5])(?:P|极)(\\+N)?', text)
    if match:
        return match.group(1) + 'P' + (match.group(2) or '')
    return text

def material_grades(value):
    text = clean(value).upper()
    if not any((word in text for word in ('不锈钢', 'STAINLESS', ' SS', 'SUS'))):
        return set()
    return set(re.findall('(?<!\\d)(\\d{3})(?!\\d)', text))

def all_drawing_items(group):
    group = copy.deepcopy(group)
    circuit_rows = {}
    for circuit in group.get('circuits', []) if isinstance(group.get('circuits'), list) else []:
        if not isinstance(circuit, dict):
            continue
        for row in circuit.get('components', []) if isinstance(circuit.get('components'), list) else []:
            if isinstance(row, dict) and clean(row.get('item_id')):
                circuit_rows.setdefault(clean(row['item_id']), row)
    for row in group.get('drawing_items', []) if isinstance(group.get('drawing_items'), list) else []:
        if not isinstance(row, dict):
            continue
        target = circuit_rows.get(clean(row.get('item_id')))
        if target is None:
            continue
        for key, value in row.items():
            if key == 'shown_parameters' and isinstance(value, dict):
                dst = target.setdefault(key, {})
                if isinstance(dst, dict):
                    for name, fact in value.items():
                        if dst.get(name) in (None, ''):
                            dst[name] = fact
            elif key == 'evidence' and value:
                evidence = target.get('evidence')
                previous = evidence if isinstance(evidence, list) else [evidence] if evidence else []
                extra = value if isinstance(value, list) else [value]
                target[key] = previous + [e for e in extra if e not in previous]
            elif target.get(key) in (None, '') and value not in (None, ''):
                target[key] = value
    return _v1511_all_drawing_items(group)
_COUNT_UNITS = {'台', '件', '只', '个', '套', '根', '支', '块', '颗', '处', '组'}

def quantity_error(value, *, integer=False):
    if value is None or value == '':
        return ''
    parsed = num(value)
    if isinstance(value, bool) or parsed is None or parsed <= 0:
        return '必须为大于零的有限数值'
    if integer and parsed != int(parsed):
        return '必须为正整数'
    return ''

def input_problems(protocol, drawing):
    problems = []

    def problem(message, gid=''):
        problems.append((gid, message))
    for data, key, label, id_key in ((protocol, 'scheme_groups', '协议配置', 'protocol_scheme_id'), (drawing, 'scheme_groups', '图纸方案', 'scheme_group_id')):
        groups = data.get(key)
        if not isinstance(groups, list) or not groups:
            problem(label + '列表为空或结构异常；需检查资料提取，不能仅填写采用解除')
            continue
        seen = set()
        for group in groups:
            if not isinstance(group, dict):
                problem(label + '列表含非对象记录；需检查提取节点')
                continue
            ident = clean(group.get(id_key))
            if not ident or ident in seen:
                problem(label + '编号缺失或重复；无法可靠关联配置和器件', ident)
            seen.add(ident)
            if label == '协议配置':
                raw_count = group.get('cabinet_quantity')
                if group.get('cabinet_quantity_basis') not in ('CONFIGURATION_SAMPLE', 'PER_CABINET'):
                    message = quantity_error(raw_count, integer=True)
                    if message:
                        problem('协议项目柜数' + message, ident)
            else:
                message = quantity_error(group.get('project_cabinet_quantity'), integer=True)
                if message:
                    problem('图纸项目柜数' + message, ident)
                sources = []
                if isinstance(group.get('drawing_items'), list):
                    sources += [(r, '') for r in group['drawing_items']]
                for circuit in group.get('circuits', []) if isinstance(group.get('circuits'), list) else []:
                    if not isinstance(circuit, dict):
                        problem('回路列表含非对象记录；需检查提取节点', ident)
                        continue
                    if isinstance(circuit.get('components'), list):
                        sources += [(r, clean(circuit.get('circuit_id'))) for r in circuit['components']]
                item_ids = {}
                for row, circuit_id in sources:
                    if not isinstance(row, dict):
                        problem('元器件列表含非对象记录；需检查提取节点', ident)
                        continue
                    iid = clean(row.get('item_id'))
                    if not iid:
                        problem('图纸元器件缺少来源编号；无法核对表格与回路重复来源', ident)
                    signature = {'circuit_id': circuit_id or clean(row.get('circuit_id')), 'shown_model': clean(row.get('shown_model')).upper().replace(' ', ''), 'quantity_per_cabinet': row.get('quantity_per_cabinet')}
                    if isinstance(row.get('shown_parameters'), dict):
                        signature.update({'param:' + key: value for key, value in row['shown_parameters'].items()})
                    previous = item_ids.get(iid, {})
                    conflicting = any((previous.get(key) not in (None, '') and value not in (None, '') and (clean(previous[key]) != clean(value)) for key, value in signature.items() if key in previous))
                    if iid and conflicting:
                        problem('同一来源编号' + iid + '出现不同回路、型号、数量或参数；不能静默丢弃其中一条', ident)
                    item_ids[iid] = {**previous, **{key: value for key, value in signature.items() if value not in (None, '')}}
                    message = quantity_error(row.get('quantity_per_cabinet'), integer=clean(row.get('unit')) in _COUNT_UNITS)
                    if message:
                        problem('器件' + (iid or clean(row.get('component_role'))) + '每柜用量' + message, ident)
    return problems

def structure_is_unsafe(protocol, drawing):
    for document in (protocol, drawing):
        groups = document.get('scheme_groups', [])
        if not isinstance(groups, list) or any((not isinstance(g, dict) for g in groups)):
            return True
    rules = protocol.get('component_rules', [])
    if not isinstance(rules, list) or any((not isinstance(r, dict) for r in rules)):
        return True
    for group in drawing.get('scheme_groups', []):
        for key in ('drawing_items', 'circuits'):
            rows = group.get(key, [])
            if not isinstance(rows, list) or any((not isinstance(r, dict) for r in rows)):
                return True
        for circuit in group.get('circuits', []):
            rows = circuit.get('components', [])
            if not isinstance(rows, list) or any((not isinstance(r, dict) for r in rows)):
                return True
    return False

def source_differences(req, rules, group):
    """Only compare facts explicitly belonging to the same mapped item."""
    drawing = req.get('drawing_parameters') or {}
    current = num(drawing.get('rated_current_a') or drawing.get('current_a'))
    poles = normalize_poles(drawing.get('pole_count') or drawing.get('poles'))
    differences = []
    minimums = []
    for rid in req.get('matched_protocol_rule_ids', []):
        rule = rules.get(rid, {})
        params = rule.get('parameters') if isinstance(rule.get('parameters'), dict) else {}
        expected = num(params.get('rated_current_a'))
        minimum = num(params.get('rated_current_min_a'))
        if minimum is not None:
            minimums.append(minimum)
        if current is not None:
            if expected is not None and expected != current:
                differences.append('协议额定电流%sA与图纸%sA不一致' % (expected, current))
            if minimum is not None and current < minimum:
                differences.append('图纸额定电流%sA低于协议最低要求%sA' % (current, minimum))
        wanted_poles = normalize_poles(params.get('pole_count') or params.get('poles'))
        if poles and wanted_poles and (poles != wanted_poles):
            differences.append('协议极数%s与图纸%s不一致' % (wanted_poles, poles))
        expected_quantity = num(params.get('quantity_per_cabinet'))
        explicit_position = params.get('bit_number') or params.get('symbol')
        if expected_quantity is None and explicit_position:
            expected_quantity = quantity_from_rule(rule, group)
        actual_quantity = num(req.get('quantity_per_cabinet'))
        if expected_quantity is not None and actual_quantity is not None and (expected_quantity != actual_quantity):
            differences.append('协议每柜数量%s与图纸%s不一致' % (expected_quantity, actual_quantity))
    requirements = req.setdefault('requirements', {})
    if poles:
        requirements['pole_count'] = poles
    if current is not None:
        requirements['rated_current_min_a'] = max([current] + minimums)
    return list(dict.fromkeys(differences))

def publish_checked_output(out, payload, issues):
    reqs = payload.get('component_requirements', [])
    retrieval = [r for r in reqs if r.get('retrieval_required') is True]
    blocked = any((i.get('blocks_retrieval') for i in issues))
    status = 'NEED_REVIEW' if blocked or not retrieval else 'VALID'
    visible = display_issues(issues, reqs)
    blocker_count = sum((i.get('severity') == 'BLOCKER' for i in visible))
    summary = '协议配置候选%d种，图纸方案%d个；整理%d项需求，待确认%d类（阻断%d类、提示%d类）。' % (len(payload.get('protocol_scheme_groups', [])), len(payload.get('drawing_scheme_groups', [])), len(reqs), len(visible), blocker_count, len(visible) - blocker_count)
    if any((r.get('quantity_basis') == 'PER_CABINET' for r in reqs)):
        summary += ' 当前含单柜计量，不代表项目总量。'
    payload.update(issues=issues, validation_status=status, retrieval_requirements=retrieval)
    out.update(validation_status=status, request_summary=summary, validation_message='；'.join(dict.fromkeys((i.get('message', '') for i in visible))), selection_request_json=wire_pack(payload), requirements_json=wire_pack(reqs), requirements=reqs, requirement_count=len(reqs), retrieval_requirements=retrieval, retrieval_count=len(retrieval), retrieval_requirements_json=wire_pack(retrieval), pricing_gate='BLOCKED_REQUIREMENT_REVIEW' if status != 'VALID' else 'READY_FOR_PRODUCT_RETRIEVAL', requirement_review_markdown=build_review({}, {}, payload.get('scheme_selections', []), reqs, payload.get('conflicts', []), issues, status, summary))
    return out

def main__stage_3(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    try:
        protocol, drawing = (parse_object(protocol_text), parse_object(drawing_text))
        problems = input_problems(protocol, drawing)
        structurally_invalid = structure_is_unsafe(protocol, drawing)
        if structurally_invalid:
            problems.append(('', '配置、回路、元器件或规则列表结构异常；请检查提取节点，不要求工程师猜测缺失参数'))
        out = _v1511_main(llm_text, protocol_text if not structurally_invalid else '{}', drawing_text if not structurally_invalid else '{}', supplementary_notes, raw_protocol_text)
        payload = wire_loads(out['selection_request_json'])
    except (ValueError, TypeError, OverflowError) as error:
        out = _v1511_main('{"component_requirements":[]}', '{}', '{}')
        payload = wire_loads(out['selection_request_json'])
        problems = [('', '提取结果无法安全解析或包含非法数值；请检查上游节点，不能仅填写采用解除。' + type(error).__name__)]
    if payload.get('capacity_blocked'):
        return out
    issues = payload.get('issues', [])
    for gid, message in problems:
        add_issue(issues, 'BLOCKER', message, gid, stage='提取结果校验', blocks_retrieval=True)
    rules = {r.get('rule_id'): r for r in payload.get('component_rules', []) if isinstance(r, dict)}
    groups = {g.get('scheme_group_id'): g for g in payload.get('drawing_scheme_groups', []) if isinstance(g, dict)}
    for req in payload.get('component_requirements', []):
        if req.get('handling_mode') in ('EXCLUDED', 'SPACE_ONLY'):
            continue
        for difference in source_differences(req, rules, groups.get(req.get('scheme_group_id'), {})):
            add_issue(issues, 'BLOCKER', difference + '；需明确变更依据，不能以采用覆盖', req.get('scheme_group_id'), req.get('request_id'), stage='技术参数冲突', blocks_retrieval=True)
    return publish_checked_output(out, payload, issues)
_v1512_source_main = main__stage_3
_v1512_source_rule_kind = rule_kind__stage_2

def rule_kind(rule):
    role = clean(rule.get('component_role')) + ' ' + clean(rule.get('category'))
    if '电涌保护器' in role and '后备' not in role:
        return 'surge'
    return _v1512_source_rule_kind(rule)

def main__stage_4(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    try:
        protocol = copy.deepcopy(parse_object(protocol_text))
        for rule in protocol.get('component_rules', []) if isinstance(protocol.get('component_rules'), list) else []:
            if not isinstance(rule, dict) or not isinstance(rule.get('parameters'), dict):
                continue
            params = rule['parameters']
            if not params.get('model') and params.get('required_model'):
                params['model'] = params['required_model']
            if not params.get('bit_number') and params.get('position'):
                params['bit_number'] = params['position']
        protocol_text = wire_pack(protocol)
    except (ValueError, TypeError):
        pass
    out = _v1512_source_main(llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text)
    payload = wire_loads(out['selection_request_json'])
    if payload.get('capacity_blocked'):
        return out
    rows = payload.get('component_requirements', [])
    excluded = {r.get('request_id') for r in rows if r.get('handling_mode') in ('EXCLUDED', 'SPACE_ONLY')}
    issues = [i for i in payload.get('issues', []) if not (i.get('request_id') in excluded and i.get('severity') != 'BLOCKER' and (i.get('stage') == '单柜用量'))]
    rules = {r.get('rule_id'): r for r in payload.get('component_rules', []) if isinstance(r, dict)}
    for row in rows:
        if row.get('handling_mode') in ('EXCLUDED', 'SPACE_ONLY'):
            continue
        uc_values = set()
        for rid in row.get('matched_protocol_rule_ids', []):
            params = rules.get(rid, {}).get('parameters', {})
            if not isinstance(params, dict):
                continue
            uc = next((num(params[key]) for key in ('continuous_operating_voltage_v', 'max_continuous_operating_voltage_v', 'maximum_continuous_operating_voltage_v', 'uc_v') if num(params.get(key)) is not None), None)
            if uc is not None:
                uc_values.add(uc)
        if len(uc_values) > 1:
            add_issue(issues, 'BLOCKER', '同一器件的适用协议包含不同Uc要求，需确认有效条款', row.get('scheme_group_id'), row.get('request_id'), stage='技术参数冲突', blocks_retrieval=True)
        elif uc_values:
            wanted = next(iter(uc_values))
            requirements = row.setdefault('requirements', {})
            actual = num(requirements.get('continuous_operating_voltage_v'))
            raw_voltage = clean((row.get('drawing_parameters') or {}).get('voltage_text'))
            match = re.fullmatch('(?:AC\\s*)?([0-9]+(?:\\.[0-9]+)?)\\s*V', raw_voltage, re.I)
            raw = num(match.group(1)) if match else None
            if actual is not None and actual != wanted:
                add_issue(issues, 'BLOCKER', '协议Uc%sV与图纸明确Uc%sV不一致' % (wanted, actual), row.get('scheme_group_id'), row.get('request_id'), stage='技术参数冲突', blocks_retrieval=True)
            elif actual is None and raw is not None and (raw != wanted):
                add_issue(issues, 'BLOCKER', '协议明确Uc%sV，但图纸另标%s且含义未明；需确认对应关系' % (wanted, raw_voltage), row.get('scheme_group_id'), row.get('request_id'), stage='技术参数冲突', blocks_retrieval=True)
            else:
                requirements['continuous_operating_voltage_v'] = wanted
                row['uc_requirement_source'] = 'APPLICABLE_PROTOCOL'
    return publish_checked_output(out, payload, issues)
_REQUIREMENT_TRANSPORT = 'requirement-envelope-v1'

def requirement_envelope(row):
    if not isinstance(row, dict):
        raise ValueError('需求传递项必须为对象，不能静默忽略')
    return {'transport_schema': _REQUIREMENT_TRANSPORT, 'request_id': str(row.get('request_id') or ''), 'payload_json': wire_pack(row)}

def transport_requirement_arrays(output):
    for name in ('requirements', 'retrieval_requirements'):
        if name in output:
            output[name] = [requirement_envelope(r) for r in output[name]]
    return output
_transport_previous_main = main__stage_4

def main__stage_5(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    return transport_requirement_arrays(_transport_previous_main(llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text))
import unicodedata
_v15121_same_part_role = same_part_role__stage_1

def identity_spec(value):
    text = unicodedata.normalize('NFKC', clean(value)).upper()
    text = text.replace('平方毫米', 'MM2')
    text = re.sub('MM\\s*\\^\\s*2', 'MM2', text)
    return re.sub('\\s+', '', text).replace('×', 'X')

def identity_role(value):
    text = unicodedata.normalize('NFKC', clean(value))

    def remove_spec(match):
        body = match.group(1).strip()
        numeric_spec = re.fullmatch('\\d+(?:\\.\\d+)?\\s*(?:mm2|mm\\^2|平方毫米|mm|ka|ma|kv|a|v|p)', body, re.I)
        return '' if numeric_spec else match.group(0)
    text = re.sub('\\(([^()]*)\\)', remove_spec, text)
    return re.sub('\\s+', '', text).casefold()

def same_part_role(req, rule):
    if _v15121_same_part_role(req, rule):
        return True
    left, right = (identity_role(req.get('component_role')), identity_role(rule.get('component_role')))
    left_spec, right_spec = (identity_spec(req.get('shown_model')), identity_spec(rule.get('shown_model')))
    return bool(left and left == right and left_spec and (left_spec == right_spec))
_semantic_base_main = main__stage_5

def _quantity_text_count(rule, group):
    value = clean(rule.get('quantity_rule')).rstrip('。；;')
    if not value:
        return None
    if re.fullmatch('[1-9]\\d{0,3}(?:\\.0+)?', value):
        return num(value)
    m = re.fullmatch('(?:每柜|每台|每个方案)?\\s*([1-9]\\d{0,3})\\s*(?:个|只|台|套|件|根|块|支|组|处|颗)\\s*(?:[（(]按(?:一|1)台柜计[）)]|/柜|/台)?', value)
    if m:
        return num(m.group(1))
    if value in ('每台一套', '每台一处', '每个方案一套', '每个方案一只', '每柜一套', '每柜一只'):
        return 1
    if re.fullmatch('按主进线回路(?:数量|配置)?', value):
        return num(group.get('incoming_count'))
    if re.fullmatch('按出线回路(?:数量|配置)?', value):
        return num(group.get('outgoing_count'))
    return None

def canonical_wiring(value):
    text = unicodedata.normalize('NFKC', clean(value)).upper().replace(' ', '')
    if text in ('3L+N', '3PH+N', '三相四线', '三相四线制'):
        return '3L+N'
    if text in ('3L', '3PH', '三相三线', '三相三线制'):
        return '3L'
    return text

def canonical_device_poles(value):
    text = unicodedata.normalize('NFKC', clean(value)).upper().replace(' ', '')
    aliases = {'单极': '1P', '一极': '1P', '双极': '2P', '两极': '2P', '二极': '2P', '三极': '3P', '四极': '4P'}
    text = aliases.get(text, text)
    return text if re.fullmatch('[1-5]P(?:\\+N)?', text) else ''

def _v163_old_schema_parameters(params, notes):
    if not isinstance(params, dict):
        return
    aliases = {'model': ('required_model', 'designated_model', 'specified_model'), 'bit_number': ('position', 'symbol'), 'continuous_operating_voltage_v': ('max_continuous_operating_voltage_v', 'maximum_continuous_operating_voltage_v', 'uc_v', 'spd_uc_v'), 'breaking_capacity_min_ka': ('breaking_capacity_ka',), 'trip_curve': ('tripping_curve',), 'test_class': ('class', 'test_type', 'test_category')}
    for target, sources in aliases.items():
        values = [params[k] for k in (target,) + sources if params.get(k) not in (None, '')]
        if not values:
            continue
        signature = {('number', num(v)) if target.endswith(('_v', '_ka')) and num(v) is not None else ('text', identity_spec(v).replace('类', '') if target == 'test_class' else identity_spec(v)) for v in values}
        if len(signature) > 1:
            notes.append('同一参数的不同字段给出不同值：' + target + '；' + ' / '.join(map(str, values)))
        elif params.get(target) in (None, ''):
            params[target] = copy.deepcopy(values[0])

def normalize_source_contract(protocol, drawing):
    protocol, drawing = (copy.deepcopy(protocol), copy.deepcopy(drawing))
    notes = []
    project = protocol.get('project_requirements') if isinstance(protocol.get('project_requirements'), dict) else {}
    for document in (protocol, drawing):
        groups = document.get('scheme_groups', [])
        if not isinstance(groups, list):
            continue
        for group in groups:
            if not isinstance(group, dict):
                continue
            legacy = clean(group.get('pole_count'))
            raw = unicodedata.normalize('NFKC', legacy).upper().replace(' ', '')
            evidence = evidence_text(group.get('evidence'))
            global_text = evidence_text(project.get('evidence')) + ' ' + clean(project.get('general_requirements'))
            network_context = evidence + ' ' + global_text
            wiring = group.get('system_wiring') or group.get('wiring_system') or group.get('phase_wiring')
            is_network = raw in ('3L+N', '3PH+N', '三相四线', '三相四线制', '3L', '3PH', '三相三线', '三相三线制')
            if raw == '3P+N' and re.search('(?:接线(?:方式|制式)?|三相四线)[^。\\n]{0,45}(?:3P\\s*\\+\\s*N|TN-S)|接线方式[：:]?\\s*3P\\s*\\+\\s*N', network_context, re.I):
                is_network = True
            if is_network:
                group.setdefault('source_group_pole_text', legacy)
                wiring = wiring or ('3L+N' if raw == '3P+N' else legacy)
                group['pole_count'] = ''
                group['pole_count_source'] = 'NETWORK_TEXT_MIGRATED'
            explicit = canonical_device_poles(group.get('main_device_pole_count'))
            if explicit:
                group['pole_count'] = explicit
            elif canonical_device_poles(group.get('pole_count')):
                group['main_device_pole_count'] = canonical_device_poles(group['pole_count'])
            if wiring:
                group['system_wiring'] = canonical_wiring(wiring)
    rules = protocol.get('component_rules', [])
    for rule in rules if isinstance(rules, list) else []:
        if isinstance(rule, dict):
            schema_parameters(rule.get('parameters'), notes)
    for group in drawing.get('scheme_groups', []) if isinstance(drawing.get('scheme_groups'), list) else []:
        if not isinstance(group, dict):
            continue
        direct = group.get('drawing_items', []) if isinstance(group.get('drawing_items'), list) else []
        circuit_items = [item for circuit in group.get('circuits', []) if isinstance(circuit, dict) for item in circuit.get('components', []) if isinstance(item, dict)] if isinstance(group.get('circuits'), list) else []
        for item in direct + circuit_items:
            if isinstance(item, dict):
                schema_parameters(item.get('shown_parameters'), notes)
    return (protocol, drawing, notes)

def scheme_match(drawing_group, protocol_group):
    """Match like-for-like fields; a network topology is never device poles."""
    matched, mismatched = ([], [])
    chosen = clean(drawing_group.get('confirmed_protocol_scheme_id'))
    if chosen and chosen != clean(protocol_group.get('protocol_scheme_id')):
        return (False, [], ['工程师确认的适用配置'])
    checks = [('main_current_a', '主回路电流', 'number'), ('incoming_count', '进线数量', 'number'), ('outgoing_count', '出线数量', 'number'), ('meter_required', '电表位', 'bool'), ('isolator_count', '隔离开关数量', 'number'), ('leakage_required', '明确的漏电配置', 'bool')]
    for field, label, mode in checks:
        result = compare_equal(drawing_group.get(field), protocol_group.get(field), mode)
        if result is True:
            matched.append(label)
        elif result is False:
            mismatched.append(label)
    left = canonical_device_poles(drawing_group.get('main_device_pole_count') or drawing_group.get('pole_count'))
    right = canonical_device_poles(protocol_group.get('main_device_pole_count') or protocol_group.get('pole_count'))
    if left and right:
        (matched if left == right else mismatched).append('器件极数')
    left = canonical_wiring(drawing_group.get('system_wiring'))
    right = canonical_wiring(protocol_group.get('system_wiring'))
    if left and right:
        (matched if left == right else mismatched).append('系统接线制式')
    a, b = (num(drawing_group.get('power_min_kw')), num(drawing_group.get('power_max_kw')))
    x, y = (num(protocol_group.get('power_min_kw')), num(protocol_group.get('power_max_kw')))
    if all((v is not None for v in (a, b, x, y))):
        (matched if x <= a <= b <= y else mismatched).append('功率范围')
    dm = material_grades(drawing_group.get('cabinet_material'))
    pm = material_grades(protocol_group.get('cabinet_material') or protocol_group.get('scheme_name'))
    if dm and pm:
        (matched if dm & pm else mismatched).append('箱体材质')
    pid = clean(protocol_group.get('protocol_scheme_id'))
    explicit_ids = {clean(drawing_group.get(k)) for k in ('confirmed_protocol_scheme_id', 'protocol_scheme_id', 'source_scheme_id', 'scheme_name')}
    if pid and pid in explicit_ids:
        matched.append('资料方案标识')
    return (not mismatched, matched, mismatched)

def calculate_scheme_selections(drawing, protocol, issues):
    groups = drawing.get('scheme_groups', []) if isinstance(drawing.get('scheme_groups'), list) else []
    pgroups = protocol_groups(protocol)
    selections = []
    pmap = {clean(p.get('protocol_scheme_id')): p for p in pgroups if isinstance(p, dict)}
    if not pgroups:
        add_issue(issues, 'BLOCKER', '技术协议未提取到配置列表；请核查提取节点', stage='方案匹配', blocks_retrieval=True)
    for group in groups:
        if not isinstance(group, dict):
            continue
        gid = clean(group.get('scheme_group_id'))
        candidates = []
        rejected = []
        for pg in pgroups:
            if not isinstance(pg, dict):
                continue
            ok, matched, mismatched = scheme_match(group, pg)
            informative = set(matched) & {'主回路电流', '进线数量', '出线数量', '功率范围', '资料方案标识'}
            if ok and (informative or pg.get('scope_basis') == 'GLOBAL_PROTOCOL'):
                candidates.append((pg, matched))
            else:
                rejected.append((clean(pg.get('protocol_scheme_id')), mismatched or ['缺少可关联的配置事实']))
        identified = [v for v in candidates if '资料方案标识' in v[1]]
        if len(identified) == 1:
            candidates = identified
        selection = {'scheme_group_id': gid, 'match_status': '', 'protocol_scheme_id': '', 'protocol_location': '', 'matching_basis': []}
        if len(candidates) == 1:
            pg, matched = candidates[0]
            selection.update(match_status='UNIQUE', protocol_scheme_id=clean(pg.get('protocol_scheme_id')), protocol_location=evidence_text(pg.get('evidence')), matching_basis=matched)
        elif candidates:
            selection['match_status'] = 'AMBIGUOUS'
            add_issue(issues, 'BLOCKER', gid + '同时匹配多个协议方案：' + '、'.join((clean(p.get('protocol_scheme_id')) for p, _ in candidates)), gid, stage='方案匹配', blocks_retrieval=True)
        else:
            selection.update(match_status='NOT_FOUND', candidate_differences=[{'protocol_scheme_id': pid, 'differences': values} for pid, values in rejected])
            details = '；'.join((pid + '：' + '、'.join(values) for pid, values in rejected[:5]))
            add_issue(issues, 'BLOCKER', gid + '未找到满足已知图纸关键字段的协议方案；具体差异：' + details, gid, stage='方案匹配', blocks_retrieval=True)
        selections.append(selection)
    return (selections, pmap)

def preserve_auxiliary_constraints(payload, issues):
    rules = {r.get('rule_id'): r for r in payload.get('component_rules', []) if isinstance(r, dict)}
    for row in payload.get('component_requirements', []):
        if row.get('handling_mode') in ('EXCLUDED', 'SPACE_ONLY'):
            continue
        requirements = row.setdefault('requirements', {})
        drawing = row.get('drawing_parameters') if isinstance(row.get('drawing_parameters'), dict) else {}
        parameters = [rules[rid].get('parameters', {}) for rid in row.get('matched_protocol_rule_ids', []) if rid in rules]
        parameters = [p for p in parameters if isinstance(p, dict)]
        system_voltage = num((payload.get('project_requirements') or {}).get('system_voltage_v'))
        explicit_voltage = any((num(p.get(k)) is not None for p in [drawing] + parameters for k in ('rated_voltage_v', 'voltage_v')))
        if system_voltage is not None and row.get('scope_type') == 'circuit':
            requirements['system_voltage_v'] = system_voltage
            if not explicit_voltage:
                requirements['rated_voltage_v'] = None
        for key in ('nominal_discharge_current_ka', 'max_discharge_current_ka', 'test_class'):
            found = [p[key] for p in [drawing] + parameters if p.get(key) not in (None, '')]
            variants = {identity_spec(v).replace('类', '') for v in found}
            if len(variants) > 1:
                add_issue(issues, 'BLOCKER', '同一器件协议与图纸的' + key + '不同，需确认变更依据', row.get('scheme_group_id'), row.get('request_id'), stage='技术参数冲突', blocks_retrieval=True)
            elif found:
                requirements[key] = found[0]
        text = clean(row.get('drawing_parameters')) + ' ' + clean(row.get('protocol_parameters'))
        for rid in row.get('matched_protocol_rule_ids', []):
            text += ' ' + clean(rules.get(rid, {}).get('parameters'))
        if re.search('无附加触点|无辅助触点|不带(?:OF\\d*|辅助触点)|禁止(?:附加|辅助)触点', text, re.I):
            requirements['forbidden_accessories'] = ['辅助触点']

def run_semantic_contract(previous, llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    try:
        protocol, drawing, notes = normalize_source_contract(parse_object(protocol_text), parse_object(drawing_text))
        out = previous(llm_text, wire_pack(protocol), wire_pack(drawing), supplementary_notes, raw_protocol_text)
    except (ValueError, TypeError):
        return previous(llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text)
    payload = wire_loads(out['selection_request_json'])
    if payload.get('capacity_blocked'):
        return out
    issues = payload.get('issues', [])
    preserve_auxiliary_constraints(payload, issues)
    for note in notes:
        add_issue(issues, 'BLOCKER', note, stage='字段语义冲突', blocks_retrieval=True)
    quantity_facts = []
    for group in payload.get('protocol_scheme_groups', []):
        if num(group.get('cabinet_quantity')) is not None:
            quantity_facts.append({'source': 'PROTOCOL', 'protocol_scheme_id': group.get('protocol_scheme_id'), 'quantity': group['cabinet_quantity'], 'basis': group.get('cabinet_quantity_basis', 'PROJECT'), 'evidence': group.get('evidence')})
    payload['quantity_facts'] = quantity_facts
    if drawing.get('drawing_validation_status') not in (None, '', 'VALID'):
        add_issue(issues, 'BLOCKER', '图纸前置校验未通过，停止产品选型；请先处理图纸识别问题', stage='图纸前置校验', blocks_retrieval=True)
    blocked_groups = {x.get('scheme_group_id') for x in payload.get('scheme_selections', []) if x.get('match_status') != 'UNIQUE'}
    if quantity_facts:
        for issue in issues:
            if issue.get('stage') == '计量口径' and issue.get('scheme_group_id') in blocked_groups:
                issue['message'] = '协议已提取柜数事实，但当前配置尚未唯一关联；先处理方案差异，不应要求重复补填资料中已有的柜数。'
    out = publish_checked_output(out, payload, issues)
    return transport_requirement_arrays(out)

def main__v16_before_1(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    return run_semantic_contract(_semantic_base_main, llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text)

def compare_extension(left, right):
    """Only call typed values incompatible; prose needs semantic/human review."""
    if isinstance(left, (int, float, bool)) and isinstance(right, (int, float, bool)):
        return 'SAME' if left == right else 'CONFLICT'

    def atom(v):
        m = re.fullmatch('\\s*(AC|DC)?\\s*([0-9]+(?:\\.[0-9]+)?)\\s*(kV|V|mA|kA|A|Hz|kW|W|mm²|mm2|mm|cm|m)\\s*', str(v), re.I)
        if not m:
            return None
        unit = m.group(3).lower()
        family, scale = {'kv': ('V', 1000), 'v': ('V', 1), 'ma': ('A', 0.001), 'ka': ('A', 1000), 'a': ('A', 1), 'hz': ('Hz', 1), 'kw': ('W', 1000), 'w': ('W', 1), 'mm': ('mm', 1), 'cm': ('mm', 10), 'm': ('mm', 1000), 'mm²': ('mm2', 1), 'mm2': ('mm2', 1)}[unit]
        return ((m.group(1) or '').upper(), float(m.group(2)) * scale, family)
    a, b = (atom(left), atom(right))
    if a and b:
        same = a[2] == b[2] and abs(a[1] - b[1]) < 1e-09 and (not a[0] or not b[0] or a[0] == b[0])
        return 'SAME' if same else 'CONFLICT'
    return 'TEXT'

def generic_item_kind(item):
    if not isinstance(item, dict):
        return 'other'
    text = ' '.join((str(item.get(k) or '') for k in ('component_role', 'category', 'functional_position')))
    if re.search('后备保护|后备断路|浪涌前级|防雷前级|surge.*backup', text, re.I):
        return 'surge_backup'
    if re.search('电涌保护|浪涌保护|surge protective', text, re.I):
        return 'surge'
    if '自动重合闸' in text or '重合闸保护' in text:
        return 'recloser'
    if '隔离开关' in text:
        return 'isolator'
    if '漏电' in text:
        return 'leakage'
    if '塑壳断路器' in text:
        return 'main_breaker'
    if '小型断路器' in text or '微型断路器' in text:
        return 'branch_breaker'
    if '断路器' in text:
        return 'generic_breaker'
    if '计量安装位' in text or '电能表安装位' in text or '仅预留表位' in text:
        return 'metering_space'
    if '电能表' in text:
        return 'meter'
    if '接地排' in text or 'PE排' in text:
        return 'pe_bar'
    if '零线排' in text:
        return 'neutral_bar'
    if '箱内导线' in text or '铜排' in text:
        return 'internal_conductor'
    if '接线端子' in text:
        return 'terminal'
    if '防水接头' in text:
        return 'gland'
    if '门锁' in text or '铰链' in text:
        return 'hardware'
    if '铭牌' in text or '标识' in text:
        return 'label'
    return 'other'
item_kind = generic_item_kind
_v16_requirement_base = main__v16_before_1

def _v163_root_base(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    out = _v16_requirement_base(llm_text, protocol_text, drawing_text, supplementary_notes, raw_protocol_text)
    payload = wire_loads(out['selection_request_json'])
    if payload.get('capacity_blocked'):
        return out
    issues = payload.get('issues', [])
    for label, text in [('协议', protocol_text), ('图纸', drawing_text), ('语义关联', llm_text)]:
        source = parse_object(text)
        for problem in source.get('_document_errors', []):
            add_issue(issues, 'BLOCKER', label + '来源或处理不完整：' + str(problem), stage='来源完整性', blocks_retrieval=True)
    rules = {r.get('rule_id'): r for r in payload.get('component_rules', []) if isinstance(r, dict)}
    for row in payload.get('component_requirements', []):
        if row.get('handling_mode') in ('EXCLUDED', 'SPACE_ONLY'):
            continue
        requirements = row.setdefault('requirements', {})
        parameters = [row.get('drawing_parameters', {})] + [rules[r].get('parameters', {}) for r in row.get('matched_protocol_rule_ids', []) if r in rules]
        existing_keys = set(requirements)
        for parameter in parameters:
            if not isinstance(parameter, dict):
                continue
            for key, value in parameter.items():
                if key not in requirements and value not in (None, '', [], {}):
                    requirements[key] = copy.deepcopy(value)
                elif key not in existing_keys and value not in (None, '', [], {}) and (requirements.get(key) not in (None, '', [], {})) and (identity_spec(requirements[key]) != identity_spec(value)):
                    left, right = (identity_spec(requirements[key]), identity_spec(value))
                    comparison = compare_extension(requirements[key], value)
                    if comparison == 'SAME':
                        pass
                    elif comparison == 'TEXT' and left in right:
                        requirements[key] = copy.deepcopy(value)
                    elif comparison == 'TEXT' and right in left:
                        pass
                    else:
                        incompatible = comparison == 'CONFLICT'
                        message = '扩展参数来源有差异：' + str(key) + '，图纸/前序值=' + clean(requirements[key]) + '，协议/后序值=' + clean(value)
                        add_issue(issues, 'BLOCKER' if incompatible else 'WARNING', message, row.get('scheme_group_id'), row.get('request_id'), stage='扩展参数冲突' if incompatible else '扩展描述复核', blocks_retrieval=incompatible)
                        if not incompatible:
                            requirements[key] = [requirements[key], copy.deepcopy(value)]
        if num(row.get('quantity')) is not None and num(row['quantity']) > 0:
            row['handling_mode'] = 'PRODUCT_SELECTION'
            row['retrieval_required'] = True
        if not clean(row.get('unit')):
            add_issue(issues, 'BLOCKER', '物料缺少计量单位', row.get('scheme_group_id'), row.get('request_id'), stage='数量单位', blocks_retrieval=True)
    payload['retrieval_requirements'] = [r for r in payload.get('component_requirements', []) if r.get('retrieval_required')]
    out = publish_checked_output(out, payload, issues)
    return transport_requirement_arrays(out)

def parameter_token(value):
    return re.sub('[\\s_\\-（）()]+', '', unicodedata.normalize('NFKC', str(value))).casefold()

def canonical_physical_fields(params, notes):
    if not isinstance(params, dict):
        return
    groups = {'continuous_operating_voltage_v': ('uc_v', 'spd_uc_v', 'max_continuous_operating_voltage_v', 'maximum_continuous_operating_voltage_v', 'Uc电压', '最大持续运行电压'), 'max_discharge_current_ka': ('imax_ka', 'Imax', '最大放电电流'), 'nominal_discharge_current_ka': ('in_ka', '标称放电电流')}
    for target, aliases in groups.items():
        tokens = {parameter_token(k) for k in (target,) + aliases}
        keys = [k for k in params if parameter_token(k) in tokens and params[k] not in (None, '')]
        if not keys:
            continue
        normalized = []
        for k in keys:
            text = str(params[k]).strip()
            m = re.fullmatch('([0-9]+(?:\\.[0-9]+)?)\\s*(V|kV|kA|A)?', text, re.I)
            if m:
                value = float(m.group(1))
                unit = (m.group(2) or '').casefold()
                if target.endswith('_v') and unit == 'kv':
                    value *= 1000
                elif target.endswith('_ka') and unit == 'a':
                    value /= 1000
                elif unit and unit not in (('v', 'kv') if target.endswith('_v') else ('a', 'ka')):
                    value = ('invalid_unit', text)
                if isinstance(value, float) and value.is_integer():
                    value = int(value)
            else:
                value = ('text', parameter_token(text))
            normalized.append(value)
        if any((v != normalized[0] for v in normalized[1:])) or isinstance(normalized[0], tuple):
            notes.append('参数别名的值或单位不一致：' + target + '；' + ' / '.join((str(params[k]) for k in keys)))
            continue
        params[target] = normalized[0]
        for k in keys:
            if k != target:
                params.pop(k, None)

def audit_cabinet_entry(protocol, raw_text):
    """Retain a missed labelled source row as unverified text, not an inferred value."""
    protocol = copy.deepcopy(protocol)
    project = protocol.setdefault('project_requirements', {})
    if not isinstance(project, dict):
        return protocol
    field = 'cabinet_cable_entry_exit'
    if project.get(field):
        return protocol
    groups = [g for g in protocol.get('scheme_groups', []) if isinstance(g, dict)]
    if groups and all((g.get(field) for g in groups)):
        return protocol
    raw = str(raw_text or '').replace('\r\n', '\n').replace('\r', '\n')
    pattern = '(?:进线电缆孔|电缆(?:进出线|进出|进线|出线)(?:方向|方式|位置)|进出线(?:方向|位置|方式))'
    rows = []
    offset = 0
    for line in raw.splitlines(keepends=True):
        if re.search(pattern, line):
            text = line.strip()
            if text and text not in [r['text'] for r in rows]:
                rows.append({'text': text, 'source_start': offset + len(line) - len(line.lstrip()), 'source_end': offset + len(line.rstrip()), 'page_index': None, 'source_type': 'RAW_PROTOCOL_ROW'})
        offset += len(line)
    if not rows:
        return protocol
    project['unmapped_cabinet_entry_requirements'] = rows
    if len(groups) == 1:
        project['cabinet_cable_entry_exit_source_text'] = '；'.join((r['text'] for r in rows))
        project['cabinet_cable_entry_exit_review'] = '原文明确存在进出线要求，但模型未结构化；保留原文待工程师核对，不作为元器件接线方式'
    return protocol

def schema_parameters(params, notes):
    canonical_physical_fields(params, notes)
    return _v163_old_schema_parameters(params, notes)

def main(llm_text, protocol_text='', drawing_text='', supplementary_notes='', raw_protocol_text=''):
    try:
        protocol = preserve_document_facts(normalize_rule_quantities(audit_cabinet_entry(parse_object(protocol_text), raw_protocol_text)), 'PROTOCOL', raw_protocol_text)
        drawing = preserve_document_facts(parse_object(drawing_text), 'DRAWING')
        out = _v163_root_base(llm_text, wire_pack(protocol), wire_pack(drawing), supplementary_notes, raw_protocol_text)
        payload = wire_loads(out['selection_request_json'])
        if payload.get('capacity_blocked'):
            return out
        issues = payload.get('issues', [])
        project = protocol.get('project_requirements', {})
        payload['quantity_resolution_audit'] = copy.deepcopy(protocol.get('quantity_resolution_audit', []))
        context = {k: copy.deepcopy(project[k]) for k in ('cabinet_cable_entry_exit', 'cabinet_cable_entry_exit_source_text', 'cabinet_cable_entry_exit_review', 'unmapped_cabinet_entry_requirements') if project.get(k)}
        if project.get('unmapped_cabinet_entry_requirements'):
            add_issue(issues, 'WARNING', '协议原文的柜体电缆进出线要求未结构化，已保留原文供工程师确认；不能当作缺失或套为每个器件接线方式', stage='原文覆盖审计')
        groups = {g.get('protocol_scheme_id'): g for g in protocol.get('scheme_groups', []) if isinstance(g, dict)}
        rules = {r.get('rule_id'): r for r in contract_rows(protocol.get('component_rules')) if isinstance(r, dict)}
        drawing_items = {}
        for group in contract_rows(drawing.get('scheme_groups')):
            if not isinstance(group, dict):
                continue
            members = contract_rows(group.get('drawing_items')) + contract_rows(group.get('shown_bom'))
            for circuit in contract_rows(group.get('circuits')):
                if isinstance(circuit, dict):
                    members += contract_rows(circuit.get('components'))
            for item in members:
                if isinstance(item, dict):
                    drawing_items[group.get('scheme_group_id'), item.get('item_id')] = item
        for row in payload.get('component_requirements', []):
            ledger = []
            sources = [rules[r] for r in row.get('matched_protocol_rule_ids', []) if r in rules]
            sources.append(drawing_items.get((row.get('scheme_group_id'), row.get('source_item_id')), {}))
            for source in sources:
                for fact in source.get('parameter_facts', []):
                    if fact not in ledger:
                        ledger.append(copy.deepcopy(fact))
            row['parameter_facts'] = ledger
            row['project_context'] = copy.deepcopy(context)
            category = clean(row.get('component_role')) + ' ' + clean(row.get('category_path'))
            if any((word in category for word in ('柜体', '箱体'))):
                requirement = row.setdefault('requirements', {})
                value = project.get('cabinet_cable_entry_exit')
                scoped = [groups[r] for r in row.get('applicable_protocol_candidates', []) if r in groups]
                if len(scoped) == 1:
                    value = scoped[0].get('cabinet_cable_entry_exit') or value
                if value:
                    requirement['cabinet_cable_entry_exit'] = copy.deepcopy(value)
                elif project.get('cabinet_cable_entry_exit_source_text'):
                    requirement['cabinet_cable_entry_exit_source_text'] = project['cabinet_cable_entry_exit_source_text']
        payload = preserve_cabinet_context(payload, drawing, protocol)
        payload = preserve_source_units_and_structure(payload, drawing, protocol, issues)
        out = publish_checked_output(out, payload, issues)
        return transport_requirement_arrays(out)
    except CapacityError as exc:
        return requirement_capacity_response(str(exc))

def quantity_number(value):
    if isinstance(value, bool) or value in (None, ''):
        return None
    try:
        number = float(value)
    except (ValueError, TypeError, OverflowError):
        return None
    if not math.isfinite(number) or number < 0:
        return None
    return int(number) if number.is_integer() else number

def quantity_token(value):
    return re.sub('\\s+', '', unicodedata.normalize('NFKC', str(value or ''))).casefold().replace('×', 'x')

def quantity_evidence_rows(value):
    """A model-authored quotation without source anchoring cannot arbitrate."""
    out = []
    if isinstance(value, list):
        for entry in value:
            out.extend(quantity_evidence_rows(entry))
    elif isinstance(value, dict):
        if value.get('source_verified') is True and value.get('document_hash') and value.get('chunk_id'):
            for line in str(value.get('text') or '').replace('\\n', '\n').splitlines():
                if line.strip() and line.strip() not in out:
                    out.append(line.strip())
        for entry in value.get('sources', []) if isinstance(value.get('sources'), list) else []:
            for line in quantity_evidence_rows(entry):
                if line not in out:
                    out.append(line)
    return out

def item_evidence_quantities(rule):
    """Only unambiguous trailing quantities in the cited item's own row.

    This is a consistency check, not a PDF table parser. Unrecognized layouts
    produce no evidence and cannot silently resolve contradictory fields.
    """
    params = rule.get('parameters') if isinstance(rule.get('parameters'), dict) else {}
    model = next((params[k] for k in ('model', 'required_model', 'specified_model', '型号', '规格型号') if params.get(k)), None)
    role = quantity_token(rule.get('component_role'))
    result = []
    for line in quantity_evidence_rows(rule.get('evidence')):
        token = quantity_token(line)
        if model:
            key = quantity_token(model)
            if not key or token.count(key) != 1:
                continue
            tail = token.split(key, 1)[1]
        else:
            if not role or token.count(role) != 1:
                continue
            tail = token.split(role, 1)[1]
        if re.search('项目总|订货总|合计|整批|总计|总数量|所有柜', token):
            continue
        if re.search('至少|不小于|不少于|最多|不超过|每[套组包箱]|/套|/包', tail):
            continue
        hits = list(re.finditer('(?<![\\d.])([0-9]+(?:\\.[0-9]+)?)\\s*(个|只|台|套|件|根|块|支|组|处|颗|米|m)(?![a-z0-9²])', tail))
        hit = re.search('(?<![\\d.])([0-9]+(?:\\.[0-9]+)?)\\s*(个|只|台|套|件|根|块|支|组|处|颗|米|m)[。；;，,]?$', tail)
        if not hit or len(hits) != 1:
            continue
        source_unit = hit.group(2)
        declared_unit = quantity_token(params.get('unit'))
        unit_alias = {'米': 'm'}
        if not declared_unit or unit_alias.get(source_unit, source_unit) != unit_alias.get(declared_unit, declared_unit):
            continue
        qty = quantity_number(hit.group(1))
        if qty is not None and qty not in result:
            result.append(qty)
    return result

def normalize_rule_quantities(protocol):
    protocol = copy.deepcopy(protocol)
    errors = protocol.setdefault('_document_errors', [])
    audit = copy.deepcopy(protocol.get('quantity_resolution_audit') or [])
    rules = protocol.get('component_rules', [])
    for rule in rules if isinstance(rules, list) else []:
        if not isinstance(rule, dict):
            continue
        params = rule.get('parameters')
        if not isinstance(params, dict):
            continue
        values = [params[k] for k in ('quantity_per_cabinet', '每柜数量', '单柜数量') if params.get(k) not in (None, '')]
        if not values:
            continue
        numbers = [quantity_number(v) for v in values]
        label = str(rule.get('rule_id') or '') + ' ' + str(rule.get('component_role') or '') + ' ' + str(params.get('model') or '')
        if None in numbers or len(set(numbers)) != 1 or numbers[0] <= 0:
            problem = label + '：逐项每柜数量字段无效或相互矛盾，需核对原始行'
            if problem not in errors:
                errors.append(problem)
            continue
        structured = numbers[0]
        params['quantity_per_cabinet'] = structured
        text_count = _quantity_text_count(rule, {})
        evidence = item_evidence_quantities(rule)
        if len(evidence) > 1 or (evidence and evidence[0] != structured):
            problem = label + '：模型逐项数量%s与已核验原文行数量%s不一致，需重新核对提取结果' % (structured, evidence)
            if problem not in errors:
                errors.append(problem)
            continue
        if text_count is None or text_count == structured:
            continue
        if evidence == [structured]:
            record = {'rule_id': rule.get('rule_id'), 'original_quantity_rule': rule.get('quantity_rule'), 'structured_quantity': structured, 'text_quantity': text_count, 'evidence_quantities': evidence, 'resolution': 'VERIFIED_ITEM_ROW_OVER_UNSUPPORTED_QUANTITY_TEXT'}
            if record not in audit:
                audit.append(record)
            rule['quantity_rule'] = '每柜%s%s' % (structured, str(params.get('unit') or '件'))
            rule['quantity_resolution'] = copy.deepcopy(record)
        else:
            problem = label + '：逐项数量%s与数量规则%s不一致，缺少足够的本行原文依据，不能自动放行' % (structured, text_count)
            if problem not in errors:
                errors.append(problem)
    if audit:
        protocol['quantity_resolution_audit'] = audit
    return protocol

def quantity_from_rule(rule, group):
    params = rule.get('parameters') if isinstance(rule.get('parameters'), dict) else {}
    if params.get('quantity_per_cabinet') not in (None, ''):
        return quantity_number(params['quantity_per_cabinet'])
    return _quantity_text_count(rule, group)
import hashlib

def contract_rows(value):
    return value if isinstance(value, list) else []

def fact_text(value):
    return unicodedata.normalize('NFKC', str(value or '')).replace('\r', '')

def fact_key(value):
    return re.sub('\\s+', '', fact_text(value)).casefold().replace('×', 'x')

def evidence_leaves(value):
    out = []
    if isinstance(value, list):
        for child in value:
            out.extend(evidence_leaves(child))
    elif isinstance(value, dict):
        if value.get('text'):
            out.append({k: copy.deepcopy(value[k]) for k in ('text', 'document_hash', 'chunk_id', 'source_verified', 'source_start', 'source_end', 'source_spans', 'page_index', 'location') if k in value})
        else:
            for child in value.values():
                if isinstance(child, (dict, list)):
                    out.extend(evidence_leaves(child))
        for child in value.get('sources', []) if isinstance(value.get('sources'), list) else []:
            out.extend(evidence_leaves(child))
    unique = []
    seen = set()
    for row in out:
        key = json.dumps(row, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            unique.append(row)
    return unique

def is_anchored(ev):
    return ev.get('source_verified') is True and bool(ev.get('document_hash')) and bool(ev.get('chunk_id'))

def source_rows(evidence, raw_text=''):
    """Expand a verified citation only to its own source line, never a document scan."""
    raw = str(raw_text or '').replace('\r\n', '\n').replace('\r', '\n')
    digest = hashlib.sha256(raw.encode()).hexdigest() if raw else ''
    rows = []
    for ev in evidence_leaves(evidence):
        if not is_anchored(ev):
            continue
        for line in str(ev['text']).replace('\\n', '\n').splitlines():
            if line.strip():
                rows.append((line.strip(), ev))
        spans = ev.get('source_spans') or ([[ev['source_start'], ev['source_end']]] if isinstance(ev.get('source_start'), int) and isinstance(ev.get('source_end'), int) else [])
        if raw and digest == ev.get('document_hash'):
            for span in spans:
                if not isinstance(span, (list, tuple)) or len(span) != 2:
                    continue
                start, end = span
                if not isinstance(start, int) or not isinstance(end, int) or (not 0 <= start < end <= len(raw)):
                    continue
                if '\n' in raw[start:end]:
                    continue
                a = raw.rfind('\n', 0, start) + 1
                b = raw.find('\n', end)
                if b < 0:
                    b = len(raw)
                row = raw[a:b].strip()
                expanded = dict(ev, text=row, source_start=a, source_end=b, source_spans=[[a, b]])
                if row:
                    rows.append((row, expanded))
    return rows

def item_source_clause(line, model, symbol, role):
    """Select a clause with an explicit item identity; same-model peers stay separate."""
    text = fact_text(line)
    model = fact_text(model).strip()
    symbol = fact_text(symbol).strip()
    clauses = re.split('[;；\\n]', text)
    selected = []
    for clause in clauses:
        if re.search('例如|示例|举例|推荐示意|可选型号', clause):
            continue
        if model and fact_key(model) not in fact_key(clause):
            continue
        if not model:
            if not symbol or not re.search('(?<![A-Za-z0-9_-])' + re.escape(symbol) + '(?![A-Za-z0-9_-])', clause, re.I):
                continue
            if role and fact_key(role) not in fact_key(clause):
                continue
        if model and fact_key(clause).count(fact_key(model)) > 1:
            if not symbol:
                continue
            hits = list(re.finditer('(?<![A-Za-z0-9_-])' + re.escape(symbol) + '(?![A-Za-z0-9_-])', clause, re.I))
            if len(hits) != 1:
                continue
            tail = clause[hits[0].start():]
            next_position = re.search('\\s+[A-Za-z][A-Za-z0-9_-]*\\s*[=:：]', tail[len(symbol):])
            clause = tail[:len(symbol) + next_position.start()] if next_position else tail
            if fact_key(clause).count(fact_key(model)) != 1:
                continue
        if symbol:
            label = re.match('\\s*([A-Za-z][A-Za-z0-9_-]*)\\s*[=:：]', clause)
            if label and label.group(1).casefold() != symbol.casefold():
                continue
        clause = re.sub('(?:不允许|不得|禁止|不能|不采用|不选用|不使用|排除|不含)[^;；。\\n,，]*', '', clause)
        if clause.strip():
            selected.append(clause.strip())
    return selected

def explicit_item_facts(clause, role=''):
    """Small, transparent grammar; unrecognized prose remains in source evidence."""
    text = fact_text(clause)
    facts = []

    def put(field, value):
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        pair = (field, value)
        if pair not in facts:
            facts.append(pair)
    if '断路器' in str(role) or 'MCB' in str(role).upper():
        for m in re.finditer('(?<![A-Z0-9])([BCD])\\s*(\\d{1,3})(?:\\s*A)?(?![A-Z0-9])', text, re.I):
            put('trip_curve', m.group(1).upper())
            put('rated_current_a', int(m.group(2)))
        for m in re.finditer('(?:脱扣(?:特性|曲线)\\s*[:：=为]?\\s*([BCD])|(?<![A-Z0-9])([BCD])\\s*型脱扣)', text, re.I):
            put('trip_curve', next((x for x in m.groups() if x)).upper())
    for m in re.finditer('(?<![A-Za-z0-9])([1-5])\\s*P\\s*(\\+\\s*N)?(?![A-Za-z0-9])', text, re.I):
        put('pole_count', m.group(1) + 'P' + ('+N' if m.group(2) else ''))
    patterns = [('continuous_operating_voltage_v', '(?:\\bUc|最大持续(?:工作|运行)电压)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V)\\b'), ('max_discharge_current_ka', '(?:\\bImax|最大放电电流)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA|A)\\b'), ('nominal_discharge_current_ka', '(?:\\bIn|标称放电电流)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA)\\b'), ('breaking_capacity_ka', '(?:分断能力|\\bIcn|\\bIcu)\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kA)\\b'), ('rated_current_a', '额定电流\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(A)\\b'), ('rated_voltage_v', '额定(?:工作)?电压\\s*[:：=为]?\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V)\\b'), ('control_voltage', '(?:线圈电压|控制电压)\\s*[:：=为]?\\s*((?:AC|DC)\\s*\\d+(?:\\.\\d+)?\\s*V)\\b')]
    for field, pattern in patterns:
        for m in re.finditer(pattern, text, re.I):
            if field == 'control_voltage':
                put(field, re.sub('\\s+', '', m.group(1)).upper())
                continue
            number = float(m.group(1))
            unit = m.group(2).lower()
            if field.endswith('_v') and unit == 'kv':
                number *= 1000
            if field.endswith('_ka') and unit == 'a':
                number /= 1000
            put(field, number)
    return facts

def normalize_fact_value(field, value):
    if field in ('trip_curve', 'pole_count', 'control_voltage'):
        return re.sub('\\s+', '', fact_text(value)).upper()
    if isinstance(value, bool):
        return ('invalid', str(value))
    m = re.fullmatch('\\s*(\\d+(?:\\.\\d+)?)\\s*(kV|V|kA|A)?\\s*', str(value), re.I)
    if not m:
        return ('text', fact_key(value))
    number = float(m.group(1))
    unit = (m.group(2) or '').lower()
    if field.endswith('_v') and unit == 'kv':
        number *= 1000
    elif field.endswith('_ka') and unit == 'a':
        number /= 1000
    elif unit and unit not in (('v', 'kv') if field.endswith('_v') else ('a', 'ka')):
        return ('invalid', str(value))
    return number

def recover_item_facts(item, parameter_key, raw_text='', extra_evidence=None):
    params = item.setdefault(parameter_key, {})
    if not isinstance(params, dict):
        return ['物料参数不是对象，无法核对来源']
    model = item.get('shown_model') or next((params[k] for k in ('model', 'required_model', 'designated_model', 'specified_model') if params.get(k)), '')
    symbol = item.get('symbol') or params.get('bit_number') or params.get('symbol') or ''
    role = str(item.get('component_role') or item.get('category') or '')
    ledger = list(item.get('parameter_facts') or [])
    values = {}
    errors = []
    evidence = [item.get('evidence'), extra_evidence]
    for line, ev in source_rows(evidence, raw_text):
        for clause in item_source_clause(line, model, symbol, role):
            for field, value in explicit_item_facts(clause, role):
                proof = {k: copy.deepcopy(ev[k]) for k in ('document_hash', 'chunk_id', 'source_verified', 'source_start', 'source_end', 'source_spans', 'page_index', 'location') if k in ev}
                fact = {'field': field, 'value': value, 'source_text': clause, 'source': proof}
                if fact not in ledger:
                    ledger.append(fact)
                values.setdefault(field, [])
                if value not in values[field]:
                    values[field].append(value)
    for field, found in values.items():
        if len({str(normalize_fact_value(field, v)) for v in found}) != 1:
            errors.append('当前物料原文的' + field + '存在不同值：' + str(found))
            continue
        value = found[0]
        if params.get(field) in (None, '', [], {}):
            params[field] = value
        elif normalize_fact_value(field, params[field]) != normalize_fact_value(field, value):
            errors.append('模型参数' + field + '=' + str(params[field]) + '与当前物料原文' + str(value) + '不一致')
    if ledger:
        item['parameter_facts'] = ledger
    return errors

def preserve_document_facts(document, kind, raw_text=''):
    if not isinstance(document, dict):
        return {'scheme_groups': [], '_document_errors': ['提取结果不是JSON对象，不能作为工程资料']}
    document = copy.deepcopy(document)
    errors = document.setdefault('_document_errors', [])
    if not isinstance(errors, list):
        errors = ['来源错误列表格式异常，需检查提取结果']
        document['_document_errors'] = errors

    def finite(value, path):
        if isinstance(value, float) and (not math.isfinite(value)):
            message = '来源字段含非有限数值：' + path
            if message not in errors:
                errors.append(message)
            return str(value)
        if isinstance(value, dict):
            return {key: finite(child, path + '.' + str(key)) for key, child in value.items()}
        if isinstance(value, list):
            return [finite(child, path + '[' + str(index) + ']') for index, child in enumerate(value)]
        return value
    document = finite(document, kind)
    document['_document_errors'] = errors
    if kind == 'PROTOCOL':
        for rule in document.get('component_rules', []) if isinstance(document.get('component_rules'), list) else []:
            if not isinstance(rule, dict):
                continue
            for error in recover_item_facts(rule, 'parameters', raw_text):
                message = str(rule.get('rule_id') or '') + ' ' + str(rule.get('component_role') or '') + '：' + error
                if message not in errors:
                    errors.append(message)
    else:
        for group in document.get('scheme_groups', []) if isinstance(document.get('scheme_groups'), list) else []:
            if not isinstance(group, dict):
                continue
            seen = set()
            for circuit in group.get('circuits', []) if isinstance(group.get('circuits'), list) else []:
                if not isinstance(circuit, dict):
                    continue
                for item in circuit.get('components', []) if isinstance(circuit.get('components'), list) else []:
                    if not isinstance(item, dict):
                        continue
                    seen.add(id(item))
                    for error in recover_item_facts(item, 'shown_parameters', raw_text, circuit.get('evidence')):
                        message = str(item.get('item_id') or '') + '：' + error
                        if message not in errors:
                            errors.append(message)
            for key in ('drawing_items', 'shown_bom', 'auxiliary_materials', 'wire_requirements'):
                for item in group.get(key, []) if isinstance(group.get(key), list) else []:
                    if not isinstance(item, dict) or id(item) in seen:
                        continue
                    seen.add(id(item))
                    for error in recover_item_facts(item, 'shown_parameters', raw_text):
                        message = str(item.get('item_id') or '') + '：' + error
                        if message not in errors:
                            errors.append(message)
    return document

def preserve_cabinet_context(payload, drawing, protocol):
    groups = {g.get('scheme_group_id'): g for g in contract_rows(drawing.get('scheme_groups')) if isinstance(g, dict)}
    project = protocol.get('project_requirements') or {}
    if not isinstance(project, dict):
        project = {}
    for row in contract_rows(payload.get('component_requirements')):
        role = str(row.get('component_role') or '') + ' ' + str(row.get('category_path') or '')
        if not any((word in role for word in ('柜体', '箱体'))):
            continue
        group = groups.get(row.get('scheme_group_id'), {})
        params = row.setdefault('requirements', {})
        for target, names in {'material': ('cabinet_material',), 'thickness_mm': ('cabinet_thickness_mm',), 'color': ('cabinet_color', 'color')}.items():
            value = next((source[k] for source in (group, project) for k in names if source.get(k) not in (None, '', [], {})), None)
            if value is not None and params.get(target) in (None, '', [], {}):
                params[target] = copy.deepcopy(value)
    return payload

def requirement_capacity_response(message):
    payload = {'capacity_blocked': True, 'capacity_message': message, 'component_requirements': [], 'issues': []}
    return {'pricing_gate': 'BLOCKED_CAPACITY', 'request_summary': message, 'requirement_count': 0, 'requirement_review_filename': '容量超限_请按柜号分批', 'requirement_review_markdown': capacity_markdown(message), 'requirements': [], 'requirements_json': '[]', 'retrieval_count': 0, 'retrieval_requirements': [], 'retrieval_requirements_json': '[]', 'selection_request_json': plain_json(payload), 'validation_message': message, 'validation_status': 'NEED_REVIEW'}

"""Embedded after the requirement validator; relies on its existing source-verification helpers."""


def explicit_source_units(evidence):
    units=set()
    for ev in evidence_leaves(evidence):
        if not is_anchored(ev):continue
        for _,unit in re.findall(r'(?<![A-Za-z\d.])([0-9]+(?:\.[0-9]+)?|[零一二两三四五六七八九十百千]+)\s*(台|只|个|件|套|根|支|组|块|颗|处|米|m)(?![A-Za-z0-9²])',fact_text(ev['text']),re.I):
            units.add('m' if unit in ('米','m','M') else unit)
        for unit in re.findall(r'(?:计量单位|单位)\s*[:：=]\s*(台|只|个|件|套|根|支|组|块|颗|处|米|m)(?![A-Za-z0-9²])',fact_text(ev['text']),re.I):
            units.add('m' if unit in ('米','m','M') else unit)
    return units


def restore_peer_protocol_evidence(peer,protocol_requirement):
    source=protocol_requirement.get('source_evidence') or {}
    verified=[ev for ev in evidence_leaves(source.get('protocol',[])) if is_anchored(ev)]
    target=peer.setdefault('source_evidence',{}).setdefault('protocol',[])
    for ev in verified:
        if ev not in target:target.append(copy.deepcopy(ev))
    if verified and peer.get('mapping_status')=='DRAWING_ONLY':peer['mapping_status']='MATCHED'


def preserve_source_units_and_structure(payload,drawing,protocol,issues):
    groups={g.get('scheme_group_id'):g for g in contract_rows(drawing.get('scheme_groups')) if isinstance(g,dict)}
    for row in contract_rows(payload.get('component_requirements')):
        if row.get('handling_mode') in ('EXCLUDED','SPACE_ONLY'):continue
        sources=row.get('source_evidence') or {}
        protocol_units=explicit_source_units(sources.get('protocol',[]))
        drawing_units=explicit_source_units(sources.get('drawing',[]))
        units=protocol_units | drawing_units
        if len(units)==1:
            row['unit']=next(iter(units));row.setdefault('requirements',{})['unit']=row['unit']
            row['unit_basis']='VERIFIED_DOCUMENT'
        elif len(units)>1:
            add_issue(issues,'BLOCKER','协议与图纸或同项引文的计量单位不一致：'+'、'.join(sorted(units)),row.get('scheme_group_id'),row.get('request_id'),stage='计量单位',blocks_retrieval=True)
            row['unit_basis']='CONFLICT'
        else:
            row['unit_basis']='UNVERIFIED'
            add_issue(issues,'BLOCKER','物料计量单位未在对应的已核验引文中明确，不能用默认台/个替代；请补充单位',row.get('scheme_group_id'),row.get('request_id'),stage='计量单位',blocks_retrieval=True)
        role=str(row.get('component_role') or '')+' '+str(row.get('category_path') or '')
        if not any(word in role for word in ('柜体','箱体')):continue
        params=row.setdefault('requirements',{});group=groups.get(row.get('scheme_group_id'),{})
        structural_evidence=[ev for ev in evidence_leaves(group.get('evidence',[])) if is_anchored(ev)]
        structural_evidence+= [ev for ev in evidence_leaves(sources.get('drawing',[])) if is_anchored(ev)]
        door_values=[]
        for ev in structural_evidence:
            for word,count in (('双门',2),('单门',1)):
                if word in fact_text(ev['text']):door_values.append((count,word,ev))
        if len({value[0] for value in door_values})==1:
            count,label,ev=door_values[0]
            if params.get('door_count') not in (None,'',count,str(count)):
                add_issue(issues,'BLOCKER','柜门数量与柜体已核验引文不一致',row.get('scheme_group_id'),row.get('request_id'),stage='柜体结构',blocks_retrieval=True)
            else:
                params['door_count']=count;params['door_type']=label
                fact={'field':'door_count','value':count,'source_text':ev['text'],'source':copy.deepcopy(ev)}
                if fact not in row.setdefault('parameter_facts',[]):row['parameter_facts'].append(fact)
        elif len({value[0] for value in door_values})>1:
            add_issue(issues,'BLOCKER','柜门形式引文含多个不同值，需确认适用配置',row.get('scheme_group_id'),row.get('request_id'),stage='柜体结构',blocks_retrieval=True)
    return payload
