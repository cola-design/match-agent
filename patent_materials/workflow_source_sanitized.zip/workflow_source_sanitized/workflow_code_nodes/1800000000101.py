import json
import re
HEADERS = {'识别概况': ['项目', '内容'], '待处理问题': ['序号', '问题级别', '问题说明', '人工处理结果'], '已识别方案组': ['序号', '方案组', '方案名称', '进线数', '出线数', '表位', '主电流(A)', '防护等级', '单柜样例数', 'PDF证据']}

def main(markdown):
    sections = {}
    current = None
    for line in str(markdown or '').splitlines():
        found = re.match('^\\s*##\\s+(.+?)\\s*$', line)
        if found:
            current = found.group(1).strip()
            if current not in HEADERS:
                current = None
            elif current in sections:
                raise ValueError('重复章节：' + current)
            else:
                sections[current] = []
            continue
        if current is None or not line.strip().startswith('|'):
            continue
        fields = [part.replace('\\|', '|').strip() for part in re.split('(?<!\\\\)\\|', line.strip().strip('|'))]
        if all((re.fullmatch(':?-{3,}:?', field.replace(' ', '')) for field in fields)):
            continue
        expected = HEADERS[current]
        if fields == expected:
            continue
        if len(fields) != len(expected):
            raise ValueError('%s应有%d列，实际%d列：%s' % (current, len(expected), len(fields), line[:100]))
        sections[current].append(fields)
    if not sections.get('识别概况'):
        sections['识别概况'] = [['识别结论', '未完整识别，本次未进入产品选型']]
    if not sections.get('待处理问题'):
        sections['待处理问题'] = [['—', '错误', '没有可读取的识别结果，请核对源文件', '']]
    if not sections.get('已识别方案组'):
        sections['已识别方案组'] = [['—', '未识别到有效方案', '需提供可读资料', '', '', '', '', '', '', '']]
    for sheet, rows in list(sections.items()):
        if len(rows) > 120:
            text = '\n'.join(('；'.join((str(v) for v in row)) for row in rows))
            chunks = [text[i:i + 6000] for i in range(0, len(text), 6000)]
            if len(chunks) > 120:
                raise ValueError('问题报告超过模板容量，请按柜号拆分资料；未输出不完整BOM')
            sections[sheet] = [[str(i + 1), '详细记录（合并展示）', chunk, ''] if sheet == '待处理问题' else [chunk] + [''] * (len(HEADERS[sheet]) - 1) for i, chunk in enumerate(chunks)]
    cells = {}
    for sheet, rows in sections.items():
        for row_number, row in enumerate(rows, 2):
            for column, value in enumerate(row):
                if value.startswith(('=', '+', '-', '@')):
                    value = "'" + value
                cells['%s!%s%d' % (sheet, chr(65 + column), row_number)] = value
    return {'payload_json': json.dumps({'cells': cells}, ensure_ascii=False), 'summary': '；'.join(('%s%d行' % (name, len(rows)) for name, rows in sections.items()))}

"""Stdlib-only XLSX geometry, embedded in Dify code nodes. No openpyxl in the sandbox."""
import base64 as _lx_b64
import io as _lx_io
import json as _lx_json
import math as _lx_math
import re as _lx_re
import unicodedata as _lx_unicode
import zipfile as _lx_zip
from xml.etree import ElementTree as _lx_et

_LX_NS='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
_LX_REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
_lx_et.register_namespace('',_LX_NS)
_lx_et.register_namespace('r',_LX_REL)


class LayoutCapacityError(ValueError):
    pass


def _lx_tag(name):return '{'+_LX_NS+'}'+name


def _lx_insert_before(parent,element,following):
    position=next((i for i,child in enumerate(parent) if child.tag in {_lx_tag(name) for name in following}),len(parent))
    parent.insert(position,element)


def _lx_col(number):
    result=''
    while number:
        number,remainder=divmod(number-1,26);result=chr(65+remainder)+result
    return result


def _lx_col_number(value):
    result=0
    for char in value:result=result*26+ord(char)-64
    return result


def _lx_lines(value,width):
    if value is None:return 1
    text=str(value).replace('\r\n','\n').replace('\r','\n')
    available=max(5,width-2)
    total=0
    for line in text.split('\n'):
        weight=sum(2.1 if _lx_unicode.east_asian_width(c) in ('W','F') else 1 for c in line)
        total+=max(1,_lx_math.ceil(weight/available))
    return total


def layout_template(template_base64,payload_json,spec):
    """Return a styled EMPTY template; the existing Excel plugin fills unchanged cell values."""
    payload=_lx_json.loads(payload_json)
    cells=payload.get('cells',{})
    if not isinstance(cells,dict):raise ValueError('Excel cells必须是对象')
    buffer=_lx_io.BytesIO()
    with _lx_zip.ZipFile(_lx_io.BytesIO(_lx_b64.b64decode(template_base64))) as original:
        files={name:original.read(name) for name in original.namelist()}
    book=_lx_et.fromstring(files['xl/workbook.xml'])
    rels=_lx_et.fromstring(files['xl/_rels/workbook.xml.rels'])
    targets={r.attrib['Id']:r.attrib['Target'].lstrip('/') for r in rels}
    names=book.find(_lx_tag('definedNames'))
    if names is None:
        names=_lx_et.Element(_lx_tag('definedNames'));_lx_insert_before(book,names,('calcPr','oleSize','customWorkbookViews','pivotCaches','extLst'))
    for item in list(names):
        if item.get('name') in ('_xlnm.Print_Area','_xlnm.Print_Titles'):names.remove(item)
    for index,sheet in enumerate(book.find(_lx_tag('sheets'))):
        name=sheet.get('name');config=spec.get(name)
        if name=='系统数据':
            sheet.set('state','veryHidden');continue
        if not config:continue
        target=targets[sheet.get('{'+_LX_REL+'}id')]
        path=target if target.startswith('xl/') else 'xl/'+target
        root=_lx_et.fromstring(files[path]);data=root.find(_lx_tag('sheetData'))
        start=config['start'];columns=config['columns'];minimum=config.get('minimum',start-1)
        values={}
        metadata=set()
        for key,value in cells.items():
            if '!' not in key:continue
            prefix,coordinate=key.rsplit('!',1)
            if prefix.strip("'")!=name:continue
            match=_lx_re.fullmatch(r'([A-Z]+)(\d+)',coordinate)
            if not match:raise ValueError('Excel单元格地址无效')
            row=int(match.group(2))
            if row>=130 and name in ('BOM确认','资料问题确认'):
                metadata.add(row);continue
            values[coordinate]=value
        rows=[int(_lx_re.search(r'\d+$',key).group()) for key in values]
        last=max([minimum]+rows)
        if config.get('hide_if_empty') and last<start:
            sheet.set('state','hidden')
            continue
        if last-start+1>120 and name not in ('01 报价汇总',):
            raise LayoutCapacityError(name+'超过120行，请分批；没有输出截断表格')
        widths=config['widths']
        merged_widths={}
        merges=root.find(_lx_tag('mergeCells'))
        for merged in merges if merges is not None else []:
            hit=_lx_re.fullmatch(r'([A-Z]+)(\d+):([A-Z]+)(\d+)',merged.get('ref',''))
            if hit and hit.group(2)==hit.group(4):
                first=_lx_col_number(hit.group(1));end=_lx_col_number(hit.group(3))
                merged_widths[hit.group(1)+hit.group(2)]=sum(widths[first-1:end])
        for row in list(data):
            number=int(row.get('r','0'))
            if number>=130 and name in ('BOM确认','资料问题确认'):
                row.set('hidden','1');row.set('ht','1');row.set('customHeight','1');continue
            if number>last:
                data.remove(row);continue
            if number<start:continue
            height=max([config.get('min_height',34)]+[
                9+16*_lx_lines(values.get(_lx_col(col)+str(number)),merged_widths.get(_lx_col(col)+str(number),widths[col-1]))
                for col in range(1,columns+1)])
            if height>409:
                raise LayoutCapacityError(name+'第'+str(number)+'行文字过长，超过Excel单行显示上限；请精简重复说明或拆分需求，未输出会截断的表格')
            row.set('ht',str(height));row.set('customHeight','1')
        dimension=root.find(_lx_tag('dimension'))
        if dimension is not None:dimension.set('ref','A1:'+_lx_col(columns)+str(max(last,max(metadata) if metadata else last)))
        filters=root.find(_lx_tag('autoFilter'))
        if filters is not None:filters.set('ref','A'+str(start-1)+':'+_lx_col(columns)+str(max(start-1,last)))
        properties=root.find(_lx_tag('sheetPr'))
        if properties is None:properties=_lx_et.Element(_lx_tag('sheetPr'));root.insert(0,properties)
        setup_properties=properties.find(_lx_tag('pageSetUpPr'))
        if setup_properties is None:setup_properties=_lx_et.SubElement(properties,_lx_tag('pageSetUpPr'))
        setup_properties.set('fitToPage','1');setup_properties.set('autoPageBreaks','1')
        setup=root.find(_lx_tag('pageSetup'))
        if setup is None:
            setup=_lx_et.Element(_lx_tag('pageSetup'));_lx_insert_before(root,setup,('headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        setup.attrib.update(orientation=config.get('orientation','landscape'),paperSize=str(config.get('paper',8)),fitToWidth='1',fitToHeight='0')
        margins=root.find(_lx_tag('pageMargins'))
        if margins is None:
            margins=_lx_et.Element(_lx_tag('pageMargins'));_lx_insert_before(root,margins,('pageSetup','headerFooter','rowBreaks','colBreaks','drawing','legacyDrawing','tableParts','extLst'))
        margins.attrib.update(left='0.25',right='0.25',top='0.35',bottom='0.35',header='0.15',footer='0.15')
        escaped="'"+name.replace("'","''")+"'"
        area=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Area','localSheetId':str(index)})
        area.text=escaped+'!$A$1:$'+_lx_col(columns)+'$'+str(last)
        repeat=_lx_et.SubElement(names,_lx_tag('definedName'),{'name':'_xlnm.Print_Titles','localSheetId':str(index)})
        repeat.text=escaped+'!$1:$'+str(config.get('header_end',start-1))
        files[path]=_lx_et.tostring(root,encoding='utf-8',xml_declaration=True)
    files['xl/workbook.xml']=_lx_et.tostring(book,encoding='utf-8',xml_declaration=True)
    with _lx_zip.ZipFile(buffer,'w',compression=_lx_zip.ZIP_DEFLATED) as output:
        for name,content in files.items():output.writestr(name,content)
    encoded=_lx_b64.b64encode(buffer.getvalue()).decode('ascii')
    if len(encoded)>55000:raise LayoutCapacityError('动态Excel模板超过传递预算，请分批')
    return encoded

_LAYOUT_TEMPLATE='UEsDBBQAAAAIAPEhXF1Gx01IlQAAAM0AAAAQAAAAZG9jUHJvcHMvYXBwLnhtbE3PTQvCMAwG4L9SdreZih6kDkQ9ip68zy51hbYpbYT67+0EP255ecgboi6JIia2mEXxLuRtMzLHDUDWI/o+y8qhiqHke64x3YGMsRoPpB8eA8OibdeAhTEMOMzit7Dp1C5GZ3XPlkJ3sjpRJsPiWDQ6sScfq9wcChDneiU+ixNLOZcrBf+LU8sVU57mym/8ZAW/B7oXUEsDBBQAAAAIAPEhXF35FXQY7wAAACsCAAARAAAAZG9jUHJvcHMvY29yZS54bWzNklFLwzAQx7+K5L29pJ1DQpcXxScFwYHiW0huW1jThOSk3be3rVuH6AfwMXf//O53cI2J0oSELylETOQw3wy+7bI0ccMORFECZHNAr3M5JrqxuQvJaxqfaQ9Rm6PeI1Scr8EjaatJwwQs4kJkqrFGmoSaQjrjrVnw8TO1M8wawBY9dpRBlAKYmibG09A2cAVMMMLk83cB7UKcq39i5w6wc3LIbkn1fV/29ZwbdxDw/vz0Oq9buC6T7gyOv7KTdIq4YZfJb/X9w/aRqYpX60Lworrb8pUUt7JefUyuP/yuwj5Yt3P/2PgiqBr4dRfqC1BLAwQUAAAACADxIVxd+lwBWfwCAADaDQAAEwAAAHhsL3RoZW1lL3RoZW1lMS54bWy1V9lS2zAU/RWP34u8LxkCw5K0D+20U/gBxZaXIsseSyHw95UVL7IdhbAkzIAlnXPPse7VVbi8fimw9oxqmpdkqZsXhq4hEpVxTtKlvmXJt0C/vrqEC5ahAmkEFmip32WQff/zqGucS+gCLvWMsWoBAI04CtKLskKEryVlXUDGh3UK4hrueMwCA8swPFDAnOh93BXmvwijzUSE64fogFizFj+ZzR/6Su9wrT1DvNR50LjcPaIXpmsYUsYXlrohProGri5Bz8JMQZaIa/HpiC0jfrIEsU43PdNYWYFjDgrWXmEOXAXNzxBRIGAU8dc1Z2DT9YzA6sASav94IHrom/aEICnYc4XQu7WcMcEeCM78Rdfh6t4dE5yB4M4IN4Z1G9pjgjsQvBnBWd341mpMEKgM5+RpDvf8IPA6eI9JSvzjID70PMO/7/ADDEiltg9A2KjwfidJHiFRdwX8V9ZrDhBZhiwnGnutUAKjpkAhzjd1rv3M04wJHbhA8A1ARI8CwESzyMmbBo5IHxHt5QYFIG+G2JqCKY9kkmP8wF4x+kmFOVriPF7zSTEQrD4VVcYfO8ERMK3h8EzbUCnVqpLyEtSVsUQHyQnbz3l+d+r5Jm2LX2XcFr1pDAsUsmHBcKU+0SuIUUplD66IcKIP31b4GOSmPuwTfZjGe4wE5ruNhEeNACk9/BhpsLklXKdttzSCGMVNwtoAo7R+SYpDR/VG1me39oQU0wzGqItrqJyois00vjDJkhU/OOwkDBVGrONGPpxkMG8HmIxH2q7R97u3+1CzqGrK7iHN9jix1N+vRJIJeZWfX8ZqduZ8MmC6hyhJUMQUM8OQr7VRDi5/Ft0Myi1D9UMW77QN3tZ/IS8K1zf5nmtxTlmXAD6oh/KZf78Y5iGuMth28tGh3ePFc68pmRV2ptbBoZ3apOsvua7eZk26lqrd+uqTeIb7MZTuJal/hIr+oe6p7qmd7F3XpuxDtqdstLbCnn2mRuupBM/YUKclC6SvY2I0+Qeqm7n6D1BLAwQUAAAACADxIVxdbp9NH2cGAABAMwAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbI3b227bRhQF0F8hGCCP0dwvsSSgceGmQNoaCdo+09bIIkKJKkVHSb4+Q+pSuYXO2S82hzM8M6S1YEncnO7b7vNulVJffF03m92sXPX99u1ksntcpXW1e9Nu0yb3LNtuXfW52T1NdtsuVYvxoHUzUUK4ybqqN+V8Ou677+bTvnq4bZu2K7qnh1l5d3frvdeinMyn7XPf1Jt03xW75/W66r69S027n5WyPO34WD+t+mFHHr2tntKn1P+5ve9ya3Kuv6jXabOr203RpeWs/Em+fSfVeMQ45K867XcX28Vu1e5/6erFhzx1PkdRFsN5P7Tt56H718Wwa5htk4pvn7ZNPc5f9O32Q1r2t6lp8hyqLKrHvv6S7vOwWfnQ9n27Hvrzyvuqz7uWXfs9bcZVpCblsXl92/8NPhQ5Fh1O+5/jOZTnUxwWdbl9Ope78a+Qr91DtUv5Av9dL/rVrAxlsUjL6rnpP7b79+l4/exQ77FtduPPYn8Yq2xZPD7v8mqOB+cVrOvN4Xf19XjdLw6QQlw5Qh2PUOPCDzONy/y56qv5tGv3RTeOHpZj1KnKeYH5ij8OI8aLkNs6X/FZWW+G18envsvdda7Yz1+/0lFofZN/C2PczXTS5/mGvsnjscQ7toQSwcVcQmkT5H9KTPJSz+tVh/Vae3296jCZGScbXvf/ruPYZV90vaiv+fr6en3N1jd8fXO9vmHrW76+vV7fsvUdX99dr+/Y+p6v76/X92z9wNcP1+sHtn7k68fr9SNbXwp+gmHMtRlOfdQUEphCElNIfgqAsSQcSx6yBCRLgrLkLUsAsyQ0S56zBDxLArTkRUuAtCRMSx61BFRLgrXkXUsAtiRkS562BGxLArfkdStAtyJ0K163AnQrQrfidSvknzT1X5rXrQDditCteN0K0K0I3YrXrQDditCteN0K0K0I3YrXrQDditCteN0K0K0I3YrXrQDditCteN0a0K0J3ZrXrQHdmtCted0a0K0J3Rp4E468C6fehvO6NaBbE7o1r1sDujWhW/O6NaBbE7o1r1sDujWhW/O6NaBbE7o1r1sDujWhW/O6DaDbELoNr9sAug2h2/C6DaDbELoNr9sAug2h2wCfspGP2dTnbF63AXQbQrfhdRtAtyF0G163AXQbQrfhdRtAtyF0G163AXQbQrfhdVtAtyV0W163BXRbQrfldVtAtyV0W163BXRbQrfldVtAtyV0W163Rb5Ho75I43VbQLcldFtetwV0W0K35XVbQLcldFtetwV0W0K35XU7QLcjdDtetwN0O0K343U7QLcjdDtetwN0O0K343U7QLcjdDtetwN0O0K343U75Ity6ptyXrcDdDtCt+N1O0C3I3Q7XrcDdDtCt+N1e0C3J3R7XrcHdHtCt+d1e0C3J3R7XrcHdHtCt+d1e0C3J3R7XrcHdHtCt+d1e0C3J3R74EYYcieMuhXG6/aAbk/o9rxuD+j2hG7P6w6A7kDoDrzuAOgOhO7A6w6A7kDoDrzuAOgOhO7A6w6A7kDoDrzuAOgOhO7A6w6A7kDoDrzuAOgOhO4A3OlGbnVT97p53QHQHQjdgdcdAd2R0B153RHQHQndkdcdAd2R0B153RHQHQndkdcdAd2R0B153RHQHQndkdcdAd2R0B153RHQHQndkdcdAd2R0B2BKAuSZaHCLEiaBYqzkHkWINAikESLoCItAsi0CCTUIqhUiwBiLQLJtQgq2CKAZItAoi2CyrYIHrsUgPZx0PVZeO9SIAEXQSVcBBBxEUjGRVAhFwGkXAQScxFUzkUAQReBJF0EFXURgH0oykZm2aAwG5RmI+NsgH0o0EYm2pBIG5RpI0NtSKoNirWRuTYk2AYl28hoG5Jtg8JtZLoNibdB+TYy4IYk3KCIG5lxQ0JuUMqNjLkBOTeJBN0klXSTQNRNIlk3SYXdJJV2m1yk6avnvr2rmz51l4886PEhia7e9H9sh8cNdsWq7erv7aavmtu0yaPTYlaeH6X4reqe6jyoScs8mXiTXxPdYbnjdt9ux628lsMDC6fWKlWL1A2trHvZtv2pkese+u7GnfNpu1i8H3fk1V9s583jiNfVentzO/6MxetXWlqtboqxfV+MSX8Vb4pJMSb2TTx2/X7uGsueZktf0uY83WVj2D4Nmlw2lnW368+HvGiNjfNBL1svT3Jyfmhm/gNQSwMEFAAAAAgA8SFcXWjEmCs0CQAAwk4AABgAAAB4bC93b3Jrc2hlZXRzL3NoZWV0Mi54bWyVnFtv49YVRv+KoADzGPF+iS9AswduCqStkUGTZ9mmbSGSqFKcOMmvL0lJjPfM5uLuiy1ykYcfaeMsQeLH67e6+fX4WlXt4vfddn+8Wb627eG71er4+Frt1sdv60O178hz3ezWbbfYvKyOh6ZaPw077barKAiy1W692S9vr4d1983tdbt+kHpbN4vm5eFmeXcneZ7HwXJ1e11/brebfXXfLI6fd7t188f31bZ+u1mGy8uKnzYvr22/otv6sH6pPlXtfw73Tbe0Gsd/2uyq/XFT7xdN9Xyz/Fv43ccwGvYYNvl5U70d371eHF/rt783m6cfu0N35xgsF/15P9T1rz3+x1O/qj/avlr88emw3QzHX7T14cfquZVqu+2OES0X68d281t13212s3yo27be9bxL3q7bbtVzU/9Z7YcU1bbqtu3yHb7a+DTIedD+tP97PofleIp9qPevL+dyN/wVumv3sD5W3QX+ZfPUvt4si+XiqXpef962P9VvP1Tn65f24z3W2+Pwc/F22jZfLh4/H7sw5327ALvN/vR7/fv5sr/bvhvG3iE67xB9sUM+tUN83iH+Yod0aofkvEMyXJjTmQyX4eO6Xd9eN/Xbohm27k83iS6jjBeg+4s+9lsMF7lb7gJ0qzf7/v/vU9t0eNON2N5++CZKoiC/6n6HSZleXa/a7ng9Wz2eh/h+doi4iIuoGyIugyzpf3djxsOQQWwOKf//kGkRFf2QWRhl1pAf5080CNN+qCgJ4uGEo7wYhizzIDqlzob1WRolXxxi1V3w8apHp6v+19/u66sencIkQ5h+dvjrak4jOaP0a/TRRCpVPJ8qnk41jSSeTmUilSqZT5VMp5pGkkynMpFKlc6nSqdTTSNJp1OZSKXK5lNl06mmkWTTqUykUuXzqfLpVNNI8ulUJlKpivlUxXSqaSTFdCoTqVTlfKpyOtU0knI6lYlUqjCYj9VvM5ULmFyYlcxmOlroiBZCtGkmF2ZGM5mO5pjmQ5jngUkIM73NdDTHXB/CZA9MQpjubaajOSb8EGZ8YBLCnG8zHc0x64cw7QOTCzOjzc/8oWPqD2HuByYhzP4209Ec838IAgAmISjAZjqaQwIhWACYhOABm+loDhOEoAJgEoIMbKbfvTpsEIENgEkENrCZjuawQQQ2ACYR2MBmOprnTT+966e3/fS+f94GkcMGEdgAmERgA5vpaA4bRGADYBKBDWymozlsEIENgMmFmdHmbRA5bBCBDYBJBDawmY7msEEENgAmEdjAZjqawwYR2ACYRGADm+loDhtEYANgEoENbKY/NXDYIAYbAJMYbGAzHc1hgxhsAExisIHNdDSHDWKwATCJwQY209E8nwPRB0H0SRB9FDRvg9hhgxhsAExisIHNdDSHDWKwATC5MDPavA1ihw1isAEwicEGNtPRHDaIwQbAJAYb2ExHc9ggBhsAkxhsYDMdzWGDGGwATGKwgc30p7UOGyRgA2CSgA1spqM5bJCADYBJAjawmY7msEECNgAmCdjAZjqawwYJ2ACYJGADm+lonq8G6LsB+nKAvh2Yt0HisEECNgAmF2ZGm7dB4rBBAjYAJgnYwGY6msMGCdgAmCRgA5vpaA4bJGADYJKADWymozlskIANgEkCNrCZ/pbMYYMUbABMUrCBzXQ0hw1SsAEwScEGNtPRHDZIwQbAJAUb2ExHc9ggBRsAkxRsYDMdzWGDFGwATFKwgc10NIcNUrABMLkwM9q8DVKHDVKwATBJwQY209EcNkjBBsAkBRvYTEdz2CAFGwCTFGxgMx3NYYMUbABMUrCBzfTdCQ4bZGADYJKBDWymozlskIENgEkGNrCZjuawQQY2ACYZ2MBmOprDBhnYAJhkYAOb6WgOG2RgA2CSgQ1spqM5bJCBDYDJhZnR5m2QeW4gojuI6BYiuodo3gaZwwYZ2ACYZGADm+loDhtkYANgkoENbKajOWyQgQ2ASQY2sJm+K8xhgxxsAExysIHNdDSHDXKwATDJwQY209EcNsjBBsAkBxvYTEdz2CAHGwCTHGxgMx3NYYMcbABMcrCBzXQ0hw1ysAEwuTAz2rwNcocNcrABMMnBBjbT0Tz3lNJNpXRXKd1WOm+D3GGDHGwATHKwgc10NIcNcrABMMnBBjbTd+M6bFCADYBJATawmY7msEEBNgAmBdjAZjqawwYF2ACYFGADm+loDhsUYANgUoANbKajOWxQgA2ASQE2sJmO5rBBATYAJhdmRpu3QeGwQQE2ACYF2MBmOprDBgXYAJgUYAOb6WiemgH1DKhoQE2DeRsUDhsUYANgUoANbKZbEA4blGADYFKCDWymozlsUIINgEkJNrCZjuawQQk2ACYl2MBmOprDBiXYAJiUYAOb6WgOG5RgA2BSgg1spqM5bFCCDYDJhZnR5m1QOmxQgg2ASQk2sJmO5rBBCTYAJiXYwGY6msMGJdgAmJRgA5vpaJ7mGVXPqHtG5TNP+8xVP8P+GRbQsIHmqKAFng5aQCU0gDJCO5+jhxZ4imgBNdEAygjtfI4yWuBpowVURwMoI7TzORppgUMRw0bT+UASI7TzzWsiDByeGDaazgemGKGdb94VYeAppwXUTgMoI7TzOQpqgaehFlBFDaCM0M7naKkFnppaQD01gDJCO5+jqhZ4umoBldUAygjtfA5/uOrL2F/GAjM2mF0VZleHGUvM2GLGGrPDH64iMzaZscqMXWZPmdnVZsY6M/aZsdDsaTSHHn+E5A+AMkI7n8MfoccfIfkDoIzQzufwh6vcjO1mrDdjv9lTcHY1nLHijB1nLDl7Ws6umjP2nLHojE1nT9XZ1XXGsjO2nbHu7Og7h57Cc0iNZ4ISUud5An6Rz+MPqj0TlJCKzxPwlG/17nlT689tfbfZtlXz/qFjw9OsDs1m3/770D/w67h4rZvNn/W+XW+l2ndbV083y/FhZv9cNy+bbqNt9dwdLPi2+99vTic6vG7rw/Cqy3J6ZNhl6bVaP1VNv9TN1s913V4WunFP7G5YeXtdPz39MKzo0r973b08b/FhvTtcyfCzXHz4Jg7TOLpaDMv3i+FpU1F5tVgt+qdFFUl5Rv8a0TDs5WjVb9V+PNz7hf71ZaPV+4XnTXNsx13U0rAw7qSX9EmuxsfW3f4PUEsDBBQAAAAIAPEhXF2wfqgtEBAAAK6gAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDMueG1sld1rbxvXEcbxr0IoQNC+CblXcmNZQHx8rkhbI0Hb17S1sohIokqtoySfvstrfZg5f56iQCzqt7PcGUpJnpDduX5db355ue/7YfLb48PTy9ur+2F4/n46ffl03z8uX75bP/dPo9ytN4/LYXy4+Tx9ed70y9td0ePDtJzN2unjcvV0dXO9+96Hzc31sPyo1g/rzWTz+ePbK2PUfD6vZlfTm+v1l+Fh9dR/2Exevjw+Lje/v+sf1q9vr4qr4zd+Wn2+H7bfGI9+Xn7uf+6Hfz5/2IyPpqfz364e+6eX1fppsunv3l79UHwfinJXsTvkX6v+9eWrrycv9+tXu1nd/jg+9djj7Gqy7fvjev3Llv3t9lvbZ3vqJ7///Pyw2j3/ZFg//9jfDap/eBifo7yaLD8Nq1/7D+Nhb68+rodh/bj18cqH5TB+626z/qN/2l1F/9CPx47X9/yng/cnOZx02/Z/Dj1cnVrcXtTXXx97MbtXYZzdx+VLPw7436vb4f7t1eJqctvfLb88DD+tX11/mF+zPd+n9cPL7q+T1/2x86vJpy8v48UcascLeFw97f9c/nYY+1fHF22ioDwUlGcFZaqgOhRU588wSxTUh4I6t6A5FDTnBXWioD0UtOcFTaJgfiiYnxdUiYLFoWCRe0ndoaA7K6gXqRdudnzldr9f0/0rvvtxeb8cljfXm/XrZLM7fvtjUZfH85x+UMaf/E/bI3Y/jPtexm+vnra/pz8Pm5FX4xmHm2+/KetyNn8z/lnUXfPmejqMz7e16afDKd5dPkU7q4vtKdq2a8c/q7JuSulU6v8+VVk0xfbqqvFvBa10yvcXT1m1i3K+v6p612jTtQvpVPry1c26RZtzKnP5ququnG1PMatmhXQKm3E1s31js9ms2Z5q3rXdm7/88FfhbO7yBS3qZndBzfi/3cSbttj3WlbSBfrLF1hUVbV7MZvFYv+izrt9z21F4wsXTv3hvRkvrBn/AbQ7S93UZ2eZjr8gp9+Scv9b0jTp35Jy/3z17vm2/9T7309/mtSBmj/T+3SVTpNJk02TS5NPUxAvPppbdXluVXpuaVJVem7pKp0mkyabJpcmn6YgXnw0t/ry3Or03NKk6vTc0lU6TSZNNk0uTT5NQbz4aG7N5bk16bmlSTXpuaWrdJpMmmyaXJp8moJ48dHc2stza9NzS5Nq03NLV+k0mTTZNLk0+TQF8eKjuc0vz22enlua1Dw9t3SVTpNJk02TS5NPUxAvPprb4vLcFum5pUkt0nNLV+k0mTTZNLk0+TQF8eKjuXWX59al55Ym1aXnlq7SaTJpsmlyafJpCuLFR3PbpqFLg9sek5ocmDqaNDuo02AGzII5MA8W5B7iERYZIyxghGlTRxNHmK7TYAbMgjkwDxbkHuIRZsSIAnIEmCogSUCdBjNgFsyBebAg9xCPMCNRFBApwFQBoQLqNJgBs2AOzIMFuYd4hBnhooB0AaaOJo4QAgaYAbNgDsyDBbmHeIQZOaOAoAGmjiaOELIGmAGzYA7MgwW5h3iEGZGjgMwBpgpIHVCnwQyYBXNgHizIPcQjzEgfBcQPMFVAAIE6DWbALJgD82BB7iEeYUYQKSCJgKkCsgjUaTADZsEcmAcLcg/xCDMySQGhBEwVEEugToMZMAvmwDxYkHuI/+tyRjopIZ2AqRLSCdRpMANmwRyYBwtyD/EIM9JJCekETJWQTqBOgxkwC+bAPFiQe4hHmPMmB73LQW9z0Psc9EYHvdNBb3XQex30Zge923E5nZQZ6aSEdAKmSkgnUKfBDJgFc2AeLMg9xCPMSCclpBMwdTRxhJBOwAyYBXNgHizIPcQjzEgnJaQTMHU0cYSQTsAMmAVzYB4syD3EI8xIJyWkEzBVQjqBOg1mwCyYA/NgQe4hHmFGOikhnYCpEtIJ1GkwA2bBHJgHC3IP8Qgz0kkJ6QRMlZBOoE6DGTAL5sA8WJB7iEeYkU5KSCdgqoR0AnUazIBZMAfmwYLcQ/wZjox0UkE6AVMVpBOo02AGzII5MA8W5B7iEWakkwrSCZiqIJ1AnQYzYBbMgXmwIPcQjzAjnVSQTsBUBekE6jSYAbNgDsyDBbmHeIQ5n8aij2PR57HoA1n0iSz6SBZ9Jos+lEWfyqKPZV1OJ1VGOqkgnYCpo4kjhHQCZsAsmAPzYEHuIR5hRjqpIJ2AqaOJI4R0AmbALJgD82BB7iEeYUY6qSCdgKkK0gnUaTADZsEcmAcLcg/xCDPSSQXpBExVkE6gToMZMAvmwDxYkHuIR5iRTipIJ2CqgnQCdRrMgFkwB+bBgtxDPMKMdFJBOgFTFaQTqNNgBsyCOTAPFuQe4k9KZ6STGtIJmKohnUCdBjNgFsyBebAg9xCPMCOd1JBOwFQN6QTqNJgBs2AOzIMFuYd4hBnppIZ0AqZqSCdQp8EMmAVzYB4syD3EI8xIJzWkEzBVQzqBOg1mwCyYA/NgQe4hHmFGOqkhnYCpo4kjhHQCZsAsmAPzYEHuIR5hRjqpIZ2AqaOJI4R0AmbALJgD82BB7iEeYUY6qSGdgKka0gnUaTADZsEcmAcLcg/xCDPSSQ3pBEzVkE6gToMZMAvmwDxYkHuIR5iRTmpIJ2CqhnQCdRrMgFkwB+bBgtxDPMKMdFJDOgFTNaQTqNNgBsyCOTAPFuQe4v8/YkY6aSCdgKkG0gnUaTADZsEcmAcLcg/xCDPSSQPpBEw1kE6gToMZMAvmwDxYkHuIR5iRThpIJ2CqgXQCdRrMgFkwB+bBgtxDPMKMdNJAOgFTDaQTqNNgBsyCOTAPFuQe4hFmpJMG0gmYOpo4QkgnYAbMgjkwDxbkHuIRZqSTBtIJmDqaOEJIJ2AGzII5MA8W5B7iEWakkwbSCZhqIJ1AnQYzYBbMgXmwIPcQjzAjnTSQTsBUA+kE6jSYAbNgDsyDBbmHeIQZ6aSBdAKmGkgnUKfBDJgFc2AeLMg9xCPMSCcNpBMw1UA6gToNZsAsmAPzYEHuIb7rR0Y6aSGdgKkW0gnUaTADZsEcmAcLcg/xCDPSSQvpBEy1kE6gToMZMAvmwDxYkHuIR5iRTlpIJ2CqhXQCdRrMgFkwB+bBgtxDPMKMdNJCOgFTLaQTqNNgBsyCOTAPFuQe4hFmpJMW0gmYOpo4QkgnYAbMgjkwDxbkHuIRZqSTFtIJmDqaOEJIJ2AGzII5MA8W5B7iEebciIvuxEW34qJ7cdHNuOhuXHQ7LrofF92Qi+7IdTmdtBnppIV0AqZaSCdQp8EMmAVzYB4syD3EI8xIJy2kEzDVQjqBOg1mwCyYA/NgQe4hHmFGOmkhnYCpFtIJ1GkwA2bBHJgHC3IP8b31MtLJHNIJmJpDOoE6DWbALJgD82BB7iEeYUY6mUM6AVNzSCdQp8EMmAVzYB4syD3EI8xIJ3NIJ2BqDukE6jSYAbNgDsyDBbmHeIQZ6WQO6QRMzSGdQJ0GM2AWzIF5sCD3EI8wI53MIZ2AqaOJI4R0AmbALJgD82BB7iEeYUY6mUM6AVNHE0cI6QTMgFkwB+bBgtxDPMKMdDKHdAKm5pBOoE6DGTAL5sA8WJB7iEeYc8dgumUw3TOYbhpMdw2m2wbTfYPpxsF052C6dfDldDLPSCdzSCdgag7pBOo0mAGzYA7MgwW5h3iEGelkDukETM0hnUCdBjNgFsyBebAg9xDfwTojnSwgnYCpBaQTqNNgBsyCOTAPFuQe4hFmpJMFpBMwtYB0AnUazIBZMAfmwYLcQzzCjHSygHQCphaQTqBOgxkwC+bAPFiQe4hHmJFOFpBOwNQC0gnUaTADZsEcmAcLcg/xCDPSyQLSCZg6mjhCSCdgBsyCOTAPFuQe4hFmpJMFpBMwdTRxhJBOwAyYBXNgHizIPcQjzEgnC0gnYGoB6QTqNJgBs2AOzIMFuYd4hBnpZAHpBEwtIJ1AnQYzYBbMgXmwIPcQjzBntQntNqHlJrTdhNab0H4TWnBCG05oxQntOLmcThYZ6WQB6QRMLSCdQJ0GM2AWzIF5sCD3EO+JyUgnHaQTMNVBOoE6DWbALJgD82BB7iEeYUY66SCdgKkO0gnUaTADZsEcmAcLcg/xCDPSSQfpBEx1kE6gToMZMAvmwDxYkHuIR5iRTjpIJ2Cqg3QCdRrMgFkwB+bBgtxDPMKMdNJBOgFTRxNHCOkEzIBZMAfmwYLcQzzCjHTSQToBU0cTRwjpBMyAWTAH5sGC3EM8wox00kE6AVMdpBOo02AGzII5MA8W5B7iEWakkw7SCZjqIJ1AnQYzYBbMgXmwIPcQjzAjnXSQTsBUB+kE6jSYAbNgDsyDBbmHeIQ5OxhpCSNtYaQ1jLSHkRYx0iZGWsVIuxhpGWPONsasdYy4jxEXMuJGRlzJiDsZcSkjbmXEtYy4lzFjMeMsZzPjjFYzAqoTytOk7YyAhtASOkJPGBKtnE0zZ0njjLY0AqoTytOkRY2AhtASOkJPGBKtnE0zZ1/jjBY2AqoTytOknY2AhtASOkJPGBKtnE0zI8rsDkpPE8LMCeVpQpwhNISW0BF6wpBo5WyaGalmd1B6mpBrTihPE5INoSG0hI7QE4ZEK2fTzFnoOKONjoDqhPI0aakjoCG0hI7QE4ZEK2fTzNntOKPljoDqhPI0ab8joCG0hI7QE4ZEK2fTzFnzOKM9j4DqhPI0adUjoCG0hI7QE4ZEK2fTzNn4OKOVj4DqhPI0aesjoCG0hI7QE4ZEK2dr1XOyEO6mx+X0uJ0e19PjfnpcUI8b6nFFPe6oz1pSn7WlHtfU4556XFSPm+pxVT3uqsdl9bitHtfVZ2ShrIX1uLEeV9bjznpcWo9b63FtPe6tx8X1uLk+Z3V91u56XF6P2+txfT3ur8cF9rjBHlfY4w57XGKfs8W+yMlCBWUhQHVCeZqUhQANoSV0hJ4wJFo5m2ZOFiooCwGqE8rTpCwEaAgtoSP0hCHRytk0c7IQbrfH9fa43x4X3OOGe1xxjzvucck9brnPWXOfteceF93jpntcdY+77nHZPW67x3X3uO8eF97nbLzPWnmPO+9x6T1uvce197j3HhffAzpCTxgSrZxNMycLwXr4d4SqkJfHH6dJWQjQEFpCR+gJQ6KVeJplThaCTfHvCFUh75E/TBMqNaEhtISO0BOGRCtn08zJQrA0/h2hKuSV8sdpUhYCNISW0BF6wpBoZT/N6ct93w/vl8Py5nr5ZVib1cPQbyab/m47vu/H4upqenP9vFk9Df94Hlbrp5fJ/Xqz+mP9NCwfVP80Ht3fbme+PWr5uf/bcvN5NR700N+NTzb7bvx79mb/suy+HtbPu6/Ga/m4HsYX7fjovl/e9pvto/Hfju/W6+H4YDzv3szumzfX69tbt/vGePVffT1+eTji2+Xj8xu1+2s3+fabqmiq8s1k9/jD9nE3K7s3k+n4ZTlb1N2B/n6i3WmPz9b/2j+dnu7rB9uvjwdNv35wt9q8DKeS6NHuwakofhQ3OX1db37ZvTY3/wVQSwMEFAAAAAgA8SFcXQqrZSwMAwAA9BQAAA0AAAB4bC9zdHlsZXMueG1s7Vhtb5swEP4riB9QQtzSMAHSRhttHzZNaj90HwkxCZLBzDgd6a+fD5MEWl9E11bppoEibN89d8+9ACZBLbeM3qwplVZTsLIO7bWU1QfHqdM1LZL6jFe0VJKMiyKRaipWTl0JmixrABXMmU4mnlMkeWlHQbkp5oWsrZRvShnaE9uJgoyXh5VzWy8o1aSg1n3CQjtOBMslB936QS+5LswcrflY/2ueCl7zTFo/ks80B81FB4NxyhkXllgtQnveHS8xPTA39cjl+eXA3OSVzZ1d9Ay2l1oZzhnb55DYeiEKqkRKKsq5mrSYdvGJyOrGt9uKhvZKJFt32jkZA6g5y5fgchX3ubve5Xymg+9B90bbi2K+4GJJxYC7XnJ2gyhgVGWobcTQluu2kQZpuoqvvWu/dQWqUSDy1XosotWNAsmrkQClCdSk5MVIhFZuBzqgcYFNJvHsyru+GB/YADEmsAFgVGADxJPAuoGqa0oZuwEjd9m+uK4y1WSWfgh8WcL9b0ED74aqI7qhNqMn4KhvTdvum/X+yK5V5fdcftqoEMp2/nPDJf0uaJY37bzJ9gRGWJ++vnX3VNaTqmLbjyxflQXVhRvtMAqSHc76JZLqljaye/A6TXZKNvdUyDyFh2iqplTYz+I3fdM+OmL9BLV4ezYvqwXWK+474Yfl773we/v8rbnIH5S3PsP3ntO/nTPsEF7K+NSdobYgzyNMkBRP/xM29QRK1+n2VL2N22Dbtl+14OsltL/B5x4bvNsOm7S62zGqa14uaUOXcTdVW8i4v5fUB6AfSw4fZk8lGEbLzBKQYX4wBhhGozA//1I8MzQeLcO4zYySGYqZoRiNMkni9sT8mDG+OsyR+j4hnodlNI6NDGIsb54HP7M1jBsgMD/g6Xm5xquNd8jxPsBqeqxDsEjxTsQixXMNEnPeAOH75mpjfgCBVQHrHfBv9gM9ZcYQAlXFuGF3MC7xfUwCvWjuUc9DsuPBaa4PdpcQ4vtmCcjMDAjBJHA34hKMAXDAJIS076hH7yNn955yDv9zRr8BUEsDBBQAAAAIAPEhXF2XirscwAAAABMCAAALAAAAX3JlbHMvLnJlbHOdkrluwzAMQH/F0J4wB9AhiDNl8RYE+QFWog/YEgWKRZ2/r9qlcZALGXk9PBLcHmlA7TiktoupGP0QUmla1bgBSLYlj2nOkUKu1CweNYfSQETbY0OwWiw+QC4ZZre9ZBanc6RXiFzXnaU92y9PQW+ArzpMcUJpSEszDvDN0n8y9/MMNUXlSiOVWxp40+X+duBJ0aEiWBaaRcnToh2lfx3H9pDT6a9jIrR6W+j5cWhUCo7cYyWMcWK0/jWCyQ/sfgBQSwMEFAAAAAgA8SFcXfWXGHJPAQAApAMAAA8AAAB4bC93b3JrYm9vay54bWy1k81Kw0AUhV8lDoHuOk0KLkIaUIpQFyL4AGWamZih8xNmRu1aaunSlbpVxI2gIIiI4Nuk2rdw+hNIqxQRu5q53Mv5DvdwwxOpuh0pu06PM6EbIDUmCyDUcUo40lWZEWE7iVQcGVuqQ6gzRRDWKSGGM+jXapuQIypAFBZa+wpG4XRAz9+ZeqB+oy+ThMakKeMjToSZARRhyFApdEozDRyBOGmAz8dBPrwf3Z3mg2fgTDkt3ACe/Rtk7MAx1bTDCHBUQG1DtbAH4Dod5e9n+W3/43wwvnwY31yVTPkrTPlrNvXyNN/Uxevoevjx1i/5qq/wVZ/4gkWOmCRUELxnNRerOabdY4JX2zuUGaKayKAO0laNyRixgwJXA05KMSZiElNUKSdY2XC3XC9wt13Pr4ewBPgzzVukLaVTAJv/B/SXgN82XzB3f2DCxQ3D4pqiL1BLAwQUAAAACADxIVxdu2zq7LoAAAAaAwAAGgAAAHhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzxZM5DoMwEEWvgnwAhiVJEQFVGtqIC1gwLGKx5ZkocPsQKMBSijSIyvpj+f1XjKMndpIbNVDdaHLGvhsoFjWzvgNQXmMvyVUah/mmVKaXPEdTgZZ5KyuEwPNuYPYMkUR7ppNNGv8hqrJscnyo/NXjwD/A8FampRqRhZNJUyHHAsZuGxMsh+/OZOGkRSxMWvgCzhYKLKHgfKHQEgoPFCKeOqTNZs1W/eXAep7f4ta+xHVoL8n16wDWV0g+UEsDBBQAAAAIAPEhXF2m/EpbIwEAAN8EAAATAAAAW0NvbnRlbnRfVHlwZXNdLnhtbM2Uz07DMAzGX6XqdWoyhsQBrbsAV9iBFwiNu0bNP8Xe6N4et90mgUbFNCS4NGpsfz/Hn5Ll6z4CZp2zHsu8IYr3UmLVgFMoQgTPkTokp4h/00ZGVbVqA3Ixn9/JKngCTwX1Gvlq+Qi12lrKnjreRhN8mSewmGcPY2LPKnMVozWVIo7LnddfKMWBILhyyMHGRJxxQi7PEvrI94BD3csOUjIasrVK9KwcZ8nOSqS9BRTTEmd6DHVtKtCh2jouERgTKI0NADkrRtHZNJl4wjB+b67mDzJTQM5cpxCRHUtwOe5oSV9dRBaCRGb6iCciS199Pujd1qB/yObxvofUDn6gHJbrZ/zZ45P+hX0s/kkft3/Yx1sI7W9fuX4VThl/5MvhXVt9AFBLAQIUAxQAAAAIAPEhXF1Gx01IlQAAAM0AAAAQAAAAAAAAAAAAAACAAQAAAABkb2NQcm9wcy9hcHAueG1sUEsBAhQDFAAAAAgA8SFcXfkVdBjvAAAAKwIAABEAAAAAAAAAAAAAAIABwwAAAGRvY1Byb3BzL2NvcmUueG1sUEsBAhQDFAAAAAgA8SFcXfpcAVn8AgAA2g0AABMAAAAAAAAAAAAAAIAB4QEAAHhsL3RoZW1lL3RoZW1lMS54bWxQSwECFAMUAAAACADxIVxdbp9NH2cGAABAMwAAGAAAAAAAAAAAAAAAgIEOBQAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1sUEsBAhQDFAAAAAgA8SFcXWjEmCs0CQAAwk4AABgAAAAAAAAAAAAAAICBqwsAAHhsL3dvcmtzaGVldHMvc2hlZXQyLnhtbFBLAQIUAxQAAAAIAPEhXF2wfqgtEBAAAK6gAAAYAAAAAAAAAAAAAACAgRUVAAB4bC93b3Jrc2hlZXRzL3NoZWV0My54bWxQSwECFAMUAAAACADxIVxdCqtlLAwDAAD0FAAADQAAAAAAAAAAAAAAgAFbJQAAeGwvc3R5bGVzLnhtbFBLAQIUAxQAAAAIAPEhXF2XirscwAAAABMCAAALAAAAAAAAAAAAAACAAZIoAABfcmVscy8ucmVsc1BLAQIUAxQAAAAIAPEhXF31lxhyTwEAAKQDAAAPAAAAAAAAAAAAAACAAXspAAB4bC93b3JrYm9vay54bWxQSwECFAMUAAAACADxIVxdu2zq7LoAAAAaAwAAGgAAAAAAAAAAAAAAgAH3KgAAeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHNQSwECFAMUAAAACADxIVxdpvxKWyMBAADfBAAAEwAAAAAAAAAAAAAAgAHpKwAAW0NvbnRlbnRfVHlwZXNdLnhtbFBLBQYAAAAACwALAMoCAAA9LQAAAAA='
_LAYOUT_SPEC={'识别概况': {'start': 2, 'columns': 2, 'widths': [25, 100], 'header_end': 1, 'paper': 9}, '待处理问题': {'start': 2, 'columns': 4, 'widths': [7, 15, 75, 55], 'header_end': 1}, '已识别方案组': {'start': 2, 'columns': 10, 'widths': [7, 16, 26, 10, 10, 14, 15, 13, 14, 48], 'header_end': 1}}
_v182_layout_base=main
def main(markdown):
    out=_v182_layout_base(markdown)
    out["template_base64"]=layout_template(_LAYOUT_TEMPLATE,out['payload_json'],_LAYOUT_SPEC)
    return out
