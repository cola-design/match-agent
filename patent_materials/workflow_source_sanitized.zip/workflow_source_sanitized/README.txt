﻿脱敏工作流及配套源码（2026-10-30）

内容：
- workflow_main_sanitized.yml：V18.2.1导出，108节点；39个Python代码节点、9个模型节点、5个HTTP请求。
- workflow_code_nodes/：从该YAML提取的39个Python代码节点。
- mongodb_api/：API 1.2.0服务、共享产品契约、独立产品修复工具及依赖清单。
- product_sync/：独立产品同步、清洗、分页及离线诊断代码；source.py包含已交付草稿分页修正，仍待现场预览。

脱敏：
API Key、MongoDB/API连接地址和secret环境变量值为空。保留环境变量名称及Dify变量引用，方便理解依赖。
同步源端默认实际地址改为 https://source.example.invalid/products 占位地址。
未打包.env、真实密钥、数据库连接串、生产数据、客户原图、原始运行快照、变更计划或价格文件。
MATERIAL_MARKUP_RATE=0.15、QUOTE_DISCOUNT_RATE=0.02是业务比例示例，保留供还原计算；实际使用需核定。

使用边界：
这是技术资料审阅包。配置为空，源端地址已替换，不能直接当作生产配置启动。
Dify代码节点依赖各自输入与工作流顺序，提取出的Python不是互相独立的命令行应用。
需保留已配置的模型提供商与generic_excel_template_filler插件；模型声明不等于现场凭据可用。
分享范围：用户于2026-10-30确认允许将本脱敏YAML及配套源码上传至现有公开GitHub仓库。

验证：YAML已解析；108个节点和连线关联检查；39个嵌入Python节点及7个配套模块语法检查；ZIP完整性及文件校验值检查。
原文摘录定位不是工程正确性的充分证明；代码存在和离线检查通过不等于现场完整验收。
