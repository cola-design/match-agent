@echo off
chcp 65001 >nul
cd /d "%~dp0运行版"
python server.py --open
pause
