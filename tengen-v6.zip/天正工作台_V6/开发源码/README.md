# 开发维护

普通使用请运行包内“运行工作台.bat”，无需Node或开发依赖。

本目录为React/Vite完整源码：

- npm ci：按package-lock安装开发依赖。
- npm run build：构建web目录。
- npm test：运行11项工作流和输入逻辑测试。
- python server.py：本机加载已构建页面并转发Dify请求。
- python tools/build_preview.py：生成独立预览HTML，禁用真实API。

浏览器测试是开发检查，需要Python Playwright和可用Chromium，可通过CHROMIUM_PATH指定浏览器路径。它们不是普通运行依赖。

src/workflow-contract.json对应用户给定YML的节点ID、输入约束、链接规则和源文件摘要，未包含原YML密钥。更改节点ID或返回URL规则时同步更新。

运行包未包含原YML、客户资料、应用密钥或真实数据库内容。已有8774页面不在本源码中。
