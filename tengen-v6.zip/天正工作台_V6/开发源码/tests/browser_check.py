"""Run against a started local workbench. Requires Python Playwright for development."""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
URL=os.environ.get('WORKBENCH_TEST_URL','http://localhost:8785')
errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1600,'height':1000});page.on('pageerror',lambda error:errors.append(str(error)))
 page.goto(URL);page.wait_for_load_state('networkidle')
 assert page.get_by_role('button',name='开始识别图纸',exact=True).is_disabled()
 assert page.get_by_role('button',name='核对与选型',exact=True).is_disabled()
 assert page.get_by_role('button',name='报价表导出',exact=True).count()==0
 page.screenshot(path=str(OUT/'01_工作台首页.png'),full_page=True)
 page.get_by_role('button',name='查看操作示例',exact=True).click()
 page.locator('.drawing-paper img').wait_for();page.wait_for_timeout(200)
 page.screenshot(path=str(OUT/'02_图纸预览.png'),full_page=True)
 page.get_by_role('button',name='放大图纸',exact=True).click();assert page.locator('.zoom-label').inner_text()=='125%'
 for _ in range(3):page.get_by_role('button',name='放大图纸',exact=True).click()
 canvas=page.locator('.canvas');box=canvas.bounding_box();page.mouse.move(box['x']+box['width']*.6,box['y']+box['height']*.5);page.mouse.down();page.mouse.move(box['x']+100,box['y']+80,steps=8);page.mouse.up()
 assert canvas.evaluate('(el)=>el.scrollLeft>0 || el.scrollTop>0')
 page.get_by_role('button',name='适合画布',exact=True).click();assert page.locator('.zoom-label').inner_text()=='100%'
 page.get_by_role('button',name='全屏查看图纸',exact=True).click();page.get_by_role('button',name='退出全屏',exact=True).wait_for();page.get_by_role('button',name='退出全屏',exact=True).click()
 page.get_by_role('button',name='体验识别过程',exact=True).click();page.get_by_role('heading',name='示例体验已完成',exact=True).wait_for()
 assert page.get_by_role('link',name='打开图纸核对与选型页',exact=True).count()==0
 page.get_by_role('button',name='使用指南',exact=True).last.click();assert page.get_by_role('dialog').is_visible();page.keyboard.press('Escape');assert not page.get_by_role('dialog').count()
 page.locator('#project').fill('测试识图任务');page.locator('#count').fill('2')
 page.get_by_role('button',name='重新开始',exact=True).click();assert page.locator('#project').input_value()=='';assert page.locator('#count').input_value()==''
 page.locator('input[type=file]').set_input_files({'name':'a.dwg','mimeType':'application/octet-stream','buffer':b'x'})
 assert 'PDF' in page.get_by_role('alert').inner_text()
 page.locator('input[type=file]').set_input_files({'name':'too-large.png','mimeType':'image/png','buffer':b'x'*(10*1024*1024+1)})
 assert '10MB' in page.get_by_role('alert').inner_text()
 page.get_by_role('button',name='查看操作示例',exact=True).click();page.locator('#count').fill('1e2');page.get_by_role('button',name='体验识别过程').click();assert '整数' in page.get_by_role('alert').inner_text()
 page.locator('#count').fill('');page.get_by_role('button',name='体验识别过程').click();page.get_by_role('heading',name='示例体验已完成',exact=True).wait_for()
 page.locator('h1').click()
 for width,height in [(1440,900),(1280,800),(1024,900),(768,1024),(390,844)]:
  page.set_viewport_size({'width':width,'height':height});page.wait_for_timeout(100)
  assert not page.evaluate('document.documentElement.scrollWidth > innerWidth'),width
  reset_box=page.get_by_role('button',name='重新开始',exact=True).bounding_box()
  assert reset_box['x']>=0 and reset_box['x']+reset_box['width']<=width,width
  if width in (1440,390):page.screenshot(path=str(OUT/f'03_工作台_{width}px.png'),full_page=True)
 page.emulate_media(reduced_motion='reduce')
 assert page.locator('.spin').count()==0
 assert not errors,errors
 browser.close()
print('PASS: first-use state, preview, zoom/pan/fit/fullscreen, sample isolation, guide, restart, file limits, count format, blank count, five screen widths, no JS errors.')
