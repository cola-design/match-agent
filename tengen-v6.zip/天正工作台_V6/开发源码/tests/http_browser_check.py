"""Real local HTTP relay + Chromium checks against a controlled Dify fixture, no model calls."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import os,json,socket,subprocess,sys,threading,time,urllib.request,urllib.error
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
CONTRACT=json.loads((ROOT/'src/workflow-contract.json').read_text())
URL='http://localhost:8774/system-quote-reviews/0123456789abcdef0123456789abcdef'
state={'mode':'ok','upload':0,'run':0,'payloads':[]}
REPLY=f'我把 **示例配电箱** 这张图里的回路和元件理了一遍，整理出了 **7 条**核对记录。\n\n建议先看 **L1 · 微型断路器**。图上标了「MCB-C16A/1P」。这一处需要确认的是「供货范围」。\n\n**[去核对图纸参数]({URL})**'
class Fixture(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_POST(self):
  body=self.rfile.read(int(self.headers['Content-Length']))
  assert self.headers.get('Authorization')=='Bearer test-only-fixture'
  if self.path=='/v1/files/upload':
   assert b'filename=' in body and b'name="user"' in body
   state['upload']+=1;self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(b'{"id":"fixture-file"}');return
  if self.path!='/v1/chat-messages':self.send_error(404);return
  payload=json.loads(body);state['payloads'].append(payload);state['run']+=1
  assert payload['inputs']['drawing']['upload_file_id']=='fixture-file'
  assert payload['inputs']['project']=='电梯配电箱（界面演示）'
  assert payload['inputs']['cabinet_count']=='2'
  assert payload['query']=='请分析' and payload['response_mode']=='streaming'
  mode=state['mode']
  if mode=='401':
   self.send_response(401);self.send_header('Content-Type','application/json');self.end_headers();self.wfile.write(json.dumps({'message':'应用密钥验证失败'},ensure_ascii=False).encode());return
  self.send_response(200);self.send_header('Content-Type','text/event-stream; charset=utf-8');self.end_headers()
  def event(e):self.wfile.write(('data: '+json.dumps(e,ensure_ascii=False)+'\r\n\r\n').encode());self.wfile.flush()
  try:
   if mode=='malformed':self.wfile.write(b'data: not-json\n\n');return
   if mode=='branch':
    event({'event':'node_finished','data':{'node_id':'drawing_upload','title':'本机读取PDF或图片','status':'failed'}})
    event({'event':'node_started','data':{'node_id':'drawing_upload_feedback','title':'读图提示'}})
   else:
    for phase in CONTRACT['phases']:
     for node in phase['nodes']:
      event({'event':'node_started','data':{'node_id':node,'title':'联调节点名称可变化'}})
      status='exception' if mode=='partial' and node=='numbered_circuit_evidence' else 'succeeded'
      event({'event':'node_finished','data':{'node_id':node,'status':status,'title':CONTRACT['nodeTitles'][node]}})
   if mode=='workflow-failed':event({'event':'workflow_finished','data':{'status':'failed','error':'识图节点未完成'}});return
   event({'event':'workflow_finished','data':{'status':'partial-succeeded' if mode in ('partial','branch') else 'succeeded'}})
   reply={'no-link':'本机核对页暂时没能打开。等一会儿再试就好，图纸可以用原来那份。','branch':'这份文件暂时没读进来。可以重新上传一张清晰的系统图。','unsafe':'<img src=x onerror="window.hacked=1"> [错误链接](https://evil.test/)'} .get(mode,REPLY)
   event({'event':'message','answer':reply})
   if mode!='disconnect':event({'event':'message_end'})
  except (BrokenPipeError,ConnectionResetError):pass

def free_port():
 with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]
fixture=ThreadingHTTPServer(('127.0.0.1',0),Fixture);threading.Thread(target=fixture.serve_forever,daemon=True).start()
port=free_port();base=f'http://127.0.0.1:{port}'
proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,env={**os.environ,'PORT':str(port),'DIFY_API_BASE':f'http://127.0.0.1:{fixture.server_port}/v1','DIFY_APP_API_KEY':'test-only-fixture'},stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
try:
 for _ in range(50):
  try:urllib.request.urlopen(base+'/api/status',timeout=1);break
  except OSError:time.sleep(.1)
 else:raise RuntimeError('fixture UI did not start')
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),args=['--no-sandbox'])
  ctx=browser.new_context(viewport={'width':1600,'height':1000},permissions=['clipboard-read','clipboard-write']);errors=[]
  ctx.on('page',lambda page:page.on('pageerror',lambda e:errors.append(str(e))))
  ctx.route('http://localhost:8774/**',lambda route:route.fulfill(content_type='text/html; charset=utf-8',body='<h1>模拟核对与选型页面</h1>'))
  page=ctx.new_page();page.goto(base);page.wait_for_load_state('networkidle')
  page.get_by_role('button',name='查看操作示例').click();page.locator('.drawing-paper img').wait_for();page.wait_for_timeout(100);drawing=page.locator('.drawing-paper img').screenshot()
  assert state['run']==0 and state['upload']==0
  def prepare(mode):
   state['mode']=mode;page.goto(base);page.wait_for_load_state('networkidle');page.get_by_text('应用配置已填写',exact=True).wait_for();page.locator('#project').fill('电梯配电箱（界面演示）');page.locator('#count').fill('2');page.locator('input[type=file]').set_input_files({'name':'配电箱系统图_界面示例.png','mimeType':'image/png','buffer':drawing})
  prepare('ok');before=state['run'];page.locator('form').evaluate('(f)=>{f.requestSubmit();f.requestSubmit();}')
  link=page.get_by_role('link',name='打开图纸核对与选型页',exact=True);link.wait_for();assert state['run']==before+1
  assert page.get_by_text('7 条',exact=False).count()>0
  assert page.locator('#project').evaluate('(e)=>e.readOnly');assert page.locator('#count').evaluate('(e)=>e.readOnly');assert page.get_by_role('button',name='重新识别',exact=True).is_visible();assert page.locator('.priority-note').is_visible();assert page.locator('.phase-list .done').count()==4
  page.screenshot(path=str(OUT/'04_识别完成_联调示意.png'),full_page=True)
  with page.expect_popup() as popup:link.click()
  popup.value.wait_for_load_state();assert popup.value.get_by_role('heading',name='模拟核对与选型页面').is_visible();popup.value.close()
  page.get_by_role('button',name='复制核对链接',exact=True).click();page.get_by_text('链接已复制',exact=True).wait_for();assert page.evaluate('navigator.clipboard.readText()')==URL
  page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(200);assert not page.evaluate('document.documentElement.scrollWidth>innerWidth');page.screenshot(path=str(OUT/'05_手机核对入口.png'),full_page=True);page.set_viewport_size({'width':1600,'height':1000})
  for mode,expected in [('no-link','本次未生成核对页'),('branch','本次未生成核对页'),('disconnect','响应连接中断'),('401','应用密钥验证失败'),('malformed','数据格式异常'),('workflow-failed','识图节点未完成'),('unsafe','本次未生成核对页')]:
   prepare(mode);page.get_by_role('button',name='开始识别图纸',exact=True).click();page.locator('.outcome').get_by_text(expected,exact=False).wait_for();page.wait_for_function("document.querySelector('.start-button').disabled===false")
   assert not page.locator('.phase-list .active').count(),mode
   assert not page.locator('.indeterminate-track').count(),mode
   assert page.get_by_role('link',name='打开图纸核对与选型页',exact=True).count()==0,mode
   assert page.locator('#project').input_value()=='电梯配电箱（界面演示）'
   assert page.locator('#count').input_value()=='2'
   assert page.locator('.drawing-paper img').is_visible()
   if mode=='no-link':
    assert page.locator('.phase-list .attention').count()==1
    page.screenshot(path=str(OUT/'06_未生成核对页_联调示意.png'),full_page=True)
   if mode=='unsafe':assert page.evaluate('window.hacked') is None
  prepare('partial');page.get_by_role('button',name='开始识别图纸',exact=True).click();page.get_by_role('link',name='打开图纸核对与选型页',exact=True).wait_for();assert page.locator('.partial-note').is_visible();assert page.locator('.phase-list .attention').count()==1
  assert 'test-only-fixture' not in page.locator('body').inner_text()
  assert not errors,errors
  browser.close()
 for path in ['/../.env','/%2e%2e/.env','/src/main.jsx']:
  try:urllib.request.urlopen(base+path)
  except urllib.error.HTTPError as e:assert e.code==404
  else:raise AssertionError('source or secret path exposed')
 report={'http_uploads':state['upload'],'http_runs':state['run'],'cases':['success/new-tab','duplicate submission','copy link','workflow-success/no-review','handled failure branch','disconnected stream','401','invalid SSE frame','workflow failure','untrusted text','partial success with valid URL'],'model_calls':0,'company_services_accessed':False,'js_errors':errors,'source_contract_sha256':CONTRACT['sourceSha256']}
 (OUT/'http_browser_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('PASS:',json.dumps(report,ensure_ascii=False))
finally:
 proc.terminate()
 try:proc.wait(timeout=5)
 except subprocess.TimeoutExpired:proc.kill()
 fixture.shutdown();fixture.server_close()
