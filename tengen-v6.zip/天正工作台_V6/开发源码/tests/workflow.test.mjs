import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  initialRun,
  reduceRun,
  findReviewUrl,
  validateFile,
  validateCount,
  phaseStates,
  replyParagraphs,
  readSSE,
} from "../src/workflow.mjs";
const c = JSON.parse(
  fs.readFileSync(new URL("../src/workflow-contract.json", import.meta.url)),
);
const url =
  "http://localhost:8774/system-quote-reviews/0123456789abcdef0123456789abcdef";
const reduce = (s, a) => reduceRun(s, a, c);
test("strict URL contract rejects protocol, host, suffix and lookalike attacks", () => {
  assert.equal(findReviewUrl(`**[去核对](${url})**`, c.reviewUrlPattern), url);
  for (const bad of [
    url + "x",
    url.replace("localhost", "localhost.evil"),
    url.replace("http:", "https:"),
    url.replace("localhost", "127.0.0.1"),
  ])
    assert.equal(findReviewUrl(bad, c.reviewUrlPattern), "");
});
test("input constraints follow YML and allow unknown cabinet count", () => {
  assert.equal(validateCount(""), "");
  for (const v of ["0", "-1", "1e2", "1.5", "1000000", " 1"])
    assert.notEqual(validateCount(v), "");
  assert.equal(validateCount("999999"), "");
  assert.equal(
    validateFile({ name: "a.pdf", size: 15 * 1024 * 1024 }, c.limits),
    "",
  );
  assert.notEqual(
    validateFile({ name: "a.png", size: 10 * 1024 * 1024 + 1 }, c.limits),
    "",
  );
  assert.notEqual(validateFile({ name: "a.dwg", size: 1 }, c.limits), "");
});
test("renaming node titles does not affect phase mapping", () => {
  let s = reduce(initialRun(), { type: "begin" });
  s = reduce(s, {
    type: "event",
    event: {
      event: "node_started",
      data: { node_id: "extract", title: "renamed" },
    },
  });
  assert.equal(phaseStates(s, c)[2], "active");
  assert.equal(phaseStates(s, c)[0], "pending");
});
test("normal workflow completion without review URL is business attention, no active phase remains", () => {
  let s = reduce(initialRun(), { type: "begin" });
  for (const id of c.phases.flatMap((p) => p.nodes))
    s = reduce(s, {
      type: "event",
      event: {
        event: "node_finished",
        data: { node_id: id, status: "succeeded" },
      },
    });
  s = reduce(s, {
    type: "event",
    event: { event: "message", answer: "本机核对页暂时没能打开。" },
  });
  s = reduce(s, { type: "finish" });
  assert.equal(s.status, "attention");
  assert.equal(s.url, "");
  assert.equal(phaseStates(s, c)[3], "attention");
  assert(!phaseStates(s, c).includes("active"));
});
test("handled failure branch retains correct affected phase", () => {
  let s = reduce(initialRun(), { type: "begin" });
  s = reduce(s, {
    type: "event",
    event: { event: "node_started", data: { node_id: "extract_feedback" } },
  });
  s = reduce(s, { type: "finish" });
  assert.equal(s.issuePhase, 2);
});
test("valid review means waiting for human review, not selection or quotation completion", () => {
  let s = reduce(initialRun(), { type: "begin" });
  s = reduce(s, {
    type: "event",
    event: { event: "message", answer: `7条核对记录。\n\n[去核对](${url})` },
  });
  s = reduce(s, { type: "finish" });
  assert.equal(s.status, "review");
  assert.equal(s.url, url);
  assert(phaseStates(s, c).every((x) => x === "done"));
  assert.deepEqual(replyParagraphs(s.answer, c.reviewUrlPattern), [
    "7条核对记录。",
  ]);
});
test("transport failure clears review URL and stops active phase", () => {
  let s = reduce(initialRun(), { type: "begin" });
  s = reduce(s, {
    type: "event",
    event: { event: "node_started", data: { node_id: "extract" } },
  });
  s = reduce(s, { type: "fail", error: "断流" });
  assert.equal(s.status, "error");
  assert(!phaseStates(s, c).includes("active"));
});
test("SSE survives byte split UTF8, CRLF split, comments, and a final message_end", async () => {
  const bytes = new TextEncoder().encode(
    ": ping\r\n\r\ndata: " +
      JSON.stringify({ event: "message", answer: "电梯回路" }) +
      '\r\n\r\ndata: {"event":"message_end"}\r\n\r\n',
  );
  let i = 0;
  const stream = new ReadableStream({
    pull(controller) {
      if (i === bytes.length) return controller.close();
      controller.enqueue(bytes.slice(i, i + 1));
      i++;
    },
  });
  let answer = "";
  const result = await readSSE(stream, (e) => {
    answer += e.answer || "";
  });
  assert.equal(answer, "电梯回路");
  assert.equal(result.ended, true);
});
test("SSE truncated response stays incomplete", async () => {
  const stream = new ReadableStream({
    start(c) {
      c.enqueue(
        new TextEncoder().encode(
          'data: {"event":"message","answer":"partial"}\n\n',
        ),
      );
      c.close();
    },
  });
  assert.equal((await readSSE(stream, () => {})).ended, false);
});

test("partial success retains valid review and marks the degraded phase", () => {
  let s = reduce(initialRun(), { type: "begin" });
  s = reduce(s, {
    type: "event",
    event: {
      event: "node_finished",
      data: { node_id: "numbered_circuit_evidence", status: "exception" },
    },
  });
  s = reduce(s, {
    type: "event",
    event: {
      event: "workflow_finished",
      data: { status: "partial-succeeded" },
    },
  });
  s = reduce(s, {
    type: "event",
    event: { event: "message", answer: `[去核对](${url})` },
  });
  s = reduce(s, { type: "finish" });
  assert.equal(s.status, "review");
  assert.equal(s.workflowStatus, "partial-succeeded");
  assert.equal(phaseStates(s, c)[1], "attention");
  assert.equal(s.url, url);
});

test("malformed SSE frames produce an actionable format error", async () => {
  const stream = new ReadableStream({
    start(c) {
      c.enqueue(new TextEncoder().encode("data: not-json\n\n"));
      c.close();
    },
  });
  await assert.rejects(
    readSSE(stream, () => {}),
    /数据格式异常/,
  );
});
