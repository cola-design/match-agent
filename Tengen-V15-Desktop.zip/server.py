"""Local-only frontend and Dify relay. Python 3.10+, no extra dependencies."""
import json
import os
import argparse
import threading
import webbrowser
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, unquote
import mimetypes
import re

ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'web'
if (ROOT / '.env').exists():
    for line in (ROOT / '.env').read_text(encoding='utf-8-sig').splitlines():
        line = line.strip()
        if line and not line.startswith('#') and '=' in line:
            key, value = line.split('=', 1)
            os.environ.setdefault(key.strip(), value.strip().strip('\"\''))
BASE = os.environ.get('DIFY_API_BASE', '').rstrip('/')
KEY = os.environ.get('DIFY_APP_API_KEY', '')

REVIEW_BASE = os.environ.get('QUOTE_PUBLIC_URL', '').strip().rstrip('/')

def valid_base(value):
    try:
        parsed = urlsplit(value)
        port = parsed.port
        return (parsed.scheme in ('http', 'https') and parsed.hostname
                and not parsed.username and not parsed.password
                and not parsed.query and not parsed.fragment
                and not any(char.isspace() for char in value))
    except ValueError:
        return False

def config_issue():
    if not valid_base(BASE) or not BASE.endswith('/v1'):
        return '请在运行版/.env 填写 Dify 的 Service API 地址，含 /v1，然后重启。'
    if not KEY:
        return '请在运行版/.env 填写 V15 应用的 DIFY_APP_API_KEY，然后重启。'
    if REVIEW_BASE and not valid_base(REVIEW_BASE):
        return '请检查运行版/.env 中的 QUOTE_PUBLIC_URL，然后重启。'
    return ''


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        # Do not log keys, uploaded contents or model responses.
        pass

    def send_json(self, value, status=200):
        body = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/api/status':
            issue = config_issue()
            return self.send_json({'configured': not issue, 'issue': issue, 'review_pattern': '^' + re.escape(REVIEW_BASE) + '/system-quote-reviews/[0-9a-f]{32}$' if REVIEW_BASE else None})
        relative = unquote(path).lstrip('/') or 'index.html'
        file = (WEB / relative).resolve()
        if not file.is_relative_to(WEB.resolve()) or not file.is_file():
            return self.send_json({'error': '页面不存在'}, 404)
        body = file.read_bytes()
        self.send_response(200)
        mime = mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
        self.send_header('Content-Type', mime + ('; charset=utf-8' if mime.startswith('text/') or mime in {'application/javascript', 'image/svg+xml'} else ''))
        self.send_header('Cache-Control', 'no-store' if file.name == 'index.html' else 'public, max-age=3600')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        origin = self.headers.get('Origin')
        if origin and urlsplit(origin).netloc != self.headers.get('Host'):
            return self.send_json({'error': '请求来源不匹配'}, 403)
        paths = {'/api/upload': '/files/upload', '/api/run': '/chat-messages'}
        route = paths.get(self.path)
        if not route:
            return self.send_json({'error': '接口不存在'}, 404)
        if not BASE or not KEY:
            return self.send_json({'error': '尚未接入Dify，请按说明配置 .env 后重启。'}, 503)
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 20 * 1024 * 1024:
                return self.send_json({'error': '请求为空或文件超过20MB。'}, 413)
            body = self.rfile.read(length)
            if self.path == '/api/run':
                payload = json.loads(body)
                if payload.get('response_mode') != 'streaming':
                    return self.send_json({'error': '请使用流式请求。'}, 400)
            request = Request(BASE + route, data=body, method='POST', headers={
                'Authorization': 'Bearer ' + KEY,
                'Content-Type': self.headers.get('Content-Type', 'application/json'),
            })
            upstream = urlopen(request, timeout=1200)
        except HTTPError as exc:
            detail = exc.read(16384).decode('utf-8', errors='replace')
            try:
                detail = json.loads(detail).get('message', detail)
            except (ValueError, AttributeError):
                detail = '' if detail.lstrip().startswith('<') else detail[:300]
            return self.send_json({'error': f'上游返回 HTTP {exc.code}' + (f'：{detail}' if detail else '')}, exc.code)
        except (URLError, TimeoutError, OSError, ValueError) as exc:
            return self.send_json({'error': f'连接Dify失败：{exc}'}, 502)
        with upstream:
            self.send_response(200)
            self.send_header('Content-Type', upstream.headers.get('Content-Type', 'application/json'))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Accel-Buffering', 'no')
            self.send_header('Connection', 'close')
            self.end_headers()
            self.close_connection = True
            try:
                if self.path == '/api/upload':
                    self.wfile.write(upstream.read())
                else:
                    for line in upstream:
                        self.wfile.write(line)
                        self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='本机系统图识别工作台')
    parser.add_argument('--open', action='store_true', help='启动成功后自动打开浏览器')
    args = parser.parse_args()
    try:
        port = int(os.environ.get('PORT', '8780'))
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        raise SystemExit('PORT请填写1至65535的整数，例如8780。')
    if not (WEB / 'index.html').is_file():
        raise SystemExit('页面文件缺失，请解压完整运行包，保留web目录。')
    try:
        server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    except OSError as exc:
        raise SystemExit(f'页面服务未启动：端口{port}不可用。请关闭之前的工作台窗口，或在.env中修改PORT后重试。') from exc
    print(f'工作台已启动，请在浏览器打开 http://localhost:{port}', flush=True)
    print('Dify应用配置已读取' if BASE and KEY else '尚未配置Dify，请填写运行版/.env后重新启动。', flush=True)
    if args.open:
        timer = threading.Timer(0.3, lambda: webbrowser.open(f'http://localhost:{port}'))
        timer.daemon = True
        timer.start()
    server.serve_forever()
