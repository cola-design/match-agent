from pathlib import Path
import os
import threading
import tkinter as tk
from tkinter import messagebox, ttk
import webbrowser
from http.server import ThreadingHTTPServer

def main():
    root = tk.Tk()
    root.withdraw()
    root.title("天正工作台")
    try:
        from server import Handler, WEB, config_issue
        if not (WEB / "index.html").is_file():
            raise ValueError("请将启动文件放在完整工作台的 server.py 旁边。")
        port = int(os.environ.get("PORT", "8780"))
        if not 1 <= port <= 65535:
            raise ValueError("PORT 应为 1 至 65535 的整数。")
        httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    except (ImportError, OSError, ValueError) as error:
        messagebox.showerror("工作台启动失败", f"{error}\n请确认文件已解压完整。如果旧工作台正在运行，请先关闭旧窗口。", parent=root)
        root.destroy()
        return

    url = f"http://127.0.0.1:{port}"
    worker = threading.Thread(target=httpd.serve_forever, daemon=True)
    worker.start()
    try:
        panel = ttk.Frame(root, padding=20)
        panel.pack(fill="both", expand=True)
        ttk.Label(panel, text="工作台已启动").pack(anchor="w")
        ttk.Label(panel, text=url).pack(anchor="w", pady=6)
        ttk.Label(panel, text=config_issue() or "识图时请保持此窗口开启。", wraplength=340).pack(anchor="w")
        ttk.Button(panel, text="打开工作台", command=lambda: webbrowser.open(url)).pack(fill="x", pady=(12, 4))
        ttk.Button(panel, text="关闭服务并退出", command=root.destroy).pack(fill="x")
        root.deiconify()
        root.after(200, lambda: webbrowser.open(url))
        root.mainloop()
    finally:
        httpd.shutdown()
        worker.join()
        httpd.server_close()

if __name__ == "__main__":
    main()
