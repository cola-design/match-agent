使用说明

1. 解压，将 dify_mongodb_03_tcp_check.yml 作为新的独立应用导入 Dify。
2. 运行预览时填写：
   mongo_host：Navicat连接属性里的完整MongoDB IPv4地址，仅填IP。
   mongo_port：27017，或Navicat中实际端口。
3. 不需要用户名、密码、MongoDB URI或API密钥。不要修改正式报价工作流。
4. tcp_connected：仅表示TCP端口可达，尚未验证MongoDB账号或读权限。
5. validate_input：IP或端口格式错误。
6. TimeoutError：连接超时，检查网络、路由、防火墙和沙箱限制。
7. ConnectionRefusedError：目标拒绝连接，检查端口及监听服务。
8. PermissionError：可能是沙箱权限限制，查看Sandbox日志。
9. 若仍被Dify强制终止（timeout / signal: killed），需管理员查看代码节点及Sandbox日志；socket超时设置不能保证绕过沙箱限制。
