"""Serve the local workbench and forward its requests to the cloud gateway."""
import argparse
import threading
import webbrowser
from http.server import ThreadingHTTPServer
from mimetypes import guess_type
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import unquote, urlsplit

from relay_http import (
    JSON_LIMIT, UPLOAD_LIMIT, JSONHandler, RequestError,
    contact, endpoint, opener, read_settings, relay_token,
)


ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'web'


def external_origin(value, name):
    origin = endpoint(value, name, allow_http=True)
    parts = urlsplit(origin)
    if parts.scheme == 'http' and parts.hostname not in ('localhost', '127.0.0.1'):
        raise ValueError(f'{name} 请填写 HTTPS 域名。HTTP 仅用于本机联调。')
    return origin


class Desktop(JSONHandler):
    client = opener()

    def check_host(self):
        port = self.server.server_port
        host = self.headers.get('Host', '')
        origin = self.headers.get('Origin')
        return host in (f'localhost:{port}', f'127.0.0.1:{port}') and (
            origin is None or origin == f'http://{host}'
        )

    def do_GET(self):
        if not self.check_host():
            return self.json_response({'error': '请求来源不匹配。'}, 403)
        path = urlsplit(self.path).path
        if path == '/api/status':
            return self.json_response({
                'configured': not self.server.config_error,
                'configError': self.server.config_error,
                'reviewOrigin': self.server.review_origin,
            })
        if self.path == '/api/check':
            return self.forward('/api/check')
        file = (WEB / (unquote(path).lstrip('/') or 'index.html')).resolve()
        if not file.is_relative_to(WEB.resolve()) or not file.is_file():
            return self.json_response({'error': '页面不存在。'}, 404)
        body = file.read_bytes()
        mime = 'application/javascript' if file.suffix == '.js' else guess_type(file.name)[0]
        self.send_response(200)
        self.send_header('Content-Type', mime or 'application/octet-stream')
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if not self.check_host():
            return self.json_response({'error': '请求来源不匹配。'}, 403)
        limits = {
            '/api/upload': (UPLOAD_LIMIT, 'multipart/form-data'),
            '/api/run': (JSON_LIMIT, 'application/json'),
        }
        if self.path not in limits:
            return self.json_response({'error': '接口不存在。'}, 404)
        if self.server.config_error:
            return self.json_response({'error': self.server.config_error}, 503)
        try:
            body = self.read_body(*limits[self.path])
            self.forward(self.path, body, self.headers['Content-Type'])
        except RequestError as exc:
            self.json_response({'error': str(exc)}, exc.status)

    def forward(self, path, body=None, content_type=None):
        if self.server.config_error:
            return self.json_response({'error': self.server.config_error}, 503)
        try:
            with contact(
                self.client, self.server.gateway + path, self.server.token,
                '华为云调用服务', body, content_type,
                timeout=20 if path == '/api/check' else 190,
            ) as upstream:
                if path == '/api/run':
                    return self.stream(upstream, '华为云调用服务')
                data = self.json_upstream(upstream, '华为云调用服务')
                return self.json_response(data)
        except HTTPError as exc:
            with exc:
                code = exc.code
                message = ''
                if exc.headers.get_content_type() == 'application/json':
                    try:
                        data = self.json_upstream(exc, '华为云调用服务')
                        if isinstance(data, dict) and isinstance(data.get('error'), str):
                            message = data['error'][:500]
                    except RequestError:
                        pass
            operation = {'/api/check': '检查连接', '/api/upload': '上传图纸', '/api/run': '启动识图'}
            message = message or f'华为云入口在{operation[path]}时返回 HTTP {code}，请检查云端网关。'
            self.json_response({'error': message}, code if 400 <= code < 600 else 502)
        except RequestError as exc:
            self.json_response({'error': str(exc)}, exc.status)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--open', action='store_true', help='启动后打开工作台')
    args = parser.parse_args()
    values = read_settings(ROOT, {'GATEWAY_URL', 'GATEWAY_TOKEN', 'REVIEW_PUBLIC_ORIGIN', 'PORT'})
    try:
        port = int(values['PORT'] or '8780')
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError:
        raise SystemExit('PORT 必须在 1 至 65535 之间。') from None
    gateway = token = review = error = ''
    try:
        if not values['GATEWAY_URL'] or not values['GATEWAY_TOKEN']:
            raise ValueError('请在运行版 .env 中填写 GATEWAY_URL 和 GATEWAY_TOKEN 后重启。')
        gateway = external_origin(values['GATEWAY_URL'], 'GATEWAY_URL')
        token = relay_token(values['GATEWAY_TOKEN'])
        if values['REVIEW_PUBLIC_ORIGIN']:
            review = external_origin(values['REVIEW_PUBLIC_ORIGIN'], 'REVIEW_PUBLIC_ORIGIN')
    except ValueError as exc:
        error = str(exc)
    if not (WEB / 'index.html').is_file():
        raise SystemExit('缺少页面文件，请解压完整运行包。')
    try:
        server = ThreadingHTTPServer(('127.0.0.1', port), Desktop)
    except OSError as exc:
        raise SystemExit(f'工作台无法启动，请确认端口 {port} 可用。') from exc
    server.gateway, server.token, server.review_origin, server.config_error = gateway, token, review, error
    url = f'http://localhost:{port}'
    print(f'请在浏览器打开 {url}。', flush=True)
    if error:
        print(error, flush=True)
    if args.open:
        timer = threading.Timer(0.3, lambda: webbrowser.open(url))
        timer.daemon = True
        timer.start()
    with server:
        server.serve_forever()


if __name__ == '__main__':
    main()
