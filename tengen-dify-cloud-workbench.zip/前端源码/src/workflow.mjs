export function initialRun() {
  return {
    status: "idle",
    nodes: {},
    logs: [],
    answer: "",
    url: "",
    error: "",
    issuePhase: null,
    startedAt: null,
    endedAt: null,
    sample: false,
    workflowStatus: "",
  };
}
export function phaseFor(contract, id) {
  return contract.phases.findIndex((p) => p.nodes.includes(id));
}
export function findReviewUrl(answer, pattern) {
  const valid = new RegExp(pattern);
  const matches = String(answer).match(/https?:\/\/[^\s<>"')\]*]+/g) || [];
  return matches.find((url) => valid.test(url)) || "";
}
export function replyParagraphs(answer, pattern) {
  return String(answer)
    .split(/\r?\n\s*\r?\n/)
    .filter(
      (p) =>
        !/^\s*\*{0,2}\[[^\]]+\]\([^)]+\)\*{0,2}\s*$/.test(p) ||
        !findReviewUrl(p, pattern),
    )
    .map((p) =>
      p
        .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
        .replace(/\*\*/g, "")
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .trim(),
    )
    .filter(Boolean);
}
export function reduceRun(run, action, contract) {
  const at = action.at ?? Date.now();
  if (action.type === "reset") return initialRun();
  if (action.type === "begin")
    return {
      ...initialRun(),
      status: "processing",
      startedAt: at,
      sample: !!action.sample,
      logs: [
        {
          text: action.sample ? "示例流程已开始" : "正在上传图纸",
          at,
          kind: "info",
        },
      ],
    };
  if (action.type === "note")
    return {
      ...run,
      logs: [
        ...run.logs,
        { text: action.text, at, kind: action.kind || "info" },
      ],
    };
  if (action.type === "event") {
    const e = action.event,
      data = e.data || {},
      id = data.node_id;
    if (e.event === "workflow_finished")
      return { ...run, workflowStatus: data.status || "" };
    if (e.event === "message" || e.event === "agent_message")
      return { ...run, answer: run.answer + (e.answer || "") };
    if (e.event === "message_replace")
      return { ...run, answer: e.answer || "" };
    if (e.event === "node_started" || e.event === "node_finished") {
      const known = phaseFor(contract, id) >= 0,
        status =
          e.event === "node_started" ? "running" : data.status || "unknown";
      const failurePhase = contract.failureNodes[id];
      const issuePhase =
        failurePhase !== undefined ? failurePhase : run.issuePhase;
      const label = data.title || contract.nodeTitles[id] || "流程处理";
      return {
        ...run,
        issuePhase,
        nodes: known ? { ...run.nodes, [id]: status } : run.nodes,
        logs: [
          ...run.logs,
          {
            text:
              label +
              (e.event === "node_started"
                ? ""
                : " · " +
                  (status === "succeeded"
                    ? "完成"
                    : status === "failed" || status === "exception"
                      ? "需处理"
                      : "已结束")),
            at,
            kind:
              status === "failed" || status === "exception"
                ? "warning"
                : "info",
          },
        ],
      };
    }
    return run;
  }
  if (action.type === "finish") {
    const original = run.sample
      ? ""
      : findReviewUrl(run.answer, contract.reviewUrlPattern);
    const publicPattern = action.reviewOrigin
      ? "^" + action.reviewOrigin.replace(/[.*+?^$${}()|[\]\\]/g, "\\$&") +
        "/system-quote-reviews/[0-9a-f]{32}$"
      : "";
    const url = action.reviewOrigin === undefined
      ? original
      : run.sample || !action.reviewOrigin
        ? ""
        : original
          ? action.reviewOrigin + new URL(original).pathname
          : findReviewUrl(run.answer, publicPattern);
    let last = contract.phases.reduce(
      (n, p, i) => (p.nodes.some((id) => run.nodes[id]) ? i : n),
      -1,
    );
    return {
      ...run,
      status: run.sample ? "sample" : url ? "review" : "attention",
      url,
      reviewNeedsAddress: !!original && action.reviewOrigin === "",
      issuePhase:
        url || run.sample ? null : (run.issuePhase ?? (last >= 0 ? last : 3)),
      endedAt: at,
    };
  }
  if (action.type === "fail") {
    const last = contract.phases.reduce(
      (n, p, i) => (p.nodes.some((id) => run.nodes[id]) ? i : n),
      -1,
    );
    return {
      ...run,
      status: "error",
      url: "",
      error: action.error,
      issuePhase: run.issuePhase ?? Math.max(0, last),
      endedAt: at,
      logs: [...run.logs, { text: action.error, at, kind: "warning" }],
    };
  }
  return run;
}
export function phaseStates(run, contract) {
  return contract.phases.map((phase, i) => {
    if (run.status === "sample") return "done";
    if (run.status === "review")
      return phase.nodes.some((id) =>
        ["failed", "exception"].includes(run.nodes[id]),
      )
        ? "attention"
        : "done";
    if (
      (run.status === "attention" || run.status === "error") &&
      run.issuePhase === i
    )
      return "attention";
    const states = phase.nodes.map((id) => run.nodes[id]);
    if (states.some((s) => s === "failed" || s === "exception"))
      return "attention";
    if (states.every((s) => s === "succeeded")) return "done";
    if (states.some(Boolean))
      return run.status === "processing" ? "active" : "attention";
    return "pending";
  });
}
export function validateFile(file, limits) {
  if (!file) return "请先选择一份系统图。";
  if (!/\.(pdf|png|jpe?g)$/i.test(file.name))
    return "请上传PDF、PNG或JPG格式的系统图。";
  if (!file.size) return "文件为空，请重新选择图纸。";
  const pdf = /\.pdf$/i.test(file.name),
    max = pdf ? limits.documentBytes : limits.imageBytes;
  if (file.size > max)
    return `${pdf ? "PDF" : "图片"}超过${max / 1024 / 1024}MB，请压缩后重新上传。`;
  return "";
}
export function validateCount(value) {
  return value === "" || /^[1-9]\d{0,5}$/.test(value)
    ? ""
    : "柜台数请输入1至999999的整数，暂不确定可留空。";
}
export async function readSSE(stream, onEvent) {
  const reader = stream.getReader(),
    decoder = new TextDecoder();
  let buffer = "",
    done = false,
    ended = false;
  const frame = (text) => {
    const data = text
      .split("\n")
      .filter((line) => line.startsWith("data:"))
      .map((line) => line.slice(5).trimStart())
      .join("\n");
    if (!data || data === "[DONE]") return;
    let event;
    try {
      event = JSON.parse(data);
    } catch {
      throw Error("服务返回的数据格式异常，请检查应用运行记录。");
    }
    onEvent(event);
    if (event.event === "message_end") ended = true;
  };
  try {
    while (!ended) {
      const result = await reader.read();
      done = result.done;
      buffer = (
        buffer +
        decoder.decode(result.value || new Uint8Array(), { stream: !done })
      ).replace(/\r\n/g, "\n");
      let index;
      while ((index = buffer.indexOf("\n\n")) >= 0) {
        frame(buffer.slice(0, index));
        buffer = buffer.slice(index + 2);
        if (ended) break;
      }
      if (done) {
        if (buffer.trim() && !ended) frame(buffer);
        break;
      }
    }
    return { ended };
  } finally {
    if (!done) await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}
export async function responseJSON(response) {
  let data;
  try {
    data = await response.json();
  } catch {
    throw Error("服务未返回有效数据，请检查应用API地址。");
  }
  if (!response.ok)
    throw Error(data.error || data.message || "请求未成功，请检查服务后重试。");
  return data;
}
