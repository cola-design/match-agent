"""HTTP helpers used by the desktop and cloud services."""
import json
import os
import re
import socket
from http.server import BaseHTTPRequestHandler
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


UPLOAD_LIMIT = 16 * 1024 * 1024  # Includes the multipart envelope around a 15 MB PDF.
JSON_LIMIT = 16 * 1024
USER_ID = re.compile(r'[a-zA-Z0-9_-]{1,128}')


class RequestError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def read_settings(folder, names):
    path = folder / '.env'
    values = {}
    if path.is_file():
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            key, sep, value = line.partition('=')
            if sep and key.strip() in names:
                values[key.strip()] = value.strip().strip('"\'')
    return {name: os.environ.get(name, values.get(name, '')).strip() for name in names}


def endpoint(value, name, path='', allow_http=False):
    try:
        parts = urlsplit(value.rstrip('/'))
        port = parts.port
        valid = (
            len(value.split('://')) == 2 and not re.search(r'[\s\\?#]', value)
            and parts.scheme in (('http', 'https') if allow_http else ('https',))
            and parts.hostname and parts.username is None and parts.password is None
            and (port is None or port > 0) and parts.path == path
            and re.fullmatch(r'[A-Za-z0-9.\-:\[\]]+', parts.netloc)
        )
    except ValueError:
        valid = False
    if not valid:
        raise ValueError(f'{name} 地址格式错误，请检查协议、主机和路径，协议只填写一次。')
    return parts._replace(netloc=parts.netloc.lower()).geturl()


def relay_token(value):
    if not re.fullmatch(r'[A-Za-z0-9_-]{32,128}', value):
        raise ValueError('GATEWAY_TOKEN 必须为 32 至 128 位字母、数字、下划线或短横线。')
    return value


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def opener(direct=False):
    return build_opener(NoRedirect(), *([ProxyHandler({})] if direct else []))


def contact(client, url, key, label, body=None, content_type=None, timeout=180):
    headers = {'Authorization': f'Bearer {key}', 'Accept-Encoding': 'identity'}
    if content_type:
        headers['Content-Type'] = content_type
    try:
        return client.open(Request(url, data=body, headers=headers), timeout=timeout)
    except (socket.timeout, TimeoutError) as exc:
        raise RequestError(504, f'连接{label}超时，请检查网络和服务状态。') from exc
    except URLError as exc:
        if hasattr(exc, 'code'):
            raise  # The caller handles upstream HTTP status and closes the response.
        status = 504 if isinstance(exc.reason, TimeoutError) else 502
        raise RequestError(status, f'无法连接{label}，请检查服务地址和网络。') from exc
    except OSError as exc:
        raise RequestError(502, f'连接{label}中断，请检查网络和服务状态。') from exc


class JSONHandler(BaseHTTPRequestHandler):
    timeout = 195

    def log_message(self, fmt, *args):
        pass

    def json_response(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_body(self, limit, content_type):
        if self.headers.get('Transfer-Encoding') or len(self.headers.get_all('Content-Length', [])) != 1:
            raise RequestError(400, '请求必须带有有效的 Content-Length。')
        if self.headers.get_content_type() != content_type:
            raise RequestError(415, '请求格式不受支持。')
        size = self.headers['Content-Length']
        if not re.fullmatch(r'[0-9]{1,10}', size) or int(size) == 0:
            raise RequestError(400, '请求内容为空或长度无效。')
        if int(size) > limit:
            raise RequestError(413, '上传内容超过允许的大小。')
        body = self.rfile.read(int(size))
        if len(body) != int(size):
            raise RequestError(400, '请求内容未完整送达，请重新提交。')
        return body

    def json_upstream(self, upstream, label):
        try:
            return json.loads(upstream.read(64 * 1024 + 1))
        except (ValueError, OSError) as exc:
            raise RequestError(502, f'{label}未返回有效的 JSON 数据。') from exc

    def stream(self, upstream, label):
        if upstream.headers.get_content_type() != 'text/event-stream':
            raise RequestError(502, f'{label}未返回识图进度流。')
        self.send_response(200)
        self.send_header('Content-Type', 'text/event-stream; charset=utf-8')
        self.send_header('Cache-Control', 'no-store, no-transform')
        self.send_header('X-Accel-Buffering', 'no')
        self.send_header('Connection', 'close')
        self.end_headers()
        self.close_connection = True
        try:
            while chunk := upstream.read1(8192):
                self.wfile.write(chunk)
                self.wfile.flush()
        except (OSError, EOFError):
            return  # An incomplete stream is detected by the desktop UI.
