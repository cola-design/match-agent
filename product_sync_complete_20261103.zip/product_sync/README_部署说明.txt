数据清洗更新服务：完整单文件部署目录

业务版本：1.2.2。product_sync_service.py 直接封装此前交付的五份业务源代码。
程序已通过原50项测试及隔离MongoDB中的实际更新、校验、重复运行和失败保护验证。
这些验证不代替目标服务器网络及首次正式写入验收。

一、替换目录
只替换 product_sync 目录。先确认没有同步任务正在运行，并在目录外保存旧.env的真实配置。
旧sync_state可以另行备份；本包无需旧状态目录即可运行。清空状态目录会丢失历史报告和快照，不会删除MongoDB产品。
将本包解压后的整个product_sync文件夹放回服务器原位置，绝对路径由部署负责人确认。
不要误放成product_sync/product_sync两层目录。

二、配置
本包.env中的三个私有值为空，必须填写：
SYNC_MONGODB_URI：同步账号的完整MongoDB连接字符串，包含正确的认证库参数。
PRODUCT_API_URL：原来电脑成功抓取时使用的完整HTTP(S)接口地址，保留原接口路径，不带查询参数。
PRODUCT_API_KEY：产品源接口提供的密钥，不是Dify查询API的密钥。
其余默认参数沿用已经验证的配置。目标数据库默认为match_agent。
本目录没有真实密码、密钥或真实源接口路径。填好后的.env只能私下保存和传输。
进程中的同名环境变量优先于.env；修改.env后须新启动任务，并核对启动器中是否有旧值。

三、Python依赖
使用已安装的Python 3.10或以上，建议3.12；可以沿用服务器现有py310环境。
在本目录执行：
python -m pip install -r requirements.txt

四、服务器连接检查（只读）
进入本目录后执行：
python product_sync_service.py --check --state-dir "$PWD/sync_state"
通过时sync_state/latest_check.json中的phase为check_complete，result为check_passed。
快检不写数据库，不验证实际写入权限，也不拉取全量数据。
Windows PowerShell把上面的状态目录写成 "$PWD\sync_state" 即可。

五、正式更新
首次正式写入前备份目标数据库的products集合。
执行：
python product_sync_service.py --apply --state-dir "$PWD/sync_state"
程序重新全量抓取、清洗、比较，受保护地更新产品，再核对写入结果。
成功时sync_state/latest.json的phase为complete、result为success、applied_operations与verified_operations相等。
prices_touched应为false，同时生成sync_state/last_success.json。
按批写入不是全库事务；失败时可能已有部分产品更新，应保留运行报告核查。
新增或技术内容变化的产品按规则进入待审核状态；不自动发布，不删除本次源接口未返回的旧产品，不更新价格。

六、定时（由部署负责人配置）
北京时间每月1日凌晨01:00运行正式更新命令。
只保留一份同步任务。将旧任务入口改为product_sync_service.py --apply。
Crontab使用Python解释器、脚本、状态目录的绝对路径，并将工作目录设为本目录，保留日志。
时间表达式按cron守护进程采用的时区解释；部署负责人必须核对北京时间，不能直接假定服务器时区。
不需要Docker或内置定时器。

七、可选全量预览
python product_sync_service.py --state-dir "$PWD/sync_state"
此模式会全量抓取、清洗和比较，但不更新MongoDB。仅合并文件不要求重复已完成的预览。

八、运行文件
product_sync_service.py：唯一业务程序入口。
.env：本机配置。
requirements.txt：依赖清单。
README_部署说明.txt：本文。
sync_state：程序首次运行时自动创建，用于快照、报告及同目录任务的互斥锁。
